%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%
%%%%    Load variables:
%%%%    Syntax:     loadright01(variable block)
%%%%       variable block: contains two strings:
%%%%          1) loadname: the specific filename suffix needed to load the correct file
%%%%          2) Variable names to load in one of three varieties
%%%%             a) empty string - load all variables in the file
%%%%                varinfoo = {loadname,''''''}; 
%%%%             b) specific variable string - only load this variables
%%%%                varinfoo = {loadname,'''losmat'''};
%%%%             c) regexp string - load variables according to the regexp
%%%%                in this example, it loads all variables in the file 
%%%%                except those listed in the given
%%%%                varinfoo = {loadname,'''-regexp'',''^(?!dircos|deltar|pathcount|pathltrue|deltaxl1|pathl1true)\w'''};
%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ loadright1 ] = loadright03(varargin)

global fileroot shapestr prodrunnum prepindex fileprefix dataname 
global sigfigs smallpartnums3 partsize  
    
if nargin==1
    varinfoo   = varargin{1};
    loadname   = varinfoo{1};
%    varnamee   = varinfoo{2};
    numvarnames = size(varinfoo,2);         %  Actual variable list starts at 2nd position as the 1st is the filename to load from
    
    filenamess = ls(sprintf('%s/_DATA/%s/prod_%04d_%s_%s*',fileroot,shapestr,prodrunnum,loadname,fileprefix));
    kk = 0;
    if partsize>=smallpartnums3
        for ii = 1:size(filenamess,1)
            for jj = 2:numvarnames
                kk = kk+1;
                if numvarnames==2;if strcmp(varinfoo{jj},'''short''')|strcmp(varinfoo{jj},'''full''');varinfoo{2} = ''''''; end;end
                tmpp = eval(sprintf('load(''%s/_DATA/%s/%s'',%s)',fileroot,shapestr,char(filenamess(ii,:)),varinfoo{jj}));
                loadright1{kk} = tmpp;
            end
        end
    else
        for ii = 1:size(filenamess,1)
            for jj = 2:numvarnames
                kk = kk+1;
                if numvarnames==2;if strcmp(varinfoo{jj},'''short''')|strcmp(varinfoo{jj},'''full''');varinfoo{2} = ''''''; end;end
                tmpp = eval(sprintf('load(''%s/_DATA/%s/%s'',%s)',fileroot,shapestr,char(filenamess(ii,:)),varinfoo{jj}));
                loadright1{kk} = tmpp;
            end
        end
    end
else
    display('Wrong inputs.  Stopping.');
end
return




%       varinfoo = {loadname,''''''}; 
%       varinfoo = {loadname,'''losmat'''}; 
%       varinfoo = {loadname,'''-regexp'',''^(?!dircos|deltar|pathcount|pathltrue|deltaxl1|pathl1true)\w'''};
