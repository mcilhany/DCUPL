%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%
%%%%    Save Variables properly (setting significant figures as well):
%%%%    Syntax:     saveright01(variable name, save flag, clear flag)
%%%%                variable name:  the names of the variables to save
%%%%                save flag:      FLAG set to allow/prevent saving
%%%%                  *** if savevar == -1 then append the varaible to the file
%%%%                clear flag:     FLAG set to clear a global after saving
%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ saveright1 ] = saveright01(varargin)

global fileroot shapestr prodrunnum prepindex fileprefix dataname 
global sigfigs smallpartnums3 partsize  
    
if nargin==1
    varinfoo   = varargin{1};
    varnamee   = varinfoo{1};
    savevar    = varinfoo{2};
    clearvar   = varinfoo{3};
    eval(sprintf('global %s',varnamee));
    
    if partsize>=smallpartnums3  
        if savevar==1
            memtest = whos(varnamee);
            if memtest.bytes>0
                if ~iscell(eval(varnamee))
                    if eval(sprintf('~islogical(%s)',varnamee))
                        eval(sprintf('%s = round(%s*10^sigfigs)/10^sigfigs;',varnamee,varnamee));
                    end
                end
                if memtest.bytes<(2^31-100)
                    save(sprintf('%s/_DATA/%s/prod_%04d_%s_%s_%s.mat',fileroot,shapestr,prodrunnum,dataname,fileprefix,varnamee),varnamee);
                else
                    save(sprintf('%s/_DATA/%s/prod_%04d_%s_%s_%s.mat',fileroot,shapestr,prodrunnum,dataname,fileprefix,varnamee),varnamee,'-v7.3');
                end
                if clearvar==1
                    eval(sprintf('clear global %s',varnamee));
                end
            end
        end
        if savevar==-1
            memtest = whos(varnamee);
            if memtest.bytes>0
                if ~iscell(eval(varnamee))
                    if eval(sprintf('~islogical(%s)',varnamee))
                        eval(sprintf('%s = round(%s*10^sigfigs)/10^sigfigs;',varnamee,varnamee));
                    end
                end
                if exist(sprintf('%s/_DATA/%s/prod_%04d_%s_%s.mat',fileroot,shapestr,prodrunnum,dataname,fileprefix))
                    if memtest.bytes<(2^31-100)
                        save(sprintf('%s/_DATA/%s/prod_%04d_%s_%s.mat',fileroot,shapestr,prodrunnum,dataname,fileprefix),varnamee,'-append');
                    else
                        save(sprintf('%s/_DATA/%s/prod_%04d_%s_%s.mat',fileroot,shapestr,prodrunnum,dataname,fileprefix),varnamee,'-v7.3','-append');
                    end
                else
                    if memtest.bytes<(2^31-100)
                        save(sprintf('%s/_DATA/%s/prod_%04d_%s_%s.mat',fileroot,shapestr,prodrunnum,dataname,fileprefix),varnamee);
                    else
                        save(sprintf('%s/_DATA/%s/prod_%04d_%s_%s.mat',fileroot,shapestr,prodrunnum,dataname,fileprefix),varnamee,'-v7.3');
                    end
                end
                if clearvar==1
                    eval(sprintf('clear global %s',varnamee));
                end
            end
        end
    else
        memtest = whos(varnamee);
        if memtest.bytes>0
            if ~iscell(eval(varnamee))
                if eval(sprintf('~islogical(%s)',varnamee))
                    eval(sprintf('%s = round(%s*10^sigfigs)/10^sigfigs;',varnamee,varnamee));
                end
            end
            if exist(sprintf('%s/_DATA/%s/prod_%04d_%s_%s_full.mat',fileroot,shapestr,prodrunnum,dataname,fileprefix))
                save(sprintf('%s/_DATA/%s/prod_%04d_%s_%s_full.mat',fileroot,shapestr,prodrunnum,dataname,fileprefix),varnamee,'-append');
            else
                save(sprintf('%s/_DATA/%s/prod_%04d_%s_%s_full.mat',fileroot,shapestr,prodrunnum,dataname,fileprefix),varnamee);
            end
            if clearvar==1
                eval(sprintf('clear global %s',varnamee));
            end
        end
    end
else
    display('Wrong inputs.  Stopping.');
end
return
    