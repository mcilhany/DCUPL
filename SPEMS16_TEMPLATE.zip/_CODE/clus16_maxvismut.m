function [ maxvismutreturn ] = clus16_maxvismut(varargin)
close all force
profile off
warning off
global fileroot shapestr prodrunnum prepindex fileprefix dataname 
global sigfigs smallpartnums3 partsize  
global dataptsminmax dataptspartkeep dataindexminmax dataindexpartkeep datapartkeepindex dataminmaxpartindex binadd2 datamin datamax datadelta 
global varnamesshort varnameslong varnamestime
varnamesshort = {'bignum','sigfigs','minpop','minpathl','threshdist','losthresh0','losthreshgrowth','threshmode','losmode','clustermode','shapestr','fileprefix','nvars','databins','datadelta','datamax','datamin','partsize','partkeep','partkeepind','memusedmaxvismut','clustermaxmut','clustermedoidsm','nclustersm','clustermaxvis','clustermedoidsv','nclustersv'};
varnameslong  = {''};
varnamestime  = {'timemaxvismut','tstartmaxvismutt','tendmaxvismutd'};
dataname      = 'maxvismut';
global pathl wgtmat

load(sprintf('%s/_DATA/prod/prod_prep_%04d_%04d.mat',fileroot,prodrunnum,prepindex));
display(sprintf('%04d - %s - LOS GATHERING for Visibility and Pluarity',prodrunnum,fileprefix))

checkfilemaxvismut0 = ls(sprintf('%s/_DATA/%s/prod_%04d_%s_%s_*.mat',fileroot,shapestr,prodrunnum,dataname,fileprefix));
checkfilemaxvismut  = logical(size(checkfilemaxvismut0,2));
if checkfilemaxvismut
   display('LOS GATHERING clustering already done.');
end
checkgomaxvismut =  ~(checkfilemaxvismut&(~checkoverwritemaxvismut));
checkgomaxvismut =   (checkgomaxvismut|checkreclustermaxvismut);
if checkgomaxvismut             % GO!!!!!!!
    display(sprintf('LOS GATHERING files:  %1d OVERWRITE LOSGATHERING:  %1d   GATHERING analysis will be DONE.',checkfilemaxvismut,checkoverwritemaxvismut));

    tstartmaxvismut = now;
    %profile on
%    loadname = 'init'; 
%    varinfoo = {loadname,'''-regexp'',''^(?!dircos|deltaxl1|pathcount|pathltrue|pathl1true|pathl1corr)\w'''};
%    loadright1 = loadright03(varinfoo);for jj=1:size(loadright1,2);varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end;loadright1{jj}=[];end

    loadname = 'init'; 
    varinfoo = {loadname,'''-regexp'',''^(?!dircos|deltar|pathcount|pathltrue|pathl1true|pathl1corr|deltaxl1|nn1)\w'''};
    loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end
    loadname = 'connpathl'; 
    varinfoo = {loadname,'''-regexp'',''^(?!connmat|pathcheck|pathlcount|pathltrue)\w'''};
    loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end
    loadname = 'LOS'; 
    varinfoo = {loadname,'''-regexp'',''^(?!sdeltax|sdccount|pathl|pathlcount)\w'''};
    loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end
    wgtmat = partkeepwgts*partkeepwgts';
    losmat = single(losmat);
    kk = 0;
    for ii = 1:length(binaddu)
       mapindex  = find(partkeep==binaddu(ii));
       if ~isempty(mapindex)
           if mapindex>0
               kk = kk+1;
               partmap(kk) = mapindex;
           end
       end
       clear mapindex
    end
%    losmat = losmat(partkeepind,partkeepind);
    losmat = losmat(partmap,partmap);
%    losmat = losmat(indexminpathl,indexminpathl);
    losmat0 = losmat;
    
    if plotall2==1
        plotclusters           = 1;
        plotpathweights        = 1;
    end
    bignum2 = bignum/10^3;
    nrows = partsize;
    indexxs = 1:nrows;
    indexxxs = logical(ones(1,nrows));

    maxvismut         = 1;          % maxvismut=1 - maximum visibility   maxvismut=0 - maximal mutual visibility
    flagcollectiveind = 0           % flagcollectiveind=1 - use the full LLL matrix for the histogram, else use individual partitions
    fixedbins         = 100;
    fixedbins         = 60;
    peakthresh0       = 0.25;
    threshmin0        = 0.01;
    resurgethresh0    = 0.33;
    threshoverlap     = 0.90;
    stddevnum         = 1;
    nsmooth           = 1;
    plotflag          = 0;
    clustershow   = 1e6;
    clustermaxvis = zeros(partsize,partsize);
    clusterid = 0;
%    nsmooth           = ceil(sqrt(fixedbins/2));
%    resurgethresh0    = peakthresh0;
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%  Place all of the "Islands" into one large group
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    l2 = losmat*losmat;
    lll = l2.*losmat;
    [maxlllp,maxllli] = max(lll);
    pindex = 1:partsize;
    maxlllh = ceil(max(maxlllp)/1);
    maxpindex = maxllli(maxlllp==maxlllh);
    losislands = maxllli(maxlllp<minpathlprep);
    
    flaglosislands = ~isempty(losislands);
    if flaglosislands
        losmat(losislands,:) = 0;
        losmat(:,losislands) = 0;
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    l2 = losmat*losmat;
    lll = l2.*losmat;
    [llla,lllb] = hist(lll(lll(:)>0),10*fixedbins);
    lllc = cumsum(llla);
    llln = 1:(10*fixedbins);
    lllnc = lllc>(lllc(end)*threshmin0);
    llln2 = llln(lllnc);
    llld = lllb(llln2);
    llldmin = min(llld);
    llldmax = max(llld);
    lllbmin = min(lllb);
    lllbins = ceil((llldmax-lllbmin)/(llldmax-llldmin)*fixedbins);  
    lllbinwidth = (llldmax-lllbmin)/lllbins;
    lllbins = lllbins+2;
    llledges = linspace(lllbmin-lllbinwidth,llldmax+lllbinwidth,lllbins);
    
    maxvisedgeset  = [];
    
    partitioncount=1;
    while partitioncount>0
        [maxlllp,maxllli] = max(lll);
        [minlllp,minllli] = min(lll);
        pindex = 1:partsize;
        maxlllh = ceil(max(maxlllp)/1);
        maxpindex = maxllli(maxlllp==maxlllh);
        binedgess = 0:maxlllh;
        binedgess = binedgess + 0.5;
        [sortmaxlpa,sortmaxlpi] = sort(maxlllp,'descend');
        if flagcollectiveind==1
            lllvec0 = lll(:);
        else
            lllvec0 = lll(sortmaxlpi(1),:);
        end
        lllvec = lllvec0(lllvec0(:)>0);
        [histt,histbins,mapuniquetowgts]= histcounts(lllvec(lllvec(:)>0),llledges);
        maxhistv   = max(histt);
        maxpindexv = maxllli(histt==maxhistv);
        
        [losmarkerstart,losmarkerend,histtlosmax] = findmarkers_01(histt,histbins,fixedbins,peakthresh0,threshmin0,resurgethresh0,stddevnum,nsmooth,maxvismut,plotflag);

        sizemarkers = length(losmarkerend);
        if flagcollectiveind==1
            maxvispartsettmp = maxllli(maxlllp>=histbins(losmarkerstart(end)));
            maxvlllind = 1:length(maxvispartsettmp);
            [maxvlll1,maxvllli] = max(maxlllp(maxvispartsettmp));
            maxpart1 = maxvlllind(maxlllp(maxvispartsettmp)==maxvlll1);
            maxvpart = maxvispartsettmp(maxpart1(ceil(end/2)));            % choose the middle partition out a tied set of maxima
        else
            maxvpart = sortmaxlpi(1);
        end
        llltmp = lll(maxvpart,:);
        loshistbins = histbins(losmarkerstart(sizemarkers):(losmarkerend(sizemarkers)-1));
        histstart = max([loshistbins(1) epss]);
        histend   = loshistbins(end);
        flagllls  = llltmp>=histstart;
        flagllle  = llltmp<=histend;
        flaglll   = flagllls&flagllle;
        goodset   = pindex(flaglll);
        sizegoodset = size(goodset,2);
        if sizegoodset<=minpathlprep
            maxvisedgeset = [maxvisedgeset goodset];
        else
            clusterid = clusterid+1
            clustermaxvis(clusterid,1:sizegoodset) = goodset;
        end
%        losmat(goodset,:) = 0;
%        losmat(:,goodset) = 0;
        lll(goodset,:) = 0;
        lll(:,goodset) = 0;
        
%        partitioncount = sum(logical(sum(losmat)))
        partitioncount = sum(logical(sum(lll)))
        
    end
    clustertmp = clustermaxvis;
    clustertmp(sum(clustertmp,2)==0,:)=[];
    clustertmpc = sum(clustertmp,1);
    clustertmp(:,clustertmpc==0) = [];
    [clustertmp1,clos1a,clos1b] = unique(clustertmp,'rows');
    clustertmp2 = clustertmp1(clos1b,:);

    clustertmp2log = logical(clustertmp2);
    clustertmp2size  = sum(clustertmp2log,2);
    [ca,cb] = sort(clustertmp2size,'descend');
    clustertmp22 = clustertmp2(cb,:);

    clussize = min([size(clustertmp22,1) clustershow]);
    clustertmp2 = clustertmp22(1:clussize,:);
    clustermaxvis0 = clustertmp2;
    
    
%     checkclussize = (sum(clustermaxvis0>0,2)>minpathlprep);
%     
%     checkclus = sum(clustermaxvis0,1);
%     clustermaxvis0(:,checkclus==0) = [];
%     nclustersv = size(clustermaxvis0,1);
% 
%     clustersizes = (sum(clustermaxvis0'>0))';
%     clustermaxvis0(sum(clustermaxvis,2)==0,:) = [];
    
    flaglosmaxvisedges = ~isempty(maxvisedgeset);
    if flaglosmaxvisedges
        clusterid = clusterid+1;
        clustermaxvis0(clusterid,1:length(maxvisedgeset)) = maxvisedgeset;
%        clustermaxvis0 = circshift(clustermaxvis0,[-1 0]);
    end
    if flaglosislands
        clusterid = clusterid+1;
        clustermaxvis0(clusterid,1:length(losislands)) = losislands;
    end
    nclustersv = size(clustermaxvis0,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%    Regroup the current clusters combining any that have an overlap
%%%    greater than threshoverlap = 90%.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%    l2 = losmat0*losmat0;
%    lll = logical(l2.*losmat0);
%    for mm = 1:nclustersv-2
%         pindtmp = clustermaxvis0(mm,clustermaxvis0(mm,:)>0);
%         sizecluster = length(pindtmp);
%         clusterpartlisttmp = [];
%         for kk = 1:sizecluster
%             clusterpartlisttmp = [clusterpartlisttmp pindex(lll(pindtmp(kk),:))];
%         end
%         clusterpartlisttmp = unique(clusterpartlisttmp);
%         sizeclustertmp = length(clusterpartlisttmp);
%         if ~isempty(clusterpartlisttmp)
%             clusterpartlist(mm,1:sizeclustertmp) = clusterpartlisttmp;
%         end
%    end
%    clusteroverl1 = zeros(nclustersv-2,partsize);
%    for mm = 1:nclustersv-2
%        clusteroverl1(mm,clusterpartlist(mm,clusterpartlist(mm,:)>0)) = 1;
%    end
%    clusteroverl2 = clusteroverl1*clusteroverl1';
%    for mm = 1:nclustersv-2
%        clusteroverl2(mm,:) = clusteroverl2(mm,:)/clusteroverl2(mm,mm);
%    end
%    mmm = 0
%    for mm = 1:nclustersv-2
%        clustermix = clusteroverl2(mm,:)>threshoverlap;
%        clustermergelist = pindex(logical(sum(clusteroverl1(clustermix,:))));
%        sizemerge = length(clustermergelist);
%        mmm = mmm+1;
%        clustermerge(mmm,1:sizemerge) = clustermergelist;
%        clusteroverl2(clustermix,:) = 0;
%    end
%    clustermerge(sum(clustermerge,2)==0,:) = [];
% %   clustermaxvis0 = clustermerge;   
%    sizeclustermerge = sum(logical(clustermerge>0),2);
%    [sizeclusm,indclusm] = sort(sizeclustermerge,'descend');
%    clustermerge = clustermerge(indclusm,:);
   
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    clustermaxvis = clustermaxvis0;
    nclustersv = size(clustermaxvis,1);

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%
    %%%%%%%  Find the centers of the dense regions - conngroup are the
    %%%%%%%  connected maxima
    %%%%%%%
    for clusterid = 1:nclustersv
        [clusmed] = findmedoid_03(clustermaxvis(clusterid,:),2);
        clustermedoidsv(clusterid,1) = clusmed;   
    end
    numrollback = flaglosislands+flaglosmaxvisedges;
    for ii = 1:numrollback
        clustermedoidsv(end+1-ii,1) = 0;
    end
%    clustermedoidsv(~checkclussize) = 0;        
    
    %%%%
    %%%%    Plot results from LOS Maximum Visibility Gathering 
    %%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        plotdataname = 'maxvis';
        titleinfo1   = sprintf('%s Clustering into %d Clusters',upper(plotdataname),nclustersv);
        titleinfo2   = 'LOS Gathering by Maximum Visibility';
        datainfoo{1} = { eval(sprintf('cluster%s',plotdataname)) clustermedoidsv };
        figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
        fileinfoo{1} = { figinfo titleinfo1 titleinfo2 };
        flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 1 1};
        plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  PATCHES (CLUSTERS Without clustering - One Big cluster!)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    titlemaxvis           = titleinfo1;
    clustermaxvismut{1,1} = {clustermaxvis};
    clustermaxvismut{1,2} = {clustermedoidsv};
    clustermaxvismut{1,3} = {nclustersv};
    clustermaxvismut{1,4} = {titlemaxvis};

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%       Do mutual visibility clustering
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    clustermaxmut = clustermaxvis;
    checkclussize = (sum(clustermaxvis>0,2)>minpathlprep);
    clustermedoidsv(~checkclussize) = 0;        
    nclustersm    = size(clustermaxmut,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%
%%%%%%%  Find the centers of the dense regions - conngroup are the
%%%%%%%  connected maxima
%%%%%%%
    for clusterid = 1:nclustersm
        [clusmed] = findmedoid_03(clustermaxmut(clusterid,:),2);
        clustermedoidsm(clusterid,1) = clusmed;   
    end    
    clustermedoidsm(end-1,1) = 0;
    clustermedoidsm(end,1)   = 0;
%    clustermedoidsv(~checkclussize) = 0;        
%%%%
%%%%    Plot results from LOS Maximum Mutual Visibility Gathering 
%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        plotdataname = 'maxmut';
        titleinfo1   = sprintf('%s Clustering into %d Clusters',upper(plotdataname),nclustersm);
        titleinfo2   = 'LOS Gathering by Maximum Mutual Visibility';
        datainfoo{1} = { eval(sprintf('cluster%s',plotdataname)) clustermedoidsv };
        figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
        fileinfoo{1} = { figinfo titleinfo1 titleinfo2 };
        flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 1 1};
        plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  PATCHES (CLUSTERS Without clustering - One Big cluster!)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
    titlemaxmut           = titleinfo1;
    clustermaxvismut{2,1} = {clustermaxmut};
    clustermaxvismut{2,2} = {clustermedoidsm};
    clustermaxvismut{2,3} = {nclustersm};
    clustermaxvismut{2,4} = {titlemaxmut};

    maxvismutreturn = {clustermaxvismut};
%%%%
%%%%   Save all of the clusters - Clusters now saved in the "Short" file
%%%%
%     varinfoo = {'clustermaxvis'   savemaxvismut 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
%     varinfoo = {'clustermedoidsv' savemaxvismut 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
%     varinfoo = {'clustermaxmut'   savemaxvismut 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
%     varinfoo = {'clustermedoidsm' savemaxvismut 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
%%%%
%%%%  Compute memory and timing variables for performance
%%%%
    tendmaxvismut = now;
    durationnmaxvismut = tendmaxvismut-tstartmaxvismut;
    display(sprintf('Ending LOS GATHERING Analysis at %s',datestr(datetime('now'))))
    tstartmaxvismutt = datetime(datevec(tstartmaxvismut));
    tendmaxvismutd   = datetime(datevec(tendmaxvismut));
    timemaxvismut = rem(durationnmaxvismut,1)*86400;
    display(sprintf('LOS GATHERING Analysis Duration: %s',datestr(timemaxvismut/86400, 'HH:MM:SS')));

    workspacee = whos;
    memusedmaxvismut = sum([workspacee.bytes]);
%%%%
%%%%   Save all of the variables
%%%%
    varnamess = {varnamesshort{:} varnameslong{:} varnamestime{:}}; 
    for ii = 1:size(varnamess,2); if size(varnamess{ii},2)>0; eval(sprintf('global %s',varnamess{ii})); end; end;
    saverightend01;
    profile off
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
else
    display('LOS GATHERING files already exists and OVERWRITE LOSGATHER set to ZERO.  LOS GATHERING analysis NOT DONE.')
    maxvismutreturn = {1};
end
close all
return 
















