%%%%
%%%%   Clear everything out and set the file root directory (previously set
%%%%        by the clus12_prep.m analysis configurator.  
%%%%   Run clus12_prep.m first.  Then run this program (and wait...)
%%%%
clear all force
clear global all
close all force
global fileroot shapestr prodrunnum prepindex fileprefix dataname 
global sigfigs smallpartnums3 partsize  
global varnamesshort varnameslong varnamestime
load('filerootname.mat')
%    clearvars -except fileroot do* prepindex numprepfiles prepfiles prodrunnum prepindexstart prepindexend tstartfull tstartsingle 
%%%%
%%%%   Initialize the Analysis
%%%%        1) Select an analysis production run number
%%%%        2) Select a specific analysis within the production group
%%%%            a) Setting runone =  xxx selects a single run with index = runone
%%%%            b) Setting runone = -xxx selects a set of runs beginning with index = runone
%%%%
% prodrunnum = 0375;  % 200 res  min pop=0   %0% data cut    %k=16%
  prodrunnum = 0401;  % 200 res  min pop=3   %2% data cut    %k=16%
% prodrunnum = 0402;  % 100 res  min pop=0   %2% data cut    %k=16%
% prodrunnum = 0403;   %100 res  min pop=0   %5% data cut    %k=16%
% prodrunnum = 0404;   %100 res  min pop=0  %10% data cut    %k=16%
% prodrunnum = 0405;   %60  res  min pop=0  %2% data cut - SPECTRAL test    %k=16%
% prodrunnum = 0406;   %40  res  min pop=0  %2% data cut - SPECTRAL test    %k=16%
% prodrunnum = 0407;  % 200 res  min pop=0   %0% data cut    %k=16%
% prodrunnum = 0408;  % 200 res  min pop=0   %3% data cut    %k=16%
% prodrunnum = 0409;  % 200 res  min pop=0   %0% data cut    %k=6%
  prodrunnum = 0410;  % 100 res  min pop=3   %2% data cut    %k=16%


tstartfull = now;
prepfiles = ls(sprintf('%s/_DATA/prod/prod_prep_%04d_*',fileroot,prodrunnum));
numprepfiles = size(prepfiles,1);
runone =   2;
if runone>0
    prepindexstart = runone;
    prepindexend   = runone;
else
    prepindexstart = -runone;
    prepindexend   = numprepfiles;
end
%%%%
%%%%    Set fileprefixes for saving files
%%%%
load(sprintf('%s/_DATA/prod/%s',fileroot,prepfiles(prepindexstart,:)));
datacode = sprintf('%01d%01d%01d%01d%01d%01d%01d%01d%01d%01d%01d%0d',dataorder(1),dataorder(2),dataorder(3),dataorder(4),dataorder(5),dataorder(6),dataorder(7),dataorder(8),dataorder(9),dataorder(10),dataorder(11),dataorder(12));
fileprefix = sprintf('%s_%03d_%03d_%12d',shapestr,basebins,minpop,eval(datacode));
fileprefix = sprintf('%s_%03d',shapestr,basebins);
diary on
diary(sprintf('%s/_DATA/%s/prod_%04d_diary_%s_s.txt',fileroot,shapestr,prodrunnum,fileprefix))
display(sprintf('Starting Analysis at %s',datestr(datetime('now'))))

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%  Main Data Production Loop over all Analysis Configurions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for prepindex = prepindexstart:prepindexend
    clearvars -global -except fileroot shapestr prodrunnum prepindex dataname sigfigs smallpartnums3 varnamesshort varnameslong varnamestime
    tstartsingle = now;
    load(sprintf('%s/_DATA/prod/%s',fileroot,prepfiles(prepindex,:)));
    display(sprintf('Prepindex: %d   Shape: %s',prepindex,shapestr));

    doinitialize = 0;
    doLMHpos     = 0;
    dokmeanmeds  = 0;
    domaxglobal  = 0;
    doconnpathl  = 0;
    domaxpathl   = 0;
    doLOS        = 0;
    domaxvismut  = 1;
    dospectral   = 0;
    dorobust     = 0;
    doplots      = 0;

%%% Initialize the cluster analysis - calculate all of the major arrays    
    if doinitialize;
        returninit       = clus16_initialize;
    end
%%%% LMHpos clustering    
    if doLMHpos;
        returnLMHpos     = clus16_LMHpos;
        clustertot{1}    = returnLMHpos;
    end
%%%% Kmeans and Kmedoids clustering    
    if dokmeanmeds;
        returnkmeanmeds  = clus16_kmeanmeds;
        clustertot{2}    = returnkmeanmeds;
    end
%%%% Maximum GLOBAL clustering    
    if domaxglobal;
        returnmaxglobal  = clus16_maxglobal;
        clustertot{3}    = returnmaxglobal;
    end
%%%% Calculate the CONN matrix as well as all pathlengths (uses Dijkstra's once Stepwise)    
    if doconnpathl;
        returnconnpathl  = clus16_connpathl;
        clustertot{4}    = returnconnpathl;
    end
%%%% Maximum PathL clustering        
    if domaxpathl;
        returnmaxpathl   = clus16_maxpathl;
    end
%%%% Calculates the LOS matrix (uses Dijkstra's twice - Pathwise)    
    if doLOS;
        returnLOS        = clus16_LOS;
    end
%%%% Find the LOS clusters for Maximum Visibility or Greatest Mutual Visibility    
    if domaxvismut;
        returnmaxvismut  = clus16_maxvismut6_v16;
        clustertot{5}    = returnmaxvismut;        
    end
%%%% Spectral Clustering - 18 variants - uses NN1, LOS and Gaussian as basis for Laplacian    
    if dospectral;      
        returnspectral   = clus16_spectral;
        clustertot{6}    = returnspectral;
    end
%%%% Robust Clustering - mainly through consensus   
    if dorobust;
        global clustertot
        returnrobust     = clus16_robust;
    end
%%%% Plot the results all together - note that each clustering routine also plots.
%%%% This routine is when all clustering routines have been completed and
%%%% you simply wish to re-plot all of the results without recomputing the
%%%% clusters.
    if doplots;
       returnplots      = clus16_plots;
    end
%
%   Calculate timing of a single analysis for perfomance stats
%
    tendsingle = now;
    durationnsingle = tendsingle-tstartsingle;
    display(sprintf('Single Analysis Ending at %s',datestr(datetime('now'))))
    tstartsinglet = datetime(datevec(tstartsingle));
    tendsingled   = datetime(datevec(tendsingle));
    timeanalysis = rem(durationnsingle,1)*86400;
    display(sprintf('Single Analysis Duration: %s',datestr(timeanalysis/86400, 'HH:MM:SS')));
    save(sprintf('%s/_DATA/prod/prod_final_single_%04d_%04d.mat',fileroot,prodrunnum,prepindex),'prodrunnum','prepindex','durationnsingle','timeanalysis','tstartsinglet','tendsingled')
end
%
%   Calculate timing for full analysis for perfomance stats
%
tendfull = now;
durationnfull = tendfull-tstartfull;
display(sprintf('Full Analysis Ending at %s',datestr(datetime('now'))))
tstartfullt = datetime(datevec(tstartfull));
tendfulld   = datetime(datevec(tendfull));
timeanalysis = rem(durationnfull,1)*86400;
display(sprintf('Full Analysis Duration: %s',datestr(timeanalysis/86400, 'HH:MM:SS')));
save(sprintf('%s/_DATA/prod/prod_final_%04d.mat',fileroot,prodrunnum),'prodrunnum','durationnfull','timeanalysis','tstartfullt','tendfulld')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%
%%%%   Save all of the variables
%%%%   The routine for saving expects three cell structures:
%%%%   varnamestime:  The times  associated with the clustering algorithm
%%%%   varnamesshort: All variables associated with the algorithm that are
%%%%                  small in memory usage
%%%%   varnameslong:  All variables that use significant memory and need to
%%%%                  be saved in individual files.
%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%clear global varnamesshort varnamestime varnameslong
dataname        = 'full';
varnamestime    = {'timesingle','tstartsinglet','tendsingled','timefull','tstartfullt','tendfulld'};
varnamesshort1  = {'returnkmeans','returnkmedoids'};
varnamesshort2  = {'returnmaxglobal'};
varnamesshort3  = {'returnconn'};
varnamesshort4  = {'returnmaxpathl'};
varnamesshort5  = {'returnmaxvis','returnmaxmut'};
varnamesshort6  = {'returnspectral01','returnspectral02','returnspectral03','returnspectral04','returnspectral05','returnspectral06','returnspectral07','returnspectral08','returnspectral09','returnspectral10','returnspectral11','returnspectral12','returnspectral13','returnspectral14','returnspectral15','returnspectral16','returnspectral17','returnspectral18',};
varnamesshort7  = {'returnlmhpos'};
varnamesshort8  = {'returnrobust1','returnrobust2','returnrobust3','returnrobust4'};
varnamesshort9  = {'returnplots'};
varnamesshort   = {varnamesshort1{:} varnamesshort2{:} varnamesshort3{:} varnamesshort4{:} varnamesshort5{:} varnamesshort6{:} varnamesshort7{:} varnamesshort8{:} varnamesshort9{:}}; 
varnameslong    = {''};
varnamess = {varnamesshort{:} varnameslong{:} varnamestime{:}}; 
for ii = 1:size(varnamess,2); if size(varnamess{ii},2)>0; eval(sprintf('global %s',varnamess{ii})); end; end;
saverightend01;
profile off


diary off


% %%%  Overwriting the "do" variables from the production preparation code
% %%%  which allows the user to set which algorithms are calculated for this
% %%%  pass

