function [ plotsreturn ] = clus16_plots(varargin)
close all force
profile off
warning off
global fileroot shapestr prodrunnum prepindex fileprefix dataname 
global sigfigs smallpartnums3 partsize  
global dataptsminmax dataptspartkeep dataindexminmax dataindexpartkeep datapartkeepindex dataminmaxpartindex binadd2 datamin datamax datadelta 
global varnamesshort varnameslong varnamestime
varnamesshort = {'memusedplots'};
varnameslong  = {''};
varnamestime  = {'timeplots','tstartplotst','tendplotsd'};
dataname      = 'plots';

load(sprintf('%s/_DATA/prod/prod_prep_%04d_%04d.mat',fileroot,prodrunnum,prepindex));
display(sprintf('%04d - %s - Calculate PLOTS',prodrunnum,fileprefix))
% nvars = 2;
% if (shapeindex==13)|(shapeindex==14); nvars = 3; end
% if (shapeindex<=10); userminmax = 1; end
% if (shapeindex==4); userminmax = 0; end
% if (nvars==2); dataorder(3) = 0; end
% realdata = strcmp(shapestr(1:min([max(size(shapestr)) 4])),'data');
% display(sprintf('EI        Names:  alpha rroc vfast vslow velasym beta betaang ke omega ow qcriterion sigma'));
% display(sprintf('EI ordering now: [  %d    %d     %d     %d      %d     %d      %d     %d    %d   %d     %d        %d  ]',dataorder(1),dataorder(2),dataorder(3),dataorder(4),dataorder(5),dataorder(6),dataorder(7),dataorder(8),dataorder(9),dataorder(10),dataorder(11),dataorder(12)));
% datacode = sprintf('%01d%01d%01d%01d%01d%01d%01d%01d%01d%01d%01d%0d',dataorder(1),dataorder(2),dataorder(3),dataorder(4),dataorder(5),dataorder(6),dataorder(7),dataorder(8),dataorder(9),dataorder(10),dataorder(11),dataorder(12));
% nvars = sum(dataorder~=0);
% fileprefix = sprintf('%s_%03d_%03d_%12d',shapestr,basebins,minpop,eval(datacode));

tstartplots = now;
%profile on
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
%%%%%%%%%%% INIT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'dataptsminmax';
    loadname     = 'init';
    if ~exist(plotdataname)|isempty(eval(plotdataname))
        loadname = plotvars{mod(find(ismember(plotvars,sprintf('%s',plotdataname))),size(plotvars,1)),1};
        varinfoo = {loadname,sprintf('''%s''',plotdataname)}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end
        varinfoo = {loadname,'''full'''}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end    
    end
    varinfoo = {loadname,'''short'''}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end    
    datapartitions = unique(dataindexminmax,'rows')-1;
    npartitions = max(size(datapartitions));
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    titleinfo1   = sprintf('For %d of Raw Data - Number of Partitions = %d',sizedataraw,npartitionsr);
    titleinfo2   = sprintf('');
    datainfoo{1} = { eval(plotdataname) };
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 };
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) plotnow 1 0 1 };
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  SCATTER
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'binaddu';
    if ~exist(plotdataname)|isempty(eval(plotdataname))
        loadname = plotvars{mod(find(ismember(plotvars,sprintf('%s',plotdataname))),size(plotvars,1)),1};
        varinfoo = {loadname,sprintf('''%s''',plotdataname)}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end 
        varinfoo = {loadname,'''full'''}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end 
    end
    binwgtp = (0.5:max(wgtp)+0.5)';
    [histwgtp]= histcounts(wgtp,binwgtp);
    binwgtp = ceil(binwgtp); binwgtp(end) = [];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    barmax       = min([max(size(binaddu)) smallpartnums3]);
    barmax       = min([max(size(binaddu))]);
    plotdataname = 'binaddu';
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    titleinfo1   = 'Unique Partition Bin Addresses vs Populations (Weights)';
    titleinfo2   = sprintf('');
    xlabel1      = 'Bin Addresses';
    xlabel2      = 'Populations';
    datainfoo{1} = { binaddu(1:barmax) wgtp(1:barmax) };
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 xlabel1 xlabel2};
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 };
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  HISTOGRAM
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    barmax       = min([max(size(binaddu)) smallpartnums3]);
    barmax       = max(wgtp)+1;
    plotdataname = 'wgtp';
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    titleinfo1   = 'Unique Partition Bin Addresses vs Populations (Weights)';
    titleinfo2   = sprintf('');
    xlabel1      = 'Bin Addresses';
    xlabel2      = 'Populations';
    datainfoo{1} = { binwgtp histwgtp };
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 xlabel1 xlabel2};
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 };
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  HISTOGRAM
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'deltaxl1';
    if ~exist(plotdataname)|isempty(eval(plotdataname))
        loadname = plotvars{mod(find(ismember(plotvars,sprintf('%s',plotdataname))),size(plotvars,1)),1};
        varinfoo = {loadname,sprintf('''%s''',plotdataname)}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end  
        varinfoo = {loadname,'''full'''}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end    
    end
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    titleinfo1   = sprintf('Sum of abs(Delta X) ');
    titleinfo2   = sprintf('');
    xlabel1      = 'Partition #';
    xlabel2      = 'Partition #';
    datainfoo{1} = { eval(plotdataname) };
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 xlabel1 xlabel2};
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) plotnow 1 1 };
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  SURFACE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'nn1';
    if ~exist(plotdataname)|isempty(eval(plotdataname))
        loadname = plotvars{mod(find(ismember(plotvars,sprintf('%s',plotdataname))),size(plotvars,1)),1};
        varinfoo = {loadname,sprintf('''%s''',plotdataname)}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end    
        varinfoo = {loadname,'''full'''}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end    
    end
    nn1(1:partsize+1:end) = 1/bignum;
    nn1perm = nn1(ppnn1c,qqnn1c);
    nn1(1:partsize+1:end) = 0;
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    titleinfo1   = sprintf('First Nearest Neighbor matrix - NN1');
    titleinfo2   = sprintf('');
    xlabel1      = 'Partition #';
    xlabel2      = 'Partition #';
    datainfoo{1} = { eval(plotdataname) };
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 xlabel1 xlabel2};
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) plotnow 1 0 };
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  SPY
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'nn1perm';
    if ~exist(plotdataname)|isempty(eval(plotdataname))
        loadname = plotvars{mod(find(ismember(plotvars,sprintf('%s',plotdataname))),size(plotvars,1)),1};
        varinfoo = {loadname,sprintf('''%s''',plotdataname)}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end    
        varinfoo = {loadname,'''full'''}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end    
    end
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    titleinfo1   = sprintf('First Nearest Neighbor matrix - NN1 (permuted)');
    titleinfo2   = sprintf('');
    xlabel1      = 'Partition #';
    xlabel2      = 'Partition #';
    datainfoo{1} = { eval(plotdataname) };
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 xlabel1 xlabel2};
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) plotnow 1 0 };
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  SPY
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'deltar';
    if ~exist(plotdataname)|isempty(eval(plotdataname))
        loadname = plotvars{mod(find(ismember(plotvars,sprintf('%s',plotdataname))),size(plotvars,1)),1};
        varinfoo = {loadname,sprintf('''%s''',plotdataname)}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end    
        varinfoo = {loadname,'''full'''}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end    
    end
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    titleinfo1   = sprintf('Euclidean Distance - \\Delta r - from (k,l)');
    titleinfo2   = sprintf('');
    xlabel1      = 'Partition #';
    xlabel2      = 'Partition #';
    datainfoo{1} = { eval(plotdataname) };
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 xlabel1 xlabel2};
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) plotnow 1 1 };
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  SURFACE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'pathltrue';
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    titleinfo1   = sprintf('True Path Length from (k,l)');
    titleinfo2   = sprintf('');
    xlabel1      = 'Partition #';
    xlabel2      = 'Partition #';
    datainfoo{1} = { eval(plotdataname) };
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 xlabel1 xlabel2};
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) plotnow 1 1 };
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  SURFACE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'pathl1true';
    if ~exist(plotdataname)|isempty(eval(plotdataname))
        loadname = plotvars{mod(find(ismember(plotvars,sprintf('%s',plotdataname))),size(plotvars,1)),1};
        varinfoo = {loadname,sprintf('''%s''',plotdataname)}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end    
        varinfoo = {loadname,'''full'''}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end    
    end
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    titleinfo1   = sprintf('True Path Length (L1) from (k,l)');
    titleinfo2   = sprintf('');
    xlabel1      = 'Partition #';
    xlabel2      = 'Partition #';
    datainfoo{1} = { eval(plotdataname) };
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 xlabel1 xlabel2};
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) plotnow 1 1 };
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  SURFACE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'pathcount';
    if ~exist(plotdataname)|isempty(eval(plotdataname))
        loadname = plotvars{mod(find(ismember(plotvars,sprintf('%s',plotdataname))),size(plotvars,1)),1};
        varinfoo = {loadname,sprintf('''%s''',plotdataname)}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end    
        varinfoo = {loadname,'''full'''}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end    
    end
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    titleinfo1   = sprintf('Path Count (# of neighborhoods) from (k,l)');
    titleinfo2   = sprintf('');
    xlabel1      = 'Partition #';
    xlabel2      = 'Partition #';
    datainfoo{1} = { eval(plotdataname) };
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 xlabel1 xlabel2};
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) plotnow 1 1 };
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  SURFACE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'dataptsminmax';
    if ~exist(plotdataname)|isempty(eval(plotdataname))
        loadname = plotvars{mod(find(ismember(plotvars,sprintf('%s',plotdataname))),size(plotvars,1)),1};
        varinfoo = {loadname,sprintf('''%s''',plotdataname)}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
        varinfoo = {loadname,'''short'''}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
        varinfoo = {loadname,'''full'''};  loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
    end
    titleinfo1   = sprintf('For %d of Processed Data - Final Number of Partitions = %d',sizedatagood,partkeepnum);
    titleinfo2   = '';
    datainfoo{1} = { eval(plotdataname) };
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    datainfoo{1} = { 1 };                                   %  When displaying patches without clusters, just assign one cluster
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 };
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) plotnow 0 1 0};
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  PATCHES (CLUSTERS Without clustering - One Big cluster!)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%  LMHpos
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'LMHpos';
%    plotdataname = sprintf('cluster%s',plotdataname);
    if ~exist(plotdataname)|isempty(eval(plotdataname))
        loadname = plotvars{mod(find(ismember(plotvars,plotdataname)),size(plotvars,1)),1};
        varinfoo = {loadname,'''short'''}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
        varinfoo = {loadname,'''full'''};  loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
    end
    global binadd2LMH datadeltaLMH partsizeLMH
    plotdataname = 'LMHpos';
    dataname     = plotdataname;
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    titleinfo1   = sprintf('%s Clustering into %d Clusters',upper(plotdataname),nclustersh);
    titleinfo2   = sprintf('');
    datainfoo{1} = { eval(sprintf('cluster%s',plotdataname)) clustermedoidsh};
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 };
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 1 plotmedoidsr};
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  SCATTER
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%     plotdataname = 'dataptsminmax';
%     loadname     = 'init';
%         varinfoo = {loadname,sprintf('''%s''',plotdataname)}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
%         varinfoo = {loadname,'''full'''};  loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
%     plotdataname = 'binnadd2';
%     loadname     = 'init';
%         varinfoo = {loadname,sprintf('''%s''',plotdataname)}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
%         varinfoo = {loadname,'''full'''};  loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
%     
%     loadname     = 'kmeanmeds';
%         varinfoo = {loadname,'''short'''}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
%         varinfoo = {loadname,'''full'''};  loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%  Kmeans Kmedoids
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'kmeans';
    plotdataname = sprintf('cluster%s',plotdataname);
    if ~exist(plotdataname)|isempty(eval(plotdataname))
        loadname = plotvars{mod(find(ismember(plotvars,plotdataname)),size(plotvars,1)),1};
        varinfoo = {loadname,'''short'''}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
        varinfoo = {loadname,'''full'''};  loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
    end
            plotdataname = 'kmeans';
            dataname     = plotdataname;
            figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s_%d.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname,kloop);
            titleinfo1   = sprintf('%s Clustering into %d Clusters    Mode= %d',upper(plotdataname),nclustersn,kloop);
            titleinfo2   = sprintf('');
            datainfoo{1} = { eval(sprintf('cluster%s',plotdataname)) clustermedoidsn};
            fileinfoo{1} = { figinfo titleinfo1 titleinfo2 };
            flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 1 plotmedoidsc};
            plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  CLUSTER
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            plotdataname = 'kmedoids';
            dataname     = plotdataname;
%            plotdataname = sprintf('cluster%s',plotdataname);
            figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s_%d.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname,kloop);
            titleinfo1   = sprintf('%s Clustering into %d Clusters    Mode= %d',upper(plotdataname),nclustersn,kloop);
            titleinfo2   = sprintf('');
            datainfoo{1} = { eval(sprintf('cluster%s',plotdataname)) clustermedoidsd};
            fileinfoo{1} = { figinfo titleinfo1 titleinfo2 };
            flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 1 plotmedoidsc};
            plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  CLUSTER
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%  Max Global    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'maxglobal';
    plotdataname = sprintf('cluster%s',plotdataname);
    if ~exist(plotdataname)|isempty(eval(plotdataname))
        loadname = plotvars{mod(find(ismember(plotvars,plotdataname)),size(plotvars,1)),1};
        varinfoo = {loadname,'''short'''}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
        varinfoo = {loadname,'''full'''};  loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
    end
    plotdataname = 'maxglobal';
    dataname     = plotdataname;
    titleinfo1   = sprintf('%s Clustering into %d Clusters',upper(plotdataname),nclustersg);
    titleinfo2   = '';
    datainfoo{1} = { eval(sprintf('cluster%s',plotdataname)) clustermedoidsg };
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 };
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 1 plotmedoidsc};
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  PATCHES (CLUSTERS Without clustering - One Big cluster!)
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
%         
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Connection   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'connmat';
    if ~exist(plotdataname)|isempty(eval(plotdataname))
        loadname = plotvars{mod(find(ismember(plotvars,sprintf('%s',plotdataname))),size(plotvars,1)),1};
        varinfoo = {loadname,sprintf('''%s''',plotdataname)}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
        varinfoo = {loadname,'''short'''}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
        varinfoo = {loadname,'''full'''};  loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
    end
    connperm = connmat(ppc,qqc);
    plotdataname = 'connperm';
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    titleinfo1   = sprintf('Connection Matrix (permuted) - from (k,l)');
    titleinfo2   = sprintf('');
    xlabel1      = 'Partition #';
    xlabel2      = 'Partition #';
    datainfoo{1} = { eval(plotdataname) };
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 xlabel1 xlabel2};
    flaginfoo{1} = { plotconn plotnow 1 0 };
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  SPY
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'conn';
    plotdataname = sprintf('cluster%s',plotdataname);
    if ~exist(plotdataname)|isempty(eval(plotdataname))
        loadname = plotvars{mod(find(ismember(plotvars,plotdataname)),size(plotvars,1)),1};
        varinfoo = {loadname,'''short'''}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
        varinfoo = {loadname,'''full'''};  loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
    end
    plotdataname = 'conn';
    dataname     = plotdataname;
    plotdataname = 'conn';
    titleinfo1   = sprintf('%s Clustering into %d Clusters',upper(plotdataname),nclustersc);
    titleinfo2   = '';
    datainfoo{1} = { eval(sprintf('cluster%s',plotdataname)) clustermedoidsc };
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 };
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 1 plotmedoidsc};
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  PATCHES (CLUSTERS Without clustering - One Big cluster!)
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%         
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%  Max Path Length   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'maxpathl';
    plotdataname = sprintf('cluster%s',plotdataname);
    if ~exist(plotdataname)|isempty(eval(plotdataname))
        loadname = plotvars{mod(find(ismember(plotvars,plotdataname)),size(plotvars,1)),1};
        varinfoo = {loadname,'''short'''}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
        varinfoo = {loadname,'''full'''};  loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
    end
    plotdataname = 'maxpathl';
    dataname     = plotdataname;
    plotdataname = 'maxpathl';
    titleinfo1   = sprintf('%s Clustering into %d Clusters',upper(plotdataname),nclustersp);
    titleinfo2   = '';
    datainfoo{1} = { eval(sprintf('cluster%s',plotdataname)) clustermedoidsp };
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 };
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 1 plotmedoidsc};
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  PATCHES (CLUSTERS Without clustering - One Big cluster!)
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%        
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   LOS     
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'connmat';
    if ~exist(plotdataname)|isempty(eval(plotdataname))
        loadname = plotvars{mod(find(ismember(plotvars,sprintf('%s',plotdataname))),size(plotvars,1)),1};
        varinfoo = {loadname,sprintf('''%s''',plotdataname)}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
        varinfoo = {loadname,'''short'''}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
        varinfoo = {loadname,'''full'''};  loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
    end
    plotdataname = 'losmat';
    if ~exist(plotdataname)|isempty(eval(plotdataname))
        loadname = plotvars{mod(find(ismember(plotvars,sprintf('%s',plotdataname))),size(plotvars,1)),1};
        varinfoo = {loadname,sprintf('''%s''',plotdataname)}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
        varinfoo = {loadname,'''short'''}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
        varinfoo = {loadname,'''full'''};  loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
    end
%     connpermlos = connmat(ppl,qql);  
%     plotdataname = 'connpermlos';
%     dataname     = plotdataname;
%     figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
%     titleinfo1   = sprintf('Connection Matrix (permuted using LOSmat) - from (k,l)');
%     titleinfo2   = sprintf('');
%     xlabel1      = 'Partition #';
%     xlabel2      = 'Partition #';
%     datainfoo{1} = { eval(plotdataname) };
%     fileinfoo{1} = { figinfo titleinfo1 titleinfo2 xlabel1 xlabel2};
%     flaginfoo{1} = { plotconn plotnow 1 0 };
%     plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  SPY
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'losmat';
    dataname     = plotdataname;
    if ~exist(plotdataname)|isempty(eval(plotdataname))
        loadname = plotvars{mod(find(ismember(plotvars,sprintf('%s',plotdataname))),size(plotvars,1)),1};
        varinfoo = {loadname,sprintf('''%s''',plotdataname)}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
        varinfoo = {loadname,'''short'''}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
        varinfoo = {loadname,'''full'''};  loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
    end
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    titleinfo1   = sprintf('Line-Of-Sight Matrix - LOS - from (k,l)');
    titleinfo2   = sprintf('');
    xlabel1      = 'Partition #';
    xlabel2      = 'Partition #';
    datainfoo{1} = { eval(plotdataname) };
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 xlabel1 xlabel2};
    flaginfoo{1} = { plotLOS plotnow 1 0 };
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  SPY
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
%%%%%%%%%%%%%%%%%%%%%%   LOS Maximal/Mutal Visibility    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'maxvis';
    plotdataname = sprintf('cluster%s',plotdataname);
    if ~exist(plotdataname)|isempty(eval(plotdataname))
        loadname = plotvars{mod(find(ismember(plotvars,plotdataname)),size(plotvars,1)),1};
        varinfoo = {loadname,'''short'''}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
        varinfoo = {loadname,'''full'''};  loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
    end
    plotdataname = 'maxvis';
    dataname     = plotdataname;
    extrainfo    = sprintf('');
%    extrainfo    = sprintf('__%4.2f__%4.2f__%4.2f__%d__%d',threshoverlap0,threshoverlap2,threshoverlap3,threshtype,navgpts);
    titleinfo1   = sprintf('%s Clustering into %d Clusters%s',upper(plotdataname),nclustersv,extrainfo);
    titleinfo2   = 'LOS Gathering by Maximum Visibility';
    datainfoo{1} = { eval(sprintf('cluster%s',plotdataname)) clustermedoidsv };
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname,extrainfo);
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2};
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 1 plotmedoidsr};
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  PATCHES (CLUSTERS Without clustering - One Big cluster!)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'maxmut';
    plotdataname = sprintf('cluster%s',plotdataname);
    if ~exist(plotdataname)|isempty(eval(plotdataname))
        loadname = plotvars{mod(find(ismember(plotvars,plotdataname)),size(plotvars,1)),1};
        varinfoo = {loadname,'''short'''}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
        varinfoo = {loadname,'''full'''};  loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
    end
    plotdataname = 'maxmut';
    dataname     = plotdataname;
    titleinfo1   = sprintf('%s Clustering into %d Clusters',upper(plotdataname),nclustersm);
    titleinfo2   = 'LOS Gathering by Maximum Mutual Visibility';
    datainfoo{1} = { eval(sprintf('cluster%s',plotdataname)) clustermedoidsm };
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 };
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 1 plotmedoidsr};
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  PATCHES (CLUSTERS Without clustering - One Big cluster!)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   Spectral Clustering    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'spectral01';
    plotdataname = sprintf('cluster%s',plotdataname);
    if ~exist(plotdataname)||isempty(eval(plotdataname))
        loadname = plotvars{mod(find(ismember(plotvars,plotdataname)),size(plotvars,1)),1};
        varinfoo = {loadname,'''short'''}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
        varinfoo = {loadname,'''full'''};  loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
    end
    for jj = 1:size(clusterspectral,1) 
        tmpp = clusterspectral{jj,1};
        varnames=sprintf('clusterspectral%02d',jj);
        eval(sprintf('%s=cell2mat(tmpp);',varnames));
    end
    for jj = 1:size(clusterspectral,1) 
        tmpp = clusterspectral{jj,2};
        varnames=sprintf('clustermedoidss%02d',jj);
        eval(sprintf('%s=cell2mat(tmpp);',varnames));
    end
    for jj = 1:size(clusterspectral,1) 
        tmpp = clusterspectral{jj,3};
        varnames=sprintf('nclusterss%02d',jj);
        eval(sprintf('%s=cell2mat(tmpp);',varnames));
    end
    for jj = 1:size(clusterspectral,1) 
        tmpp = clusterspectral{jj,4};
        varnames=sprintf('titlespectral%02d',jj);
        eval(sprintf('%s=cell2mat(tmpp);',varnames));
    end
    for spectralid = 1:size(clusterspectral,1)
        plotdataname = sprintf('spectral%02d',spectralid);
        dataname     = plotdataname;
        eval(sprintf('titleinfo1 = titlespectral%02d;',spectralid));
        titleinfo2   = '';
        datatmp      = eval(sprintf('cluster%s',plotdataname));
        datatmp2     = eval(sprintf('clustermedoidss%02d',spectralid));
        datainfoo{1} = { datatmp datatmp2 };
        figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
        fileinfoo{1} = { figinfo titleinfo1 titleinfo2 };
        flaginfoo{1} = { plotspectral printspectral plotnow 1 1 plotmedoidsr};
        plotviewer01(datainfoo,fileinfoo,flaginfoo);   
    end
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%   Robust Plotting
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'robust1';
    plotdataname = sprintf('cluster%s',plotdataname);
    if ~exist(plotdataname)|isempty(eval(plotdataname))
        loadname = plotvars{mod(find(ismember(plotvars,plotdataname)),size(plotvars,1)),1};
        varinfoo = {loadname,'''short'''}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
        varinfoo = {loadname,'''full'''};  loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright{jj}=[]; end    
    end
     for jj = 1:size(clusterrobust,1) 
        tmpp = clusterrobust{jj,1};
        varnames=sprintf('clusterrobust%1d',jj);
        eval(sprintf('%s=cell2mat(tmpp);',varnames));
    end
    for jj = 1:size(clusterrobust,1) 
        tmpp = clusterrobust{jj,2};
        varnames=sprintf('clustermedoidsr%1d',jj);
        eval(sprintf('%s=cell2mat(tmpp);',varnames));
    end
    for jj = 1:size(clusterrobust,1) 
        tmpp = clusterrobust{jj,3};
        varnames=sprintf('nclustersr%1d',jj);
        eval(sprintf('%s=cell2mat(tmpp);',varnames));
    end
    for jj = 1:size(clusterrobust,1) 
        tmpp = clusterrobust{jj,4};
        varnames=sprintf('titlerobust%1d',jj);
        eval(sprintf('%s=cell2mat(tmpp);',varnames));
    end
    for robustid = 1:size(clusterrobust,1)
        plotdataname = sprintf('robust%1d',robustid);
        dataname     = plotdataname;
        eval(sprintf('titleinfo1 = titlerobust%1d;',robustid));
        titleinfo2   = '';
        datatmp      = eval(sprintf('cluster%s',plotdataname));
        datatmp2     = eval(sprintf('clustermedoidsr%1d',robustid));
        datainfoo{1} = { datatmp datatmp2 };
        figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
        fileinfoo{1} = { figinfo titleinfo1 titleinfo2 };
        flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 1 plotmedoidsr};
        checkdatainfoo = cell2mat(datainfoo{1}(1));
        if checkdatainfoo(1,1)~=0
            plotviewer01(datainfoo,fileinfoo,flaginfoo);  
        end
    end
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%
%%%%%       Done Plotting 
%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotsreturn = {1};
%%%%
%%%%  Compute memory and timing variables for performance
%%%%
    tendplots = now;
    durationnplots = tendplots-tstartplots;
    display(sprintf('Ending Plots at %s',datestr(datetime('now'))))
    tstartplotst = datetime(datevec(tstartplots));
    tendplotsd   = datetime(datevec(tendplots));
    timeplots = rem(durationnplots,1)*86400;
    display(sprintf('Plotting Duration: %s',datestr(timeplots/86400, 'HH:MM:SS')));

    workspacee = whos;
    memusedplots = sum([workspacee.bytes]);
%%%%
%%%%   Save all of the variables
%%%%
    varnamess = {varnamestime{:}}; 
    for ii = 1:size(varnamess,2); eval(sprintf('global %s',varnamess{ii}));  end;
    saverightend01;
    profile off
    
close all
return 


