function [ LOSreturn ] = clus16_LOS(varargin)
close all force
profile off
warning off
global fileroot shapestr prodrunnum prepindex fileprefix dataname 
global sigfigs smallpartnums3 partsize  
global dataptsminmax dataptspartkeep dataindexminmax dataindexpartkeep datapartkeepindex dataminmaxpartindex binadd2 datamin datamax datadelta 
global varnamesshort varnameslong varnamestime
varnamesshort = {'bignum','sigfigs','minpop','minpathl','threshdist','nvars','databins','datadelta','datamax','datamin','shapestr','partsize','partkeep','partkeepind','ppl','qql','rrl','ssl','ttl','uul','memusedlos'};
varnameslong  = {'losmat','sdeltax'};
varnamestime  = {'timelos','tstartlost','tendlosd'}';
dataname      = 'LOS';

load(sprintf('%s/_DATA/prod/prod_prep_%04d_%04d.mat',fileroot,prodrunnum,prepindex));
fprintf('%04d - %s - Calculate LOS\n',prodrunnum,fileprefix)

checkfilelos0 = ls(sprintf('%s/_DATA/%s/prod_%04d_%s_%s_*.mat',fileroot,shapestr,prodrunnum,dataname,fileprefix));
checkfilelos  = logical(size(checkfilelos0,2));
if checkfilelos
   display('LOS clustering already done.');
end
checkgolos =  (~(checkfilelos&(~checkoverwriteLOS)))&(~checkreLOS);
if checkgolos             % GO!!!!!!!
    display(sprintf('LOS files:  %1d OVERWRITE LOS:  %1d   LOS analysis will be DONE.',checkfilelos,checkoverwriteLOS));

    tstartlos = now;
    timelos0 = 0;
    tic
    %profile on
    loadname = 'init'; 
    varinfoo = {loadname,'''-regexp'',''^(?!deltar|dircos|pathl|pathlcount|pathcount|pathl1corr|dataindexminmax|dataptsminmax)\w'''};
    loadright1 = loadright03(varinfoo); 
    for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); 
        for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); 
        end; loadright1{jj}=[]; 
    end
%    wgtmat = partkeepwgts*partkeepwgts';

    bignum2 = bignum/10^3;
    checkLOShold1 = exist(sprintf('%s/_DATA/%s/prod_%04d_LOShold_%s.mat',fileroot,shapestr,prodrunnum,fileprefix));
    checkLOShold2 = exist(sprintf('%s/_DATA/%s/prod_%04d_LOShold_%s_full.mat',fileroot,shapestr,prodrunnum,fileprefix));
    if(checkLOShold1|checkLOShold2)
        loadname = 'LOShold'; 
        varinfoo = {loadname,''''''};
        loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end
        timelos0 = timelos;
        display(sprintf('Broken in the middle, continuing at kk = %05d     and   timelos = %f',kk,timelos0));
    else
        if plotall2==1
            plotLOS = 1;
            plotconn = 1;
        end
        if(partsize<=12)
           nn1
        end
%        sdeltax    = ones(partsize)/bignum2;
        sdeltax    = zeros(partsize);
        nn1sdc     = zeros(partsize);
        kk = 1;
    end
    loadname = 'connpathl'; 
    varinfoo = {loadname,'''pathcheck'''};
    loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end

    nn1(1:partsize+1:end) = 0;
    nn1uw = sparse(logical(nn1));
    clear nn1
    while kk<=partsize
%        deltaxl1i   = repmat(deltaxl1(kk,:),partsize,1);
        deltaxl1i   = repmat((deltaxl1(kk,:).*pathcheck(kk,:)),partsize,1);
%        deltaxl1i   = repmat(abs(deltaxl1(kk,:)-pathl1true(kk,:)).*pathcheck(kk,:),partsize,1);
        nn1sdc    = nn1uw.*deltaxl1i;
        clear deltaxl1i
%        for ii = 1:partsize
%           nn1sdc(ii,:)    = nn1uw(ii,:).*deltaxl1(kk,:).*pathcheck(kk,:);
%        end

        ggnn1sdc  = digraph(nn1sdc);
        sdeltax(kk,:)     = distances(ggnn1sdc,kk,'Method','positive');
        kk=kk+1;
        if mod(kk,saveshowevery)==0
            timelos = timelos0 + toc;
            dataname = 'LOShold';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%   Always put longest variables first, if Matlab requires v7.3 for
%%%%%   saving, it needs to know this first, not last.
%            varinfoo = {''          1 0}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
            varinfoo = {'sdeltax'  -1 0}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
            varinfoo = {'kk'       -1 0}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
            varinfoo = {'timelos'  -1 0}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
            dataname = 'LOS';
            display(sprintf('current kk = %05d   and  timelos = %f',kk,timelos));
        end
    end
%    stmp = sdeltax-sdeltax';
    loadname = 'init'; 
    varinfoo = {loadname,'''pathl1true'''};
    loadright1 = loadright03(varinfoo);for jj=1:size(loadright1,2);varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright1{jj}=[];end; 
    checkdeltl1a = (sdeltax<pathl1true+0.1);
    checkdeltl1b = (sdeltax'<pathl1true+0.1);
    varinfoo = {'sdeltax' savedeltax -1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
%    stmp(isnan(stmp)) = bignum;
%    pathcheck  = abs(pathl-pathltrue)<10^(-sigfigs+1);
%    deltxcrit   = abs(stmp)<(pathcount+0.1);
%    deltxcrit   = abs(stmp)<(pathl1true+0.1);
    deltxcrit   = checkdeltl1a&checkdeltl1b;
%    deltxcrit   = abs(sdeltax-pathl1true)<(pathcount/2+0.1);
%    deltxcrit  = logical(sdeltax>10^(-sigfigs+2));
%    deltxcrit  = deltxcrit&deltxcrit';
%    deltxcrit = deltxcrit|deltxcrit';
    losmat     = deltxcrit&pathcheck;    
%    plot(graphh);
    clear dircos dircossq deltar pathcount pathltrue sdccrit* loscheck*

    [ppl,qql,rrl,ssl,ttl,uul] = dmperm(sparse(losmat));
    varinfoo = {'losmat'  savelosmat 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
    loadname = 'connpathl'; 
    varinfoo = {loadname,'''connmat'''};
    loadright1 = loadright03(varinfoo);for jj=1:size(loadright1,2);varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright1{jj}=[];end;
    connpermlos = connmat(ppl,qql);  
    varinfoo = {'connpermlos'  savelosmat 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
    clear connmat 
    loadname = 'LOS'; 
    varinfoo = {loadname,'''connpermlos'''};
    loadright1 = loadright03(varinfoo);for jj=1:size(loadright1,2);varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright1{jj}=[];end;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'connpermlos';
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    titleinfo1   = sprintf('Connection Matrix (permuted using LOSmat) - from (k,l)');
    titleinfo2   = sprintf('');
    xlabel1      = 'Partition #';
    xlabel2      = 'Partition #';
    datainfoo{1} = { eval(plotdataname) };
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 xlabel1 xlabel2};
    flaginfoo{1} = { plotconn printconn plotnow 1 0 };
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  SPY
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    clear connpermlos
    loadname = 'LOS'; 
    varinfoo = {loadname,'''losmat'''};
    loadright1 = loadright03(varinfoo);for jj=1:size(loadright1,2);varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end; loadright1{jj}=[];end;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'losmat';
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    titleinfo1   = sprintf('Line-Of-Sight Matrix - LOS - from (k,l)');
    titleinfo2   = sprintf('');
    xlabel1      = 'Partition #';
    xlabel2      = 'Partition #';
    datainfoo{1} = { eval(plotdataname) };
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 xlabel1 xlabel2};
    flaginfoo{1} = { plotLOS printLOS plotnow 1 0 };
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  SPY
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    clear losmat
    LOSreturn = {1};    
%%%%
%%%%  Compute memory and timing variables for performance
%%%%
    tendlos = now;
    durationnlos = tendlos-tstartlos;
    display(sprintf('Ending LOS Analysis at %s',datestr(datetime('now'))))
    tstartlost = datetime(datevec(tstartlos));
    tendlosd   = datetime(datevec(tendlos));
    timelos = rem(durationnlos,1)*86400;
    display(sprintf('LOS Analysis Duration: %s',datestr(timelos/86400, 'HH:MM:SS')));

    workspacee = whos;
    memusedlos = sum([workspacee.bytes]);
%%%%
%%%%   Save all of the variables
%%%%
    varnamess = {varnamesshort{:} varnameslong{:} varnamestime{:}}; 
    for ii = 1:size(varnamess,2); eval(sprintf('global %s',varnamess{ii}));  end;
    saverightend01;
    profile off
    dataname = 'LOShold';
    delete(sprintf('%s/_DATA/%s/prod_%04d_%s_%s*.mat',fileroot,shapestr,prodrunnum,dataname,fileprefix));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
elseif checkreLOS
    display('LOS files already exists and RECLUSTER LOS set.  LOS clustering analysis will be DONE.')
   
    loadname = 'init'; 
    varinfoo = {loadname,'''-regexp'',''^(?!deltaxl1|deltar|dircos|nn1|pathltrue|pathl1true|pathl1corr|dataindexminmax|dataptsminmax)\w'''};
    loadright1 = loadright03(varinfoo);for jj=1:size(loadright1,2);varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end;loadright1{jj}=[];end
%    wgtmat = partkeepwgts*partkeepwgts';
%    clear wgtmat
    
    loadname = 'connpathl'; 
    varinfoo = {loadname,'''connmat''','''pathcheck'''};
    loadright1 = loadright03(varinfoo);for jj=1:size(loadright1,2);varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end;loadright1{jj}=[];end
    clear pathl pathlcount
    
    loadname = 'LOS'; 
    varinfoo = {loadname,'''sdeltax'''};
    loadright1 = loadright03(varinfoo);for jj=1:size(loadright1,2);varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end;loadright1{jj}=[];end
%    wgtmat = partkeepwgts*partkeepwgts';
   
    stmp = sdeltax-sdeltax';
    stmp(isnan(stmp)) = bignum;
%    pathcheck  = abs(pathl-pathltrue)<10^(-sigfigs+1);
    deltxcrit   = abs(stmp)<(pathcount+0.1);
%    deltxcrit   = abs(sdeltax-pathl1true)<(pathcount/2+0.1);
%    deltxcrit  = logical(sdeltax>10^(-sigfigs+2));
%    deltxcrit  = deltxcrit&deltxcrit';
%    deltxcrit = deltxcrit|deltxcrit';
    clear stmp pathcount
    losmat     = deltxcrit&pathcheck;
    clear deltxcrit pathcheck

    [ppl,qql,rrl,ssl,ttl,uul] = dmperm(sparse(losmat));
    connpermlos = connmat(ppl,qql);  
    clear connmat
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'connpermlos';
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    titleinfo1   = sprintf('Connection Matrix (permuted using LOSmat) - from (k,l)');
    titleinfo2   = sprintf('');
    xlabel1      = 'Partition #';
    xlabel2      = 'Partition #';
    datainfoo{1} = { eval(plotdataname) };
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 xlabel1 xlabel2};
    flaginfoo{1} = { plotconn printconn plotnow 1 0 };
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  SPY
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    clear connpermlos
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'losmat';
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    titleinfo1   = sprintf('Line-Of-Sight Matrix - LOS - from (k,l)');
    titleinfo2   = sprintf('');
    xlabel1      = 'Partition #';
    xlabel2      = 'Partition #';
    datainfoo{1} = { eval(plotdataname) };
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 xlabel1 xlabel2};
    flaginfoo{1} = { plotLOS printLOS plotnow 1 0 };
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  SPY   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    LOSreturn = {1};    
%%%%
%%%%   Save all of the variables
%%%%
    varnamess = {varnamesshort{:} varnameslong{:}}; 
    for ii = 1:size(varnamess,2); if size(varnamess{ii},2)>0; eval(sprintf('global %s',varnamess{ii})); end; end;
    saverightend01;
    profile off
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
else
    display('LOS files already exists and OVERWRITE LOS set to ZERO.  LOS analysis NOT DONE.')
    LOSreturn = {1};    
end
clear global kk 
close all
return 
    



















