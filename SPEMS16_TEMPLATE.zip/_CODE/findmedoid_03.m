function [ clusmedoid ] = findmedoid_03(varargin)

clusparts = varargin{1};
flagtype  = varargin{2};       %  flagtype=1 uses deltar   flagtype=2  uses pathl
clusparts(clusparts==0) = [];
indexs = 1:size(clusparts,2);
tic
if (nargin==0)
    display('failed');
end

if flagtype<5
    if flagtype==1
        global deltar 
        med1  = deltar(clusparts,clusparts);
    elseif flagtype==2
        global  pathl 
        med1  = pathl(clusparts,clusparts);
    elseif flagtype==3
        global deltar wgtmat
        med1  = deltar(clusparts,clusparts).*wgtmat(clusparts,clusparts);
    elseif flagtype==4
        global  pathl wgtmat
        med1  = pathl(clusparts,clusparts).*wgtmat(clusparts,clusparts);
    end
    med2  = sum(med1) + (sum(med1==0)*max(max(med1)));
%    med3  = sort(med2,'ascend');
%    med4  = indexs(med2==med3(1));
    med3  = min(med2);
    med4  = indexs(med2==med3);
    clusmedoid  = clusparts(med4(ceil(end/2)));
elseif flagtype==5
    clusmedoid = clusparts;
end
return


 