%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%
%%%%%%%%%%%  High-Dimensional Data Clustering Analysis Suite
%%%%%%%%%%%
%%%%%%%%%%%  PREP - Routine to prepare a production run over all test cases
%%%%%%%%%%%  and all data clustering techniques (with flags that can be set
%%%%%%%%%%%  to turn on/off particular techniques).  Also, most of the USER
%%%%%%%%%%%  settable PARAMETERS are set within this routine.
%%%%%%%%%%%
%%%%%%%%%%%  This routine merely writes the production data files.  The
%%%%%%%%%%%  routine INITIALIZE/RUN actually runs the code sequentially.
%%%%%%%%%%%  Depending on the size of the bins chosen, you might want to
%%%%%%%%%%%  condider going home for the evening and looking at the results
%%%%%%%%%%%  in the morning.  It is best to start the code with small
%%%%%%%%%%%  numbers of bin so that you can guage the overall run-time.
%%%%%%%%%%%
%%%%%%%%%%%  Kevin Mcilhany - March 15, 2017 (v1)
%%%%%%%%%%%  v15:  23-SEPT-2017
%%%%%%%%%%%  mcilhany@usna.edu
%%%%%%%%%%%  Physics Dept. USNA  (410) 293-6667
%%%%%%%%%%%
%%%%%%%%%%%  Steve Wiggins - collaborating - Math Dept. Univ of Bristol, UK
%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Throughtout this code and all of its functions, Matlab allows for the
%%% contraction of code by clicking on a "+" or a "-" box to the immediate
%%% left of the beginning of the lines for statements like - while and for
%%% As such, I have used this to simplify the presentation by creating
%%% empty "for" loops with a dummy variable for hidecodeXXX = 1:1  (code inserted here)     end
%%% In this manner, I can simply click the "-" box to make the code hidden,
%%% then I can expand it later viewing.  As I continue to clean up this
%%% code, I will eventually offload most of these lines of code into
%%% functions located in the main directory, but for now, they are hidden.
%%%  The analysis assumes a directory structure is in place with three main
%%%  directories all at the same level; "_CODE", "_DATA", "_FIGS"
%%%  within _DATA and _FIGS, further subdirectories are assumed to exist,
%%%  one for each case of the data; ie. data2d1, data2d2, plus1, etc...
%%%  Finally, within the _DATA directory, two more subdirectories are
%%%  assumed to exist; "_SETS" and "prod", where the _SETS directory contains the original
%%%  data to be analyzed and the "prod" directory is where all files from
%%%  this code are written - the "production run files".
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
fileroot0 = pwd;
fileroot = strrep(fileroot0,'_CODE','');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%  Sets a production number that will be attached to all outputs from
%%%%  this analysis, allowing the user to track the details.  If the
%%%%  production number is negative, use the specified production number,
%%%%  else use a randomly chosen production number that is currently not in
%%%%  the production pool.  This allows a cluster to initiate a large set
%%%%  of production runs without overwriting results.  The final file
%%%%  produced is called _DATA/prod/prod_prep_RRRR_XXXX.mat, where RRRR is 
%%%%  the run number and XXXX is an index for one of the sub-productions runs. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%prodrunnum = -351;
%prodrunnum = -339;
prodrunnum = -354;
prodrunnum = -375;   %200 res  min pop=0 %0% data cut  %k=16%
% prodrunnum = -401;   %200 res  min pop=3  %2% data cut  %k=16%
% prodrunnum = -402;   %100 res  min pop=0  %2% data cut  %k=16%
% prodrunnum = -403;   %100 res  min pop=0  %5% data cut  %k=16%
% prodrunnum = -404;   %100 res  min pop=0 %10% data cut  %k=16%
% prodrunnum = -405;   %60  res  min pop=0  %2% data cut - SPECTRAL test  %k=16%
% prodrunnum = -406;   %40  res  min pop=0  %2% data cut - SPECTRAL test  %k=16%
% prodrunnum = -407;   %200 res  min pop=0  %0% data cut  %k=16%
% prodrunnum = -408;   %200 res  min pop=0  %3% data cut  %k=16%
% prodrunnum = -409;   %200 res  min pop=0  %0% data cut %k=6%
 prodrunnum = -410;   %100 res  min pop=3  %2% data cut  %k=16%

for hidecodeproductionrun = 1:1
    checkfileprod0 = ls(sprintf('%s/_DATA/prod/prod_prep_%04d_*',fileroot,abs(prodrunnum)));
    checkfileprod  = logical(size(checkfileprod0,2));
    checkoverwriteprod = 1;
    if checkfileprod
        checkoverwrite0 = input('Production files already exist, overwrite (default - <ENTER> = YES, all else = NO)?');
        checkoverwriteprod  = ~logical(size(checkoverwrite0,2));
        if checkoverwriteprod
            display(sprintf('Overwriting production run #%04d',abs(prodrunnum)));
        else
            display(sprintf('Production run #%04d already exists, EXITING.',abs(prodrunnum)));
        end
    else
        display(sprintf('No existing Production files for run #%04d already exist, PROCEEDING.',abs(prodrunnum)));    
    end
    checkgoprod = ~(checkfileprod&(~checkoverwriteprod));

    if checkgoprod     %  GO!!!!!!!!!!!!!!
       delete(sprintf('%s/_DATA/prod/prod_prep_%04d_*',fileroot,abs(prodrunnum))); 
    end

    if prodrunnum<0
        prodrunnum = abs(prodrunnum);
    else
        prodfiles0 = ls(sprintf('%s/_DATA/prod/prod*',fileroot));
        jj = 1;
        for ii = 1:size(prodfiles0,1) 
            if strcmp(prodfiles0(ii,21:23),'mat')
            if ~isempty(str2num(prodfiles0(ii,11:14)))
                prodrundone0(jj) = str2num(prodfiles0(ii,11:14));
                jj = jj+1;
            end
            end
        end
        prodrundone = unique(prodrundone0);
        flagfindrun = 1;
        while flagfindrun
            if ismember(prodrunnum, prodrundone)
                prodrunnum = ceil(rand(1)*1000);
            else
                flagfindrun = 0;
            end
        end
end
display(sprintf('Current run is Production Run Number: %04d',prodrunnum));
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Establish most of the variables needed to run the logistics of the
%%% code, like when and what to print.  None of the algorithm's variables
%%% are set here, only logistics.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for hidecodelogistics = 1:1

%%%%  Various flags to set to perform parts or all of the clustering
%%%%  calculation.  In this manner, the user can  set only a few techniques
%%%%  to be applied or all of them.  In the future, these will all be set
%%%%  by a GUI.
    doinitialize          = 1;
    doLMHpos              = 1;
    dokmeanmeds           = 1;
    dokmeans              = 1;
    dokmedoids            = 1;
    domaxglobal           = 1;
    doconnpathl           = 1;
    domaxpathl            = 1;
    doLOS                 = 1;
    doLOS1                = 1;
    doLOS2                = 1;
    doLOS3                = 1;
    domaxvismut           = 1;
    domaxvis              = 1;
    domaxmut              = 1;
    dospectral            = 1;
    dospectral12          = 1;
    dospectral32          = 1;
    dospectralnn1         = 1;
    dospectrallos         = 1;
    dospectralrad         = 1;
    dorobust              = 1;
    dorobust1             = 1;
    dorobust2             = 1;
    dorobust3             = 1;
    dorobust4             = 1;
    doplots               = 1;
    plotall2              = 0;
    printall2             = 0;
    savebig               = 0;
%%%% Various settings and flags, mainly for plotting features. "bignum" and "epss" set 
%%%  the limits for the lower bound on most numerical calculations - when needed.
%%%  "sigfigs" sets the number of significant digits for all saved
%%%  variables.
    runindex      = 1;
    saveshowevery = 200;
    markersizee   = 24;
    bignum                = 1.0e9;
    epss                  = 1/bignum;
    sigfigs               = 5;
    smallpartnums1        = 250;
    smallpartnums1        = 0;
    smallpartnums2        = 100;
    smallpartnums3        = 1000;
%%% Print magnification factor - from export_fig, the m-value 1=low, 3=high    
    magprint              = 1;

    transparencyfactor    = 0.60;
    transparencyfactor3d  = 0.50;
    transparencyfactorpts = 0.15;

    euclgridsize          = 1.0;
    pathlgridsize         = 1.0;
    LOSfast               = 1;
    LOSgood               = 1;
    threshpeak            = 0.75;
    partmatmax            = -20000;
    doplots               = 1;
    plotnow               = 1;
    plotclustersonly      = 1;
        
    plottitles            = 0;
    plotaxes              = 1;
    plotmedoidsc          = 1;
    plotmedoidsc          = 0;
    plotmedoidsr          = 1;
    plotmedoidsr          = 0;

%%% List of all possible variables that can be plotted 
    plotvars = {'init'      'binadd2';
                'init'      'binaddu';
                'init'      'wgtp';
                'init'      'dataptsminmax';
                'init'      'dataindexminmax';
                'init'      'datapartitions';
                'init'      'hindorig';
                'init'      'h3orig';
                'init'      'hind';
                'init'      'h3';
                'init'      'deltaxl1';
                'init'      'nn1';
                'init'      'deltar';
    %            'init'      'dircos';            
                'init'      'pathltrue';
                'init'      'pathl1true';
                'init'      'pathcount';
                'LMHpos'    'clusterLMHpos';
                'LMHpos'    'clustermedoidsh';
                'kmeanmeds' 'clusterkmeans';
                'kmeanmeds' 'clustermedoidsn';
                'kmeanmeds' 'clusterkmedoids';
                'kmeanmeds' 'clustermedoidsd';
                'maxglobal' 'clustermaxglobal';
                'maxglobal' 'clustermedoidsg';
                'connpathl' 'connmat';
                'connpathl' 'pathl';
                'connpathl' 'pathlcount';
                'connpathl' 'pathcheck';
                'connpathl' 'clusterconn';
                'connpathl' 'clustermedoidsc';
                'maxpathl'  'clustermaxpathl';
                'maxpathl'  'clustermedoidsp';
                'LOS'       'sdeltax';
                'LOS'       'losmat';
                'LOS'       'connpermlos';
                'maxvismut' 'clustermaxvis';
                'maxvismut' 'clustermedoidsv';
                'maxvismut' 'clustermaxmut';
                'maxvismut' 'clustermedoidsm';
                'spectral'  'clusterspectral01';
                'spectral'  'clustermedoids01';
                'spectral'  'clusterspectral02';
                'spectral'  'clustermedoids02';
                'spectral'  'clusterspectral03';
                'spectral'  'clustermedoids03';
                'spectral'  'clusterspectral04';
                'spectral'  'clustermedoids04';
                'spectral'  'clusterspectral05';
                'spectral'  'clustermedoids05';
                'spectral'  'clusterspectral06';
                'spectral'  'clustermedoids06';
                'spectral'  'clusterspectral07';
                'spectral'  'clustermedoids07';
                'spectral'  'clusterspectral08';
                'spectral'  'clustermedoids08';
                'spectral'  'clusterspectral09';
                'spectral'  'clustermedoids09';
                'spectral'  'clusterspectral10';
                'spectral'  'clustermedoids10';
                'spectral'  'clusterspectral11';
                'spectral'  'clustermedoids11';
                'spectral'  'clusterspectral12';
                'spectral'  'clustermedoids12';
                'spectral'  'clusterspectral13';
                'spectral'  'clustermedoids13';
                'spectral'  'clusterspectral14';
                'spectral'  'clustermedoids14';
                'spectral'  'clusterspectral15';
                'spectral'  'clustermedoids15';
                'spectral'  'clusterspectral16';
                'spectral'  'clustermedoids16';
                'spectral'  'clusterspectral17';
                'spectral'  'clustermedoids17';
                'spectral'  'clusterspectral18';
                'spectral'  'clustermedoids18';
                'robust'    'clusterrobust1';
                'robust'    'clustermedoidsr1';
                'robust'    'clusterrobust2';
                'robust'    'clustermedoidsr2';
                'robust'    'clusterrobust3';
                'robust'    'clustermedoidsr3';
                'robust'    'clusterrobust4';
                'robust'    'clustermedoidsr4'};
%%% Flags for which variables to plot to the screen and the print to file.
    plotbinaddu           = 0;
    plotconnpathl         = 1;
    plotconn              = 1;
    plotdata              = 0;
    plotdataptsminmax     = 0;
    plotdeltar            = 0;
    plotdeltaxl1          = 0;
    plotdircos            = 0;
    plotdist              = 0;
    plotfilldensity       = 0;
    plotkmeans            = 1;
    plotkmedoids          = 1;
    plotLMHpos            = 1;
    plotLOS               = 0;
    plotLOSclusters       = 1;
    plotmaxglobal         = 1;
    plotmaxmut            = 1;
    plotmaxpathl          = 1;
    plotmaxvis            = 1;
    plotnn1               = 0;
    plotnn1perm           = 0;
    plotnnn               = 0;
    plotpathcount         = 0;
    plotpathl             = 0;
    plotpathlcount        = 0;
    plotpathldircos       = 0;
    plotpathltrue         = 0;
    plotpathl1true        = 0;
    plotrobust1           = 1;
    plotrobust2           = 1;
    plotrobust3           = 1;
    plotrobust4           = 1;
    plotspectral          = 1;
    plotwgtp              = 0;
    plotwgtplog           = 0;

    printbinaddu           = 0;
    printconnpathl         = 1;
    printconn              = 1;
    printdata              = 0;
    printdataptsminmax     = 0;
    printdeltar            = 0;
    printdeltaxl1          = 0;
    printdircos            = 0;
    printdist              = 0;
    printfilldensity       = 0;
    printkmeans            = 1;
    printkmedoids          = 1;
    printLMHpos            = 1;
    printLOS               = 0;
    printLOSclusters       = 0;
    printmaxglobal         = 1;
    printmaxmut            = 1;
    printmaxpathl          = 1;
    printmaxvis            = 1;
    printmedoidsc          = 1;
    printmedoidsr          = 0;
    printnn1               = 0;
    printnn1perm           = 0;
    printnnn               = 0;
    printpathcount         = 0;
    printpathl             = 0;
    printpathlcount        = 0;
    printpathldircos       = 0;
    printpathltrue         = 0;
    printpathl1true        = 0;
    printrobust1        = 1;
    printrobust2        = 1;
    printrobust3        = 1;
    printrobust4        = 1;
    printspectral          = 1;
    printwgtp              = 0;
    printwgtplog           = 0;

    if plotall2==1
        plotdata           = 0;
        plotdataptsminmax  = 1;
        plotbinaddu        = 0;
        plotconnpathl      = 1;
        plotconn           = 1;
        plotdist           = 1;
        plotdeltar         = 0;
        plotdircos         = 0;
        plotdeltaxl1       = 0;
        plotkmeanmeds      = 1;
        plotLMHpos         = 1;
        plotLOS            = 1;
        plotmaxvis         = 1;
        plotmaxmut         = 1;
        plotmaxglobal      = 1;
        plotmaxpathl       = 1;
        plotnn1            = 0;
        plotnn1perm        = 0;
        plotpathltrue      = 0;
        plotpathl1true     = 0;
        plotpathcount      = 0;
        plotrobust1        = 1;
        plotrobust2        = 1;
        plotrobust3        = 1;
        plotrobust4        = 1;
        plotspectral       = 1;
        plotweights        = 1;
        plotweightslog     = 1;
        doplots            = 1;
    end

    if printall2==1
        printdata           = 0;
        printdataptsminmax  = 1;
        printbinaddu        = 0;
        printconnpathl      = 1;
        printconn           = 1;
        printdist           = 1;
        printdeltar         = 0;
        printdircos         = 0;
        printdeltaxl1       = 0;
        printkmeanmeds      = 1;
        printLMHpos         = 1;
        printLOS            = 1;
        printmaxvis         = 1;
        printmaxmut         = 1;
        printmaxglobal      = 1;
        printmaxpathl       = 1;
        printnn1            = 0;
        printnn1perm        = 0;
        printpathltrue      = 0;
        printpathl1true     = 0;
        printpathcount      = 0;
        printrobust         = 1;
        printspectral       = 1;
        printweights        = 1;
        printweightslog     = 1;
        doplots             = 1;
    end
    if plotclustersonly==1
        printLMHpos         = 1;
        printkmeanmeds      = 1;
        printmaxglobal      = 1;
        printconn           = 1;
        printmaxpathl       = 1;
        printmaxvis         = 1;
        printmaxmut         = 1;
        printspectral       = 1;
        printrobust1        = 1;
        printrobust2        = 1;
        printrobust3        = 1;
        printrobust4        = 1;
        doplots             = 1;
        plotbinaddu           = 0;
        plotconnpathl         = 0;
        plotdata              = 0;
        plotdataptsminmax     = 0;
        plotdeltar            = 0;
        plotdeltaxl1          = 0;
        plotdircos            = 0;
        plotdist              = 0;
        plotfilldensity       = 0;
        plotLOS               = 0;
        plotLOSclusters       = 0;
        plotnn1               = 0;
        plotnn1perm           = 0;
        plotnnn               = 0;
        plotpathcount         = 0;
        plotpathl             = 0;
        plotpathlcount        = 0;
        plotpathldircos       = 0;
        plotpathltrue         = 0;
        plotpathl1true        = 0;
        plotwgtp              = 0;
        plotwgtplog           = 0;
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% What to save and not save.  The total file output can get large, so
%%% save what you need and lose the rest.
    savebinadd2           = 1;
    savecluster           = 0;
    saveconn              = 1;
    savedataptsminmax     = 1;
    savedataindexminmax   = 1;
    savedeltar            = 1;
    savedircos            = 0;
    savedeltax            = 1;
    savedeltaxl1          = 1;
    savekmeanmeds         = 1;
    saveLMHpos            = 1;
    savelosmat            = 1;
    savemaxglobal         = 1;
    savemaxpathl          = 1;
    savemaxvismut         = 1;
    savenn1               = 1;
    savepathl             = 1;
    savepathltrue         = 1;
    savepathl1true        = 1;
    savepathl1corr        = 1;
    savepathcount         = 1;
    saverobust            = 1;
    savespec              = 1;
%%%%  Flags for whether to allow a routine to overwrite an important file
%%%%  or not.  For instace, the LOS files take the longest to calculate.
    checkoverwriteinitialize  = 1;
    checkoverwriteLMHpos      = 1;
    checkoverwritekmeanmeds   = 1;
    checkoverwritemaxglobal   = 1;
    checkoverwriteconnpathl   = 1;
    checkoverwritemaxpathl    = 1;
    checkoverwriteLOS         = 1;
    checkoverwritemaxvismut   = 1;
    checkoverwritespectral    = 1;
    checkoverwriterobust      = 1;
%%% Flags for which variables to save
    if savebig==1
        savedeltar            = 1;
        savedircos            = 1;
        savedeltaxl1          = 1;
        savenn1               = 1;
        savepathltrue         = 1;
        savepathl1true        = 1;
        savepathcount         = 1;
        savedataptsminmax     = 1;
        savedataindexminmax   = 1;
        savebinadd2           = 1;
        saveconn              = 1;
        savelosmat            = 1;
        savespeccluster       = 1;
        savecluster           = 1;
        savemaxglobal         = 1;
    end

    if domaxglobal==1
        savedeltar            = 1;
        savebinadd2           = 1;
        savedataptsminmax     = 1;
        savedataindexminmax   = 1;
        savemaxglobal         = 1;
        savepathcount         = 1;
        savenn1               = 1;
    end

    if domaxpathl==1
        doLOS                 = 1;
        savedeltar            = 1;
        savebinadd2           = 1;
        savedataptsminmax     = 1;
        savedataindexminmax   = 1;
        savemaxpathl          = 1;
    end

    if domaxvismut==1
        doLOS                 = 1;
        savelosmat            = 1;
        savecluster           = 1;
    end

    if doLOS==1
        savenn1               = 1;
        savedeltar            = 1;
        savedircos            = 1;
        savedeltaxl1          = 1;
        savepathltrue         = 1;
        savepathl1true        = 1;
        savepathcount         = 1;
        saveconn              = 1;
        savelosmat            = 1;
    end

    if dospectral==1
        savenn1               = 1;
        savebinadd2           = 1;
        savedataptsminmax     = 1;
        savedataindexminmax   = 1;
        savespeccluster       = 1;
    end

    if doconnpathl==1
        savenn1               = 1;
        saveconn              = 1;
    end
    
%%%  Flags for how medoids are treated.
    medoidtypeLMHpos      = 1;
    medoidtypekmeans      = 1;
    medoidtypekmedoids    = 1;
    medoidtypemaxglob     = 1;
    medoidtypeconn        = 1;
    medoidtypemaxpathl    = 2;
    medoidtypelosmaxvis   = 2;
    medoidtypelosmaxmut   = 2;
    medoidtypespec(1)     = 2;
    medoidtypespec(2)     = 2;
    medoidtypespec(3)     = 2;
    medoidtypespec(4)     = 2;
    medoidtypespec(5)     = 2;
    medoidtypespec(6)     = 2;
    medoidtypespec(7)     = 2;
    medoidtypespec(8)     = 2;
    medoidtypespec(9)     = 2;
    medoidtypespec(10)    = 2;
    medoidtypespec(11)    = 2;
    medoidtypespec(12)    = 2;
    medoidtypespec(13)    = 1;
    medoidtypespec(14)    = 1;
    medoidtypespec(15)    = 1;
    medoidtypespec(16)    = 1;
    medoidtypespec(17)    = 1;
    medoidtypespec(18)    = 1;
%%%  Flags to set if you simply wish to "recluster" and not reanalyze the
%%%  clustering algorithm.  For reclustering, you are using the analyzed
%%%  results but treating the "gathering" process diffently.
    checkreclusterLMHpos      = 0;
    checkreclusterkmeanmeds   = 0;
    checkreclustermaxglobal   = 0;
    checkreclusterconnpathl   = 0;
    checkreclustermaxpathl    = 0;
    checkreLOS                = 0;
    checkreclustermaxvismut   = 0;
    checkreclusterspectral    = 0;
    checkreclusterrobust      = 0;        
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%  The main algorithm parameters are set here.  More than one parameter
%%%  can be set such that a group of analyses are done in sequence.  In
%%%  this case, each file produced has a production run number in common
%%%  but is followed by a "analysis variant" number.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for hidecodealgparams = 1:1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% PARAMETERS FOR ALGORITHMS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%  All of the parameters up to this point were for a single production
%%%%  run.  When the user wishes to run over multiple parameters for a
%%%%  systematic study, these arrays are used instead.  For each value in
%%%%  each array, a different production will be performed
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Indices for the testcases provided
    shapesstr = {'L' 'C' 'O' 'S' 'Z' 'plus1' 'plus2' 'plus3' 'concentric1' 'concentric2' 'data2d1' 'data2d2' 'data3d1' 'data3d2' 'clipart01' 'clipart02' 'clipart03' 'clipart04' 'clipart05' 'clipart06' 'clipart09' 'clipart11'  'clipart12' 'dataP' 'L2'};
    shapesind = [ 1   2   3   4   5     6       7       8          9             10          11        12        13        14        15          16          17          18          19          20          21          22           23         24    25 ];
%%%%
%%%%  bins - probably the most important parameter in the production as it
%%%%  sets the overall time it will take to finish.  For 2D testcases, bins
%%%%  sets the total number of possible bin addresses to bins^2.  For 3D
%%%%  data sets, bins is reset to bins^(2/3) so that the final number of
%%%%  bins is still bins^2, making the analysis roughly consistent in how
%%%%  long it takes to finish.  For higher dimensional problems, the number
%%%%  of bins should be set according to the axes chosen.  In some cases,
%%%%  this might be as low as 2 or 3 bins, but it might be as high as 50.
%%%%  I strongly recommend keeping this number below 50 bins as the maximum
%%%%  unique integer possible in Matlab is 10^15 (or 10^18) depending on
%%%%  how you cast things.  In order to be able to use the full power of
%%%%  Matlab, the total number of addressable bins should be less than
%%%%  10^15.  The total number of addressable bins is the product sum of
%%%%  the bins for each dimension.
%%%%
    basebins0             = 160;
    basebins              = basebins0;
    basebins3d            = 25;
    basebins3d            = ceil(basebins0^(2/3));    % this makes the number of 3D partitions comparable to a 2D analysis
    basebinstitle         = basebins;
    userminmax            = 0;                        % for images input as distributions, set the pixel dimensions
%%%%
%%%% threshdist = the first cut applied to the data which removes any bins
%%%% whose cummulative populations are less than X% of the total data set,
%%%% where X is threshdist. 
%%%%
%%%% minpop = serves a similar purpose by removing all bins with a
%%%% population below minpop.
%%%%
%%%% minpopglobalpathl = similar to above, but sets a minimum on how
%%%% short a path length can be.
%%%%
    threshdist            = 0.01;
    minpop                = 1;
    minpathl              = 4;
%%%% K-value for Kmeans and Kmedoids
    cluskmeanmedsknum     = 16;
%    cluskmeanmedsknum     = 6;
    kmeanmedsmode         = 2;                     % mode=0 do all types, mode=1 partitions, mode=2 data as bins, mode=3 data pts
%%%%  Max Global/Pathl parameters for establishing peaks
    minpopglobalpathl     = 0;
    threshpeak            = 0.75;
    threshfilld           = 0.50;
%%%% MaxVis parameters
    fixedbins             = 100;
    threshoverlap0        = +0.05;
    threshoverlap2        = +0.90;
    threshoverlap3        = +0.03;
    threshtype            = 1;
%%%% MaxMutual parameters
    peakthresh0       = 0.25;
    threshmin0        = 0.01;
    resurgethresh0    = 0.30;
    stddevnum         = 1;
    nsmooth           = 1;    
%%%% For spectral clustering, clusspecgather determines how the regions
%%%% within the eigenspace are broken, either using k-means, k-medoids or a
%%%% simple 2D histogram approach.
    clusspecgather        = 3;     % 1 = histo,  2 = kmeans,   3 = kmedoids
%%%% For spectral clustering, clusspecdata determines whether to use the
%%%% NN1 or the LOS matrix to form the numerical Laplacian
    clusspecdata          = 2;     % 1 = nn1,    2 = conn,     3 = LOS
%%%%  clusspechistobins, clusspeckmeansnum and clusspeckmedoidsnum set the
%%%%  number of groups to find within the eigenspace.
%    clusspechistobins     = 6;
%    clusspeckmeansnum     = 16;
%    clusspeckmedoidsnum   = 16;
    clusspechistobins     = max([ceil(sqrt(cluskmeanmedsknum)) 6]);
    clusspeckmeansnum     = cluskmeanmedsknum;
    clusspeckmedoidsnum   = cluskmeanmedsknum;
%%%% clusspeceig = parameter to choose whether the 1+2 eigenvectors are
%%%% used or the 2+3 eigenvectors for spectral clustering
    clusspeceig           = 1;     % 1 = eigvec1+2,   3 = eigvec3+2
    clusgatherintersect   = 1;
    clusgatherbulk        = 1;
%%% Spectral Clustering Gaussian Radial parmaters:  
%%% radialsigma:  sigma in terms of the maximum span of the dataspace domain
%%% radialthresh: lower set of the value of the Laplacian of the Gaussian's magnitude
    radialsigma           = 1.0;
%    radialsigma           = -1;
%    radialsigma           = 0;
    radialthresh          = epss;
%%%%  Robust parameters
    threshmajority        = 0.50;
%    threshmajority        = 0.35;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%  name your variables, establish the order for them (dataorder), set the
%%%  aspect ratio for the bins (binfactor) and set a naming code for the variables chosen (datacode) 
%%%  Set the minimum amd maximum values expected (set to zero for auto limits)
    datanames   = {'alpha' 'rroc' 'vfast' 'vslow' 'velasym' 'beta' 'betaang' 'ke' 'omega' 'ow' 'qcriterion' 'sigma'};
    datamap     = [   1       2      3       4        5        6       7       8     9     10       11         12];
    dataorder   = [   1       2      3       0        0        0       0       0     0      0        0         0 ];
    binfactor   = [   1       1      1       1        1        1       1       1     1      1        1         1 ];
    datacode = sprintf('%01d%01d%01d%01d%01d%01d%01d%01d%01d%01d%01d%0d',dataorder(1),dataorder(2),dataorder(3),dataorder(4),dataorder(5),dataorder(6),dataorder(7),dataorder(8),dataorder(9),dataorder(10),dataorder(11),dataorder(12));
%   minnuser = [minn01 minn02 minn03 minn04 minn05 minn06 minn07 minn08 minn09 minn10 minn11 minn12];
%   maxxuser = [maxx01 maxx02 maxx03 maxx04 maxx05 maxx06 maxx07 maxx08 maxx09 maxx10 maxx11 maxx12];
    minnuser = [    0      0     0       0      0      0      0      0      0      0      0      0 ];
    maxxuser = [  1200   1200    0       0      0      0      0      0      0      0      0      0 ];
    minn = zeros(size(minnuser));
    maxx = zeros(size(maxxuser));
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for hidecodealgparamsprod = 1:1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% For the purpose of creating multiple analyses, the following variables
%%% may be vectors, such that each entry becomes one analysis configuration
%%% leading to many analysis configurations.  Use this capability carefully as 
%%% it may create a large number of configurations.
%%% Each of these "prep" values supercedes previously set value.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% {'L' 'C' 'O' 'S' 'Z' 'plus1' 'plus2' 'plus3' 'concentric1' 'concentric2' 'data2d1' 'data2d2' 'data3d1' 'data3d2' 'clipart01' 'clipart02' 'clipart03' 'clipart04' 'clipart05' 'clipart06' 'clipart09' 'clipart11'  'clipart12' 'dataP' 'L2'};
% [ 1   2   3   4   5     6       7       8          9             10          11        12        13        14        15          16          17          18          19          20          21          22           23         24    25 ];
%   basebinsprep           = [40 60 100 120 150 200];
    basebinsprep           = [100];
%   threshdistprep         = [0.00 0.01 0.02 0.05 0.10 0.20 0.50 0.80];
%   threshdistprep         = [0.00 0.01 0.05 0.10];
    threshdistprep         = [0.02];
%   minpopprep             = [0 1 2 3 4 5 6];
%   minpopprep             = [1 3];
    minpopprep             = [3];
%   minpathlprep           = [0 1 2 3 4];
    minpathlprep           = [0];
%   shapeindexprep         = [11 12 13 14 16 23 15 22 10 8 6 9 1 ];
   shapeindexprep         = [11 12 13 14 23 15 22 10 1 4  25 9 16 8 6 ];
%   shapeindexprep         = [11 12 13 14 4];
%   shapeindexprep         = [11 12 13 14];
%   shapeindexprep         = [11];
%   clusspechistobinsprep  = [6];
%   clusspecknumsprep      = [16 40];
    clusspecknumsprep      = cluskmeanmedsknum;
    clusspechistobinsprep  = max([ceil(sqrt(clusspecknumsprep)) 6]);
%   clusspecdataprep       = [1 2 3];   %1=NN1,   2=LOS,  3=RAD
    clusspecdataprep       = [3];
%   clusspeceigprep        = [1 3];
    clusspeceigprep        = [3];
%   clusspecgatherprep     = [1 2 3];   %1=2DHIS,  2=KMEAN,  3=KMEDS
    clusspecgatherprep     = [3];
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%  Code to write the production files.  If multiple variable runs were requested,
%%%  create all production runs with an index 1...X for each variant of the
%%%  parameters chosen.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for hidecodewriteprod = 1:1
    
    runindex = 1;
    if ~exist('basebinsprep'); basebinsprep = basebins; end;
    for index1 = 1:size(basebinsprep,2)
        basebins0             = basebinsprep(index1);
        basebins3d            = ceil(basebins0^(2/3));
        basebinstitle         = basebins;
    if ~exist('threshdistprep'); threshdistprep = threshdist; end;
    for index2 = 1:size(threshdistprep,2)
        threshdist            = threshdistprep(index2);
    if ~exist('minpopprep'); minpopprep = minpop; end;
    for index3 = 1:size(minpopprep,2)
        minpop                = minpopprep(index3);
    if ~exist('minpathlprep'); minpathlprep = minpathl; end;
    for index4 = 1:size(minpathlprep,2)
        minpathl              = minpathlprep(index4);
    if ~exist('clusspecknumsprep'); clusspecknumsprep = clusspecknums; end;
    for index5 = 1:size(clusspecknumsprep,2)
        clusspechistobins   = clusspechistobinsprep(index5);
        clusspeckmeansnum   = clusspecknumsprep(index5);
        clusspeckmedoidsnum = clusspecknumsprep(index5);
    if ~exist('clusspecdataprep'); clusspecdataprep = clusspecdata; end;
    for index6 = 1:size(clusspecdataprep,2)
        clusspecdata   = clusspecdataprep(index6);
    if ~exist('clusspecgatherprep'); clusspecgatherprep = clusspecgather; end;
    for index7 = 1:size(clusspecgatherprep,2)
        clusspecgather = clusspecgatherprep(index7);
    if ~exist('clusspeceigprep'); clusspeceigprep = clusspeceig; end;
    for index8 = 1:size(clusspeceigprep,2)
        clusspeceig = clusspeceigprep(index8);
    if ~exist('shapeindexprep'); shapeindexprep = shapeindex; end;
    for index9 = 1:size(shapeindexprep,2)
        basebins              = basebins0;
        basebins3d            = ceil(basebins0^(2/3));
        basebinstitle         = basebins;
        shapeindex            = shapeindexprep(index9);
        shapestr = shapesstr{shapeindex};
        if (shapeindex>=13)&(shapeindex<=14)
            basebins              = min([basebins3d basebins]);
        end
        nvars = 2;
        if (shapeindex==13)|(shapeindex==14); nvars = 3; end
        if nvars==2; dataorder(3) = 0; else dataorder(3) = 3; end
        realdata = strcmp(shapestr(1:min([max(size(shapestr)) 4])),'data');
        datacode = sprintf('%01d%01d%01d%01d%01d%01d%01d%01d%01d%01d%01d%0d',dataorder(1),dataorder(2),dataorder(3),dataorder(4),dataorder(5),dataorder(6),dataorder(7),dataorder(8),dataorder(9),dataorder(10),dataorder(11),dataorder(12));
        fileprefix = sprintf('%s_%03d_%03d_%12d',shapestr,basebinstitle,minpop,eval(datacode));
        fileprefix = sprintf('%s_%03d',shapestr,basebinstitle);
        save(sprintf('%s/_DATA/prod/prod_prep_%04d_%04d.mat',fileroot,prodrunnum,runindex))
        runindex = runindex+1;
    end
    end
    end
    end
    end
    end
    end
    end
    end

end

save('filerootname.mat','fileroot');


















