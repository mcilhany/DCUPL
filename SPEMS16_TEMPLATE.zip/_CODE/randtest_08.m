clear all

npoints  = 10000;
npoints1 = 19;
xmin = 0;
xmax = 100;
xrange = xmax-xmin;
peakseparation = 1.5;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 xrand = [];
 xrand1 = rand(npoints1-1,1)*xrange+xmin;
 xrand1 = [xrand1' xmax];
for nn = 1:length(xrand1)
    xrand = [xrand randn(1,ceil(npoints/npoints1))*xrange/npoints1/peakseparation + xrand1(nn)];
end
xrand = sort(xrand);
xrand = xrand(xrand<xmax);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
npoints = length(xrand);
xfactor = 0.9;
%xfactor = ceil(log10(npoints))-1;
xfactor = max([xfactor 1]);
xfactor = 6;
xfactor2 = 0.25;
histbins = 150; 
peakcheckthresh = 0.1;
peakcheckthresh = 0.0;
smoothn  = ceil(sqrt(npoints))*log10(npoints)/xfactor;
smoothn  = ceil(sqrt(npoints))*log10(npoints)*1.5;
smoothn2 = ceil(sqrt(npoints))*log10(npoints)*2;
innern = npoints/50;
innern = smoothn/10;
%promthreshold = ceil(log10(npoints))*xfactor;
promthreshold = ceil(log10(npoints))*ceil(npoints^(0.20))*xfactor2;
%promthreshold = xfactor2;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
xsize = length(xrand);
xdiff = diff(xrand);
%xdiffsmooth = smooth(xdiff,smoothn)';
xdiffsmooth = smoothdata(xdiff,'gaussian',smoothn);
xdiffsmoothinner = xdiffsmooth(innern:end-innern);
ymax = max(xdiffsmoothinner);
%xdiffstd = std(xdiffsmooth);
xdiffstd = std(xdiffsmooth(innern:end));

[xfindp,xfindlocs] = findpeaks(xdiffsmooth,'MinPeakProminence',xdiffstd/promthreshold);

clf
subplot(4,1,1);
hist(xrand,histbins)
[hista,histb] = hist(xrand,histbins);
ymaxx = max(hista);
hold on
plot([xrand(xfindlocs)' xrand(xfindlocs)']',[0*ones(size(xfindlocs))' ymaxx*ones(size(xfindlocs))']','Color','r','LineWidth',5)
subplot(4,1,2);
plot((xdiff),'g')
hold on
plot((xdiffsmooth),'b')
hold on
ylim([0 ymax]);
line([npoints/2 npoints/2],[0 xdiffstd],'Color','r','LineWidth',5)
plot(xfindlocs,xfindp,'ko')


clear xcheck*
xfindlocs0 = xfindlocs;
xfindp0    = xfindp;
starti = 1;
xpeaksize = max(size(xfindlocs));
if ~isempty(xfindlocs)
    for ii = 1:xpeaksize
        endi = xfindlocs(ii);
        lowercheck = ceil((starti+endi)/2);
        starti = endi+1;
        if ii<xpeaksize
            if (xfindlocs(ii+1)<max(size(xdiff)))
                endi = xfindlocs(ii+1);
            else
                endi = max(size(xdiff));
            end
        else
            endi = max(size(xdiff));
        end
        uppercheck = ceil((starti+endi)/2);
    %     checksize  = min([xfindlocs(ii)-lowercheck uppercheck-xfindlocs(ii)]);
    %     meancheck = mean(xdiffsmooth((xfindlocs(ii)-checksize):(xfindlocs(ii)+checksize)));
    %    meancheck = mean(xdiffsmooth(lowercheck:uppercheck));
        checksize  = min([2*smoothn xfindlocs(ii)-lowercheck uppercheck-xfindlocs(ii)]);
        clear xtest
        xtestl = xdiffsmooth((xfindlocs(ii)-checksize):xfindlocs(ii));
        xtestr = xdiffsmooth(xfindlocs(ii):(xfindlocs(ii)+checksize));
        xtestlmin = find(xtestl==min(xtestl));
        xtestrmin = find(xtestr==min(xtestr));
        checksize = min([(checksize-xtestlmin) (xtestrmin)]);
        xtest = xdiffsmooth((xfindlocs(ii)-checksize):(xfindlocs(ii)+checksize));
        xtest = xtest(xtest<xfindp(ii));
    %    clf; plot(xtest);
        meancheck = mean(xtest);
    %    xcheck(ii) = (meancheck-xfindp(ii))/(min([meancheck xfindp(ii)]));
    %    xcheck(ii) = (meancheck-xfindp(ii))/(max([meancheck xfindp(ii)]));
    %    xcheck(ii) = (meancheck-xfindp(ii))/(min([xdiffsmooth meancheck xfindp(ii)]));
    %    xcheck(ii) = (meancheck-xfindp(ii))/(max([xdiffsmooth meancheck xfindp(ii)]));
    %    xcheck(ii) = (meancheck-xfindp(ii))/(min([xtest meancheck xfindp(ii)]));
    %    xcheck(ii) = (meancheck-xfindp(ii))/(max([xtest meancheck xfindp(ii)]));
    %    xcheck(ii) = (meancheck-xfindp(ii))/(xdiffstd);
        xcheck(ii) = (abs(min(xtest)-xfindp(ii)))/(xdiffstd)
    %    xcheck(ii) = (abs(min(xtest)-xfindp(ii)))/(xfindp(ii))
    %    xcheck(ii) = (abs(meancheck-xfindp(ii))) /(min(xtest))

    end
    xcheck2 = abs(xcheck)<peakcheckthresh;
    xfindlocs(xcheck2) = [];
    xfindp(xcheck2)    = [];
    xcheck3 = xcheck2;

    if max(size(xfindp))<max(size(xfindp0))
        xfindlocs = xfindlocs0;
        xfindp    = xfindp0;
        xcheck3last    = xcheck2*1.0;
        xcheck3last(1) = -1;
        while (sum(abs(xcheck3*1.0-xcheck3last))>0)
            xcheck3last = xcheck3;
            for ii = 2:xpeaksize
                if xcheck3last(ii)==1
                if xcheck3last(ii-1)==1
                    if xfindp(ii)>xfindp(ii-1)
                        xcheck3(ii) = 0;
                    else
                        xcheck3(ii-1) = 0;
                    end
                end
                end
            end
        end
        xfindlocs(xcheck3) = [];
        xfindp(xcheck3)    = [];
    end

        xfindlocs = xfindlocs0;
        xfindp    = xfindp0;
        xfindlocs(xcheck2) = [];
        xfindp(xcheck2)    = [];

    xddiffsmooth = diff([xdiffsmooth 0]);
    xddiffsmoothh = smoothdata(xddiffsmooth,'gaussian',smoothn2)';
    subplot(4,1,3);
    plot((xddiffsmoothh),'g')
    hold on
    plot([0 max(size(xddiffsmoothh))],[0 0])
    axis tight
    ylim([-4e-5 4e-5]);
    ylim([-2*mean(abs(xddiffsmoothh)) +2*mean(abs(xddiffsmoothh))]);

    xdddiffsmooth = diff([xddiffsmooth 0]);
    xdddiffsmoothh = smoothdata(xdddiffsmooth,'gaussian',smoothn)';
    subplot(4,1,4);
    plot((xdddiffsmoothh),'g')
    hold on
    axis tight
    ylim([-2*mean(abs(xdddiffsmoothh)) +2*mean(abs(xdddiffsmoothh))]);

    xdd = (xddiffsmoothh.*circshift(xddiffsmoothh,1)<=0);
    subplot(4,1,3);
    plot(xdd*mean(abs(xddiffsmoothh)));


    subplot(4,1,1);
    % hist(xrand,histbins)
    % [hista,histb] = hist(xrand,histbins);
    % ymaxx = max(hista);
    hold on
    plot([xrand(xfindlocs)' xrand(xfindlocs)']',[0*ones(size(xfindlocs))' ymaxx/2*ones(size(xfindlocs))']','Color','c','LineWidth',5)


    xind = 1:max(size(xdddiffsmoothh));
    xdfinal = xind(xdd>0).*(xdddiffsmoothh(xdd>0)'<0);
    xdfinal(xdfinal==0) = [];
    [xdfinalr,xdfinalc] = find(abs(xdfinal'-xfindlocs)<smoothn);
    xfindlocs2 = xfindlocs(xdfinalc);
    plot([xrand(xfindlocs)' xrand(xfindlocs)']',[0*ones(size(xfindlocs))' ymaxx/3*ones(size(xfindlocs))']','Color','m','LineWidth',5)
end



