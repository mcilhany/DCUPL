function [ connreturn ] = clus16_connpathl(varargin)
close all force
profile off
warning off
% clearvars -except fileroot do* prepindex numprepfiles prepfiles prodrunnum prepindexstart prepindexend tstartfull tstartsingle
global fileroot shapestr prodrunnum prepindex fileprefix dataname 
global sigfigs smallpartnums3 partsize  
global dataptsminmax dataptspartkeep dataindexminmax dataindexpartkeep datapartkeepindex dataminmaxpartindex binadd2 datamin datamax datadelta 
global varnamesshort varnameslong varnamestime
varnamesshort = {'bignum','sigfigs','minpop','minpathl','threshdist','nvars','databins','datadelta','datamax','datamin','shapestr','partsize','partkeep','partkeepind','memusedconnpathl','ppc','qqc','rrc','ssc','ttc','uuc','indexminpathl','clusterconn','clustermedoidsc','nclustersc'};
varnameslong  = {'connmat','pathcheck','pathl','pathlcount'};
varnamestime  = {'timeconnpathl','tstartconnpathlt','tendconnpathld'};
dataname      = 'connpathl';
global pathl wgtmat

load(sprintf('%s/_DATA/prod/prod_prep_%04d_%04d.mat',fileroot,prodrunnum,prepindex));
display(sprintf('%04d - %s - Calculate Connection and Path Length',prodrunnum,fileprefix))

checkfileconnpathl0 = ls(sprintf('%s/_DATA/%s/prod_%04d_%s_%s_*.mat',fileroot,shapestr,prodrunnum,dataname,fileprefix));
checkfileconnpathl  = logical(size(checkfileconnpathl0,2));
if checkfileconnpathl
   display('Connection and Path Length clustering already done.');
end
checkgoconnpathl =  ~(checkfileconnpathl&(~checkoverwriteconnpathl));
checkreconnpathl =   (checkfileconnpathl&(checkreclusterconnpathl));
if checkgoconnpathl             % GO!!!!!!!
    display(sprintf('Connection and Path Length files:  %1d OVERWRITE Connection and Path Length:  %1d   Connection and Path Length analysis will be DONE.',checkfileconnpathl,checkoverwriteconnpathl));

    tstartconnpathl = now;
    %profile on
    loadname = 'init'; 
    varinfoo = {loadname,'''-regexp'',''^(?!deltar|deltaxl1|dircos|pathcount|pathl1true|pathl1corr|dataindexminmax|dataptsminmax)\w'''};
    loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end
    wgtmat = partkeepwgts*partkeepwgts';

    if plotall2==1
        plotlos = 1;
        plotconn = 1;
    end
    if(partsize<=12)
       nn1
    end
    
    nn1(1:partsize+1:end) = 0;    
%    nn1 = sparse(logical(nn1));
    indexxs = 1:partsize;
    connmat = logical(zeros(partsize));

    graphh = graph(nn1);
    clear nn1
    connparts = conncomp(graphh);
    numclusconn = max(connparts);
    clusterconn = zeros(numclusconn,partsize);
    for mm = 1:numclusconn
       numclus = sum(connparts==mm); 
       connmat(connparts==mm,connparts==mm) = 1; 
       clusterconn(mm,1:numclus) = indexxs(connparts==mm);
    end
    checkclus = sum(clusterconn);
    clusterconn(:,checkclus==0) = [];
    nclustersc = size(clusterconn,1);

    clustersizes = (sum(clusterconn'>0))';
    [clustersizes2,clustersizeindex]  = sort(clustersizes,'descend');
    clusterconn = clusterconn(clustersizeindex,:);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%  Cut on pathlength at minpathlprep
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    checkclussize = (sum(clusterconn>0,2)>=minpathlprep);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    pathl = distances(graphh,'Method','positive');
    pathlcount = distances(graphh,'Method','unweighted');
    pathcheck  = abs(pathl-pathltrue)<.1;
    pathl(isinf(pathl)) = 0;
    pathlcount(isinf(pathlcount)) = 0;
    
%    connmat = logical(~isinf(pathl));
%    connmat(1:partsize+1:end) = 1;
    maxpathl = max(pathl,[],1);
    connmat2 = unique(connmat,'rows');
    clear indextmp pathltmp
    for iii = 1:size(connmat2,1)
       indextmp0 = find(connmat2(iii,:));
       indextmp(iii,1:max(size(indextmp0))) = indextmp0(:)';
       pathltmp = pathl(indextmp0,:);
       maxpathl2(iii)  = max(max(pathltmp))+1;
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%  Cut on pathlength at minpathlprep
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    checkminpathl = maxpathl2>=minpathl;               % set to true all of those partitions part of a path length that is too short
    indextmp2 = indextmp(checkminpathl,:);
    indextmp3 = unique(indextmp2);
    indextmp3(indextmp3==0) = [];
    indexminpathl = indextmp3;  
    if isempty(indexminpathl)
        indexminpathl = 1;
        display('All Paths too Short');
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%
%%%%%%%  Find the centers of the dense regions - conngroup are the
%%%%%%%  connected maxima
%%%%%%%
    for mm = 1:nclustersc
        [clusmed] = findmedoid_03(clusterconn(mm,:),2);
        clustermedoidsc(mm,1) = clusmed;   
    end  
    clustermedoidsc(~checkclussize) = 0;        
varinfoo = {'pathlcount' savepathl 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
varinfoo = {'pathl'      savepathl 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
varinfoo = {'pathcheck'  savepathl 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%
%%%  Re-Order the connection matrix to square-diagonal
%%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    [ppc,qqc,rrc,ssc,ttc,uuc] = dmperm(sparse(connmat));
    connperm = connmat(ppc,qqc);
varinfoo = {'connmat'    saveconn  0}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'connperm';
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    titleinfo1   = sprintf('Connection Matrix (permuted) - from (k,l)');
    titleinfo2   = sprintf('');
    xlabel1      = 'Partition #';
    xlabel2      = 'Partition #';
    datainfoo{1} = { eval(plotdataname) };
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 xlabel1 xlabel2};
    flaginfoo{1} = { plotconn printconn plotnow 1 0 };
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  SPY
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'conn';
    titleinfo1   = sprintf('%s Clustering into %d Clusters',upper(plotdataname),nclustersc);
    titleinfo2   = '';
    datainfoo{1} = { eval(sprintf('cluster%s',plotdataname)) clustermedoidsc };
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 };
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 1 plotmedoidsc};
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  PATCHES (CLUSTERS Without clustering - One Big cluster!)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
    titleconn         = titleinfo1;
    clusterconnect{1} = {clusterconn};
    clusterconnect{2} = {clustermedoidsc};
    clusterconnect{3} = {nclustersc};
    clusterconnect{4} = {titleconn};
    
    connreturn = {clusterconnect};
%%%%
%%%%   Save all of the clusters - Clusters now saved in the "Short" file
%%%%
%     varinfoo = {'clusterconn'     saveconn 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
%     varinfoo = {'clustermedoidsc' saveconn 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
%%%%
%%%%  Compute memory and timing variables for performance
%%%%
    tendconnpathl = now;
    durationnconnpathl = tendconnpathl-tstartconnpathl;
    display(sprintf('Ending Connection and Path Length Analysis at %s',datestr(datetime('now'))))
    tstartconnpathlt = datetime(datevec(tstartconnpathl));
    tendconnpathld   = datetime(datevec(tendconnpathl));
    timeconnpathl = rem(durationnconnpathl,1)*86400;
    display(sprintf('Connection and Path Length Analysis Duration: %s',datestr(timeconnpathl/86400, 'HH:MM:SS')));

    workspacee = whos;
    memusedconnpathl = sum([workspacee.bytes]);
%%%%
%%%%   Save all of the variables
%%%%
    varnamess = {varnamesshort{:} varnameslong{:} varnamestime{:}}; 
    for ii = 1:size(varnamess,2); eval(sprintf('global %s',varnamess{ii}));  end;
    saverightend01;
    profile off
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
elseif checkreconnpathl
    display('CONNPATHL files already exists and RECLUSTER CONNPATHL set.  CONNPATHL clustering analysis will be DONE.')
   
    loadname = 'init'; 
    varinfoo = {loadname,'''-regexp'',''^(?!deltaxl1|dircos|pathltrue|pathl1true|pathl1corr|dataindexminmax|dataptsminmax)\w'''};
    loadright1 = loadright03(varinfoo);for jj=1:size(loadright1,2);varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end;loadright1{jj}=[];end
    wgtmat = partkeepwgts*partkeepwgts';

    dataname = 'connpathl';
    dataname = sprintf('cluster%s',dataname);
    if ~exist(dataname)|isempty(eval(dataname))
        loadname = plotvars{mod(find(ismember(plotvars,dataname)),size(plotvars,1)),1};
        varinfoo = {loadname,'''short'''}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end;loadright1{jj}=[];end    
        varinfoo = {loadname,'''full'''};  loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end;loadright1{jj}=[];end    
    end    
   
%    clusterconnpathl = clustertmp2;
    nclustersc = size(clusterconn,1);
%%%%%%%  Find the centers of the dense regions
    for mm = 1:nclustersc
        [clusmed] = findmedoid_03(clusterconn(mm,:),1);
        clustermedoidsc(mm,1) = clusmed;
    end
    clustermedoidsc(~checkclussize) = 0;        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'conn';
    titleinfo1   = sprintf('%s Clustering into %d Clusters',upper(plotdataname),nclustersc);
    titleinfo2   = '';
    datainfoo{1} = { eval(sprintf('cluster%s',plotdataname)) clustermedoidsc };
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 };
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 1 plotmedoidsc};
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  PATCHES (CLUSTERS Without clustering - One Big cluster!)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    titleconn         = titleinfo1;
    clusterconnect{1} = {clusterconn};
    clusterconnect{2} = {clustermedoidsc};
    clusterconnect{3} = {nclustersc};
    clusterconnect{4} = {titleconn};
    
    connreturn = {clusterconnect};
%%%%
%%%%   Save all of the variables
%%%%
    varnamess = {varnamesshort{:} varnameslong{:} varnamestime{:}}; 
    for ii = 1:size(varnamess,2); if size(varnamess{ii},2)>0; eval(sprintf('global %s',varnamess{ii})); end; end;
    saverightend01;
    profile off
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
else
    display('Connection and Path Length files already exists and OVERWRITE Connection and Path Length set to ZERO.  Connection and Path Length analysis NOT DONE.')
    connreturn = {1};
end
close all
return 

    
    
