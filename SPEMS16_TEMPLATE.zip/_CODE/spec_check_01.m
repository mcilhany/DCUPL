clear all

npts = 40;
toevec = zeros(1,npts);
toevec(1) = 2;
toevec(2) = -1;
toemat = toeplitz(toevec);
nclusters = floor(npts/2    );
ii = 1;
while (ii<=nclusters)
    npts = max(size(toemat));
    nremove = floor(npts/(randsample(nclusters,1)));
    toemat(nremove,:) = [];
    toemat(:,nremove) = [];    
    nclusters = floor(npts/3);
    ii = ii+1;
end
% nremove = floor(npts/3);
% toemat(nremove,:) = [];
% toemat(:,nremove) = [];
% nremove = floor(npts/4);
% toemat(nremove,:) = [];
% toemat(:,nremove) = [];
% nremove = floor(npts/14);
% toemat(nremove,:) = [];
% toemat(:,nremove) = [];
% nremove = floor(npts/40);
% toemat(nremove,:) = [];
% toemat(:,nremove) = [];
[eigvecs,eigvals] = eig(toemat);
%[eigvecs,eigvals] = eig(toemat,ones(npts),'qz');
%[eigvecs,eigvals] = eig(toemat,ones(npts),'chol');
spy(eigvecs(:,1:30))
display('Press a key to continue...'); pause
plot(eigvecs(:,1),eigvecs(:,2),'o')
