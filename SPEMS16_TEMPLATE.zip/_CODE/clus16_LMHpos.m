function [ LMHposreturn ] = clus16_LMHpos(varargin)
close all force
profile off
warning off
% clearvars -except fileroot do* prepindex numprepfiles prepfiles prodrunnum prepindexstart prepindexend tstartfull tstartsingle
global fileroot shapestr prodrunnum prepindex fileprefix dataname 
global sigfigs smallpartnums3 partsize  
global dataptsminmax dataptspartkeep dataindexminmax dataindexpartkeep datapartkeepindex dataminmaxpartindex binadd2 datamin datamax datadelta 
global varnamesshort varnameslong varnamestime
global binadd2LMH datadeltaLMH partsizeLMH
varnamesshort = {'bignum','sigfigs','minpop','minpathl','threshdist','nvars','databins','datadeltaLMH','datamax','datamin','shapestr','partsizeLMH','partkeep','memusedLMHpos','dataindexpartkeep','binadd2LMH','clusterLMHpos','clustermedoidsh','nclustersh','clusterLMHposwgtp'};
varnameslong  = {''};
varnamestime  = {'timeLMHpos','tstartLMHpost','tendLMHposd'};
dataname      = 'LMHpos';

load(sprintf('%s/_DATA/prod/prod_prep_%04d_%04d.mat',fileroot,prodrunnum,prepindex));
display(sprintf('%04d - %s - Calculate LMHpos',prodrunnum,fileprefix))

checkfileLMHpos0 = ls(sprintf('%s/_DATA/%s/prod_%04d_%s_%s_*.mat',fileroot,shapestr,prodrunnum,dataname,fileprefix));
checkfileLMHpos  = logical(size(checkfileLMHpos0,2));
if checkfileLMHpos
   display('LMHpos clustering already done.');
end
checkgoLMHpos =  ~(checkfileLMHpos&(~checkoverwriteLMHpos));
checkreLMHpos =   checkgoLMHpos;
if checkgoLMHpos             % GO!!!!!!!
    display(sprintf('LMHpos files:  %1d OVERWRITE LMHpos :  %1d   LMHpos analysis will be DONE.',checkfileLMHpos,checkoverwriteLMHpos));
    tstartLMHpos = now;
    %profile on
    if plotall2==1
        plotLMHpos = 1;
    end
%
%   Load in the dataset formed in Initialize    
%
    loadname = 'init'; 
    varinfoo = {loadname,'''-regexp'',''^(?!deltar|deltaxl1|dircos|nn1|pathcount|pathltrue|pathl1true|pathl1corr|dataptsminmax|dataindexminmax)\w'''};
    loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%  Setting the bin numbers to 3 for LMHPos Clustering
basebins = 3;
%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for vari = 1:nvars
        databins(vari) = basebins; 
        datadeltaLMH(vari) = (maxx(vari)-minn(vari))/databins(vari);
        dataindexpartkeepL(:,vari) = floor((dataptspartkeep(:,vari)-minn(vari))/datadeltaLMH(vari));
        dataindexpartkeepL(dataindexpartkeepL(:,vari)>(databins(vari)-1),vari) = ceil(databins(vari)-1);
    end
    dataindexpartkeepL = dataindexpartkeepL+1;
%
    for vari = 1:nvars
        dataptstmp = dataptspartkeep(:,mapdataorder2(vari));
        binadd(:,vari) = ceil((dataptstmp-datamin(vari))/(datamax(vari)-datamin(vari))*basebins);
    end
    clear dataptstmp
%
%  Form the partition ID from the bin coordinates
%
    datasizegood = max(size(binadd));
    binaddress = zeros(datasizegood,1);
    binshift = 1;
    for vari = 1:nvars
        nbinss = basebins;
        databins(vari) = nbinss;
        binaddress(:) = binaddress(:) + (binadd(:,vari)-1)*binshift; 
        binshift = binshift*nbinss;
    end
    binaddress = binaddress+1;
    maxbinaddress = max(binaddress);
    clear bins*  binadd
%
%  Form a unique list of partition IDs
%
    [binaddu,u2,mapbintounique] = unique(binaddress);
    datasizepart = max(size(binaddu))
    binu = (0.5:datasizepart+0.5)';
    [wgtp,tmp2,mapuniquetowgts]= histcounts(mapbintounique,binu);
    clusterLMHposwgtp = wgtp';
    clear u2 tmp2 mapuniquetowgts
%
%   Form the partition list
%
    partkeep = binaddu;
    binaddresstmp = partkeep-1;
    binadd2LMH = zeros(max(size(binaddresstmp)),nvars);
    for vari = nvars:-1:1
        binshift = 1;
        for jj = 1:(vari-1)
            nbinss = basebins;
            binshift = binshift*nbinss;
        end
        binadd2LMH(:,vari) = floor(binaddresstmp/binshift)+1;
        binaddresstmp = binaddresstmp-(binadd2LMH(:,vari)-1)*binshift;
    end
    partsizeLMH = size(binadd2LMH,1)
    clear binu*  u2  binaddresstmp
%       
%   For LMHpos Clustering, the partitions ARE the clusters.
%
    numclusLMHpos = partsizeLMH;
    clusterLMHpos = zeros(numclusLMHpos,partsizeLMH);
    for mm = 1:numclusLMHpos
       clusterLMHpos(mm,1) = mm;
    end
    checkclus = sum(clusterLMHpos);
    clusterLMHpos(:,checkclus==0) = [];
    nclustersh = size(clusterLMHpos,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%
%%%%%%%  Find the centers of the dense regions - conngroup are the
%%%%%%%  connected maxima
%%%%%%%
    for mm = 1:nclustersh
        [clusmed] = findmedoid_03(clusterLMHpos(mm,:),5);
        clustermedoidsh(mm,1) = clusmed;   
    end  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'LMHpos';
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    titleinfo1   = sprintf('%s Clustering into %d Clusters',upper(plotdataname),nclustersh);
    titleinfo2   = sprintf('');
    datainfoo{1} = { eval(sprintf('cluster%s',plotdataname)) clustermedoidsh};
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 };
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 1 plotmedoidsc};
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  SCATTER
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    titleLMH      = titleinfo1;
    clusterLMH{1} = clusterLMHpos;
    clusterLMH{2} = clustermedoidsh;
    clusterLMH{3} = nclustersh;
    clusterLMH{4} = titleLMH;
    
    LMHposreturn = {clusterLMHpos};
%%%%
%%%%   Save all of the clusters - Clusters now saved in the "Short" file
%%%%
%     varinfoo = {'clusterLMHpos'     saveLMHpos 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
%     varinfoo = {'clustermedoidsh'   saveLMHpos 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
%     varinfoo = {'clusterLMHposwgtp' saveLMHpos 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
%%%%
%%%%  Compute memory and timing variables for performance
%%%%
    tendLMHpos = now;
    durationnLMHpos = tendLMHpos-tstartLMHpos;
    display(sprintf('Ending LMHpos Analysis at %s',datestr(datetime('now'))))
    tstartLMHpost = datetime(datevec(tstartLMHpos));
    tendLMHposd   = datetime(datevec(tendLMHpos));
    timeLMHpos = rem(durationnLMHpos,1)*86400;
    display(sprintf('LMHpos Analysis Duration: %s',datestr(timeLMHpos/86400, 'HH:MM:SS')));

    workspacee = whos;
    memusedLMHpos = sum([workspacee.bytes]);
%%%%
%%%%   Save all of the variables
%%%%
    varnamess = {varnamesshort{:} varnameslong{:} varnamestime{:}}; 
    for ii = 1:size(varnamess,2); if size(varnamess{ii},2)>0; eval(sprintf('global %s',varnamess{ii})); end; end;
    saverightend01;
    profile off
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
else
    display('LMHpos  files already exists and OVERWRITE LMHpos  set to ZERO.  LMHpos  analysis NOT DONE.')
    LMHposreturn = {1};
end
close all
return 

    
    



