%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%
%%%%    Save Variables properly (setting significant figures as well):
%%%%    Syntax:     saverightend01()
%%%%                Save all variables in the varaible list to disk
%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ saverightend1 ] = saverightend01

global fileroot shapestr prodrunnum prepindex fileprefix dataname 
global sigfigs smallpartnums3 partsize  
global varnamesshort varnameslong varnamestime

if ~isempty(varnameslong{1})
    varnamesss = {varnamesshort{:} varnameslong{:} varnamestime{:}};
else
    varnamesss = {varnamesshort{:} varnamestime{:}};
end    
for ii = 1:size(varnamesss,2); if size(varnamesss{ii},2)>0; eval(sprintf('global %s',varnamesss{ii})); end; end;
if partsize<smallpartnums3
    varnamess = {};
    if ~isempty(varnameslong{1})
        varnamess0 = { varnamesshort{:}, varnameslong{:} };
    else
        varnamess0 = { varnamesshort{:} };
    end
    jj = 0;
    for ii = 1:size(varnamess0,2)
        varnamee = varnamess0{ii};
        memtest = whos(varnamee);
        if memtest.bytes>0
            if ~iscell(eval(varnamee))
                if eval(sprintf('~islogical(%s)',varnamee))
                    eval(sprintf('%s = round(%s*10^sigfigs)/10^sigfigs;',varnamee,varnamee));
                end
            end
            jj = jj+1;
            varnamess{jj} = varnamess0{ii};
        end
    end
    varnamess = {varnamess{:}, varnamestime{:}};
    if exist(sprintf('%s/_DATA/%s/prod_%04d_%s_%s_full.mat',fileroot,shapestr,prodrunnum,dataname,fileprefix))
        save(sprintf('%s/_DATA/%s/prod_%04d_%s_%s_full.mat',fileroot,shapestr,prodrunnum,dataname,fileprefix),varnamess{:},'-append');
    else
        save(sprintf('%s/_DATA/%s/prod_%04d_%s_%s_full.mat',fileroot,shapestr,prodrunnum,dataname,fileprefix),varnamess{:});
    end
else
    if ~isempty(varnameslong{1});     
        varnamess = { varnameslong{:} };
        for ii = 1:size(varnamess,2)
            varnamee = varnamess{ii};
            if exist(varnamee)
                memtest = whos(varnamee);
                if memtest.bytes>0
                    if ~iscell(eval(varnamee))
                        if eval(sprintf('~islogical(%s)',varnamee))
                            eval(sprintf('%s = round(%s*10^sigfigs)/10^sigfigs;',varnamee,varnamee));
                        end
                    end
                    if memtest.bytes<(2^31-100)
                        save(sprintf('%s/_DATA/%s/prod_%04d_%s_%s_%s.mat',fileroot,shapestr,prodrunnum,dataname,fileprefix,varnamee),varnamee);
                    else
                        save(sprintf('%s/_DATA/%s/prod_%04d_%s_%s_%s.mat',fileroot,shapestr,prodrunnum,dataname,fileprefix,varnamee),varnamee,'-v7.3');
                    end
                end
                eval(sprintf('clear global %s',varnamee));
            end
        end
    end
    varnamess = { varnamesshort{:} };
    for ii = 1:size(varnamess,2)
        varnamee = varnamess{ii};
        if exist(varnamee)
            memtest = whos(varnamee);
            if memtest.bytes>0
                if ~iscell(eval(varnamee))
                    if eval(sprintf('~islogical(%s)',varnamee))
                        eval(sprintf('%s = round(%s*10^sigfigs)/10^sigfigs;',varnamee,varnamee));
                    end
                end
            end
        end
    end
    save(sprintf('%s/_DATA/%s/prod_%04d_%s_%s_short.mat',fileroot,shapestr,prodrunnum,dataname,fileprefix),varnamesshort{:})
    save(sprintf('%s/_DATA/%s/prod_%04d_%s_%s_time.mat',fileroot,shapestr,prodrunnum,dataname,fileprefix),varnamestime{:})
end

return
    