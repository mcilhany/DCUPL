function [ losmarkerstart,losmarkerend,histtlosmax ] = findmarkers_01(varargin)

    histt          = varargin{1};
    histbins       = varargin{2};
    fixedbins      = varargin{3};
    peakthresh0    = varargin{4};
    threshmin0     = varargin{5};
    resurgethresh0 = varargin{6};
    stddevnum      = varargin{7};
    nsmooth        = varargin{8};
    flagtype       = varargin{9};       %  flagtype =1 use maximum visibility,   flagtype=2  use highest mutual visibility
    flagtype2      = varargin{10};       %  flagtype2=1 make plots

    histbins(end+1) = histbins(end)+0.1;
    maxhisttv  = max(histt);
    maxhistt   = max(size(histt));
    for nn = 1:nsmooth
        histshiftleft       = circshift(histt,[0 +1]);
        histshiftleft(1)    = 0;
        histt2              = (histshiftleft+histt)/2;
        histshiftright      = circshift(histt,[0 -1]);
        histshiftright(end) = 0;
        histt3              = (histshiftright+histt)/2;
        histt               = (histt2+histt3)/2;
    end
    histtplus = histt>0;
    histt = histt.*histtplus;
    maxhistv   = max(histt);
    histtnz = histt(histt>0);
    histtlow = histtnz(histtnz<(maxhistv/2));


    histt = [0 0 histt];
    histt = [histt 0 0];
    maxhistt  = max(size(histt));
    if flagtype2==1
        x1 =  1:maxhistt;
        bar(x1,histt)
        axis([0 maxhistt+1 0 max(histt)+1])
        ylim auto
    end
    % peakthresh0 =  std(histt)/maxhistv;
    % resurgethresh0 = peakthresh0;
    % 
    peakthresh = 1-peakthresh0;
    resurgethresh = resurgethresh0+1;
    diff1h = diff(histt);
    diff1h(end+1) = 0;
    diff2h = diff(diff1h);
    histt(1)    = [];
    diff1h(end) = [];
    diff1h(1)   = [];
    histt(end)  = [];
    diff2h(end) = [];
    maxdiff1h = max(size(diff1h));
    maxdiff2h = max(size(diff2h));
    maxhistt  = max(size(histt));
    x1 =  1:maxhistt;
    x2 = (1:maxdiff1h);
    x3 = (1:maxdiff2h);

    if flagtype2==1
        clf
        subplot(3,1,1)
        bar(x1,histt)
        axis([0 maxhistt+1 0 max(histt)+1])
        subplot(3,1,2)
        bar(x2,diff1h,'r')
        axis([0 maxdiff1h+1 -100 5000])
        ylim auto
        subplot(3,1,3)
        bar(x3,diff2h,'g')
        axis([0 maxdiff2h+1 -12 5])
        ylim auto
    end

    kkstart = 0;
    kkend   = 0;
    maxpop  = 0;
    endold  = 0;
    markerstartwait = 0;
    markerendwait   = 1;
    for ii = 1:maxhistt
        if markerendwait==0
            if diff1h(ii)>=0                % Look for the end marker
                if histt(ii)<maxpop*peakthresh
                    if doresurge==0
                        kkend               = kkend+1;
                        losmarkerendf(kkend) = ii;
                        markerendwait       = 1;
                        markerstartwait     = 0;
                        maxpop              = 0; 
                        endold              = histt(ii);
                    else
                        kkend               = kkend;
                        losmarkerendf(kkend) = ii;
                        losmarkerstartf(kkstart) = [];
                        kkstart             = kkstart-1;
                        markerendwait       = 1;
                        markerstartwait     = 0;
                        maxpop              = 0; 
                        endold              = histt(ii);
                    end
                end
            end
        end
        if markerstartwait==0           % Start of PEAK
            if diff1h(ii)>0             
                if diff2h(ii)>0
                    kkstart                 = kkstart+1;
                    losmarkerstartf(kkstart) = ii;
                    markerstartwait         = 1;
                end
            end
        elseif diff2h(ii)<0                 % PEAKED
            if diff1h(ii)<0
                markerendwait = 0;
%                    if histt(ii)<endold*resurgethresh
                if maxpop<endold*resurgethresh
                    doresurge = 1;
                else 
                    doresurge = 0;
                end
            end
        end
        if histt(ii)>maxpop
            maxpop = histt(ii);
            maxbin = ii;
        end
    end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%    Reverse order
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    histto  = histt;
    histto(end) = [];
    histto(1)   = [];
    histtr  = fliplr(histto);
    histtr = [0 0 histtr];
    histtr = [histtr 0 0];
    maxhistt  = max(size(histtr));
    if flagtype2==1
        x1r =  1:maxhistt;
        bar(x1r,histtr)
        axis([0 maxhistt+1 0 max(histt)+1])
        ylim auto
    end

    % peakthresh0 =  std(histt)/maxhistv;
    % resurgethresh0 = peakthresh0;
    % 
    peakthresh = 1-peakthresh0;                 %  XXX% down  from the top of the last peak reached
    resurgethresh = resurgethresh0+1;           %  XXX% above the last basintop of the last peak reached
    diff1hr = diff(histtr);
    diff1hr(end+1) = 0;
    diff2hr = diff(diff1hr);
    histtr(1)    = [];
    diff1hr(end) = [];
    diff1hr(1)   = [];
    histtr(end)  = [];
    diff2hr(end) = [];
    maxdiff1h = max(size(diff1hr));
    maxdiff2h = max(size(diff2hr));
    maxhistt  = max(size(histtr));

    kkstart = 0;
    kkend   = 0;
    maxpop  = 0;
    endold  = 0;
    markerstartwait = 0;
    markerendwait   = 1;
    for ii = 1:maxhistt
        if markerendwait==0
            if diff1hr(ii)>=0                % Look for the end marker
                if histtr(ii)<maxpop*peakthresh
                    if doresurge==0
                        kkend               = kkend+1;
                        losmarkerendr(kkend) = ii;
                        markerendwait       = 1;
                        markerstartwait     = 0;
                        maxpop              = 0; 
                        endold              = histtr(ii);
                    else
                        kkend               = kkend;
                        losmarkerendr(kkend) = ii;
                        losmarkerstartr(kkstart) = [];
                        kkstart             = kkstart-1;
                        markerendwait       = 1;
                        markerstartwait     = 0;
                        maxpop              = 0; 
                        endold              = histtr(ii);
                    end
                end
            end
        end
        if markerstartwait==0           % Start of PEAK
            if diff1hr(ii)>0             
                if diff2hr(ii)>0
                    kkstart                 = kkstart+1;
                    losmarkerstartr(kkstart) = ii;
                    markerstartwait         = 1;
                end
            end
        elseif diff2hr(ii)<0                 % PEAKED
            if diff1hr(ii)<0
                markerendwait = 0;
%                    if histtr(ii)<endold*resurgethresh
                if maxpop<endold*resurgethresh
                    doresurge = 1;
                else 
                    doresurge = 0;
                end
            end
        end
        if histtr(ii)>maxpop
            maxpop = histtr(ii);
            maxbin = ii;
        end
    end

    lossrr = maxhistt - losmarkerstartr + 1;
    loserr = maxhistt - losmarkerendr   + 1;
    losr   = fliplr(lossrr);
    loer   = fliplr(loserr);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%  Combine the Forward and Reverse markers
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    losmarkers   = [[losmarkerstartf'; loer'] [losmarkerendf'; losr']];
%    losmarkers   = [[loer'; loer'] [losr'; losr']];
%    losmarkers   = [[losmarkerstartf'; losmarkerstartf'] [losmarkerendf'; losmarkerendf']];
    slosmarkers  = sortrows(losmarkers);
    uslosmarkers = unique(slosmarkers,'rows');
    for ii = size(uslosmarkers,1):-1:2
        if uslosmarkers(ii,1)==uslosmarkers(ii-1,1)
            uslosmarkers(ii,:) = [];
        end
    end
    for ii = size(uslosmarkers,1):-1:2
        if uslosmarkers(ii,2)==uslosmarkers(ii-1,2)
            uslosmarkers(ii,:) = [];
        end
    end
    uslosstart = uslosmarkers(:,1)';
    uslosend   = uslosmarkers(:,2)';
    for ii = 1:size(uslosstart,2)
        histtuslos{ii,:} = histt(uslosstart(ii):uslosend(ii));
    end
    for ii = 1:size(uslosstart,2)
        histtmax(ii) = max(histtuslos{ii,:});
    end
    histtindex = 1:size(uslosstart,2);
    histtlist = histtindex(histtmax>(std(histt)/4));
    for ii = 1:size(histtlist,2)
        histtlims{ii,:} = 0;
    end
    for ii = 1:size(uslosstart,2)
        histtdist = abs(histtindex(ii)-histtlist);
        [hxxx,histtdistind] = min(histtdist);
        histtlims{histtdistind,:} = [histtlims{histtdistind,:} uslosstart(ii) uslosend(ii)];
    end
    for ii = 1:size(histtlist,2)
        markertmp = histtlims{ii,:};
        markertmp(markertmp==0) = [];
        markerlosstartt(ii) = min(markertmp);
        markerlosendt(ii)   = max(markertmp);
    end
    markers = [markerlosstartt markerlosendt];
    markersu = unique(sort(markers));
    losmarkerstart = markersu(1:end-1);
    losmarkerend   = markersu(2:end);

    for ii = 1:size(losmarkerstart,2)
        histtlos{ii,:} = histt(losmarkerstart(ii):losmarkerend(ii));
    end
    for ii = 1:size(losmarkerstart,2)
        histtlosmax(ii) = max(histtlos{ii,:});
    end

    if flagtype2==1
        subplot(2,1,1)
       clf
%        clf('reset');set(gcf, 'Position', [1 1 1600 1000]);
        x1 =  1:(maxhistt);
        bar(histbins(x1),histt,max(histbins)/(1.5*sqrt(fixedbins)))
       title(sprintf('histogram       #bins = %d    #smooths=%d       drop thresh = %4.2f - resurge thresh = %4.2f',fixedbins,nsmooth,peakthresh0,resurgethresh0))
        %ylim auto
        breaksize = std(histt)/stddevnum;
        line([histbins(losmarkerstart);histbins(losmarkerstart)]   ,repmat([-1;breaksize],1,max(size(losmarkerstart))),'LineWidth',3,'color','m')
        line([histbins(losmarkerend);  histbins(losmarkerend)]-0.25,repmat([-1;breaksize],1,max(size(losmarkerend)))  ,'LineWidth',3,'color','c')
        %ylim([0 150])
        axis([0 histbins(maxhistt)+1 0 max(histt)+1])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        
%%%% For the data set: data3d2    bins:200 thresh:0.05,1,4  histo:100,0.25,0.01,0.33,0smooths        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                
%         axis([0 histbins(maxhistt)+1 0 (max(histt))*1.05])
%         xarrow = [0.36 0.530];
%         yarrow = [0.850000 0.87];
%         aa = annotation('textarrow',xarrow,yarrow,'String','Greatest Mutual Visibility'); 
%         aa.FontSize = 24;
%         aa.LineWidth = 3;
%         xarrow = [maxhistt*0.8 0.74];
%         yarrow = [0.55 0.35];
%         aa = text(double(histbins(maxhistt)*0.80),maxhisttv*0.50,'Maximal Visibility'); 
%         aa.FontSize = 24;
%         aa.LineWidth = 3;
%         xarrow = [0.890 0.89 ];
%         yarrow = [0.45 0.20];
%         aa = annotation('textarrow',xarrow,yarrow,'String',''); 
%         aa.LineWidth = 3;
%         xlabel('Number of Seen (LOS) partitions from any other partition','Fontsize',18)
%         ylabel('Counts','Fontsize',18)
%         axx = gca;
%         axx.FontSize = 16;
%             export_fig('los_visibility_histo_01.pdf','-m3');        
        display('Press a key to continue...'); pause
        subplot(4,1,3)
        bar(x2,diff1h,'r')
        title('First Derivative')
        axis([0 maxdiff1h+1 -11 5])
        ylim auto
        subplot(4,1,4)
        bar(x3,diff2h,'g')
        title('Second Derivative')
        axis([0 maxdiff2h+1 -12 5])
        ylim auto
        % pause
        % clf
        % hold on
        % bar(x1,histt)
        % bar(x2,diff1h,'FaceColor','none','EdgeColor','r','LineWidth',3)
        % bar(x3,diff2h,'FaceColor','none','EdgeColor','g','LineWidth',3)
        %saveplott = input('Save plot?','s');
%             if exist('saveplott')
%             if strcmp(saveplott,'y')
%                 display('Gotcha')
%                 export_fig(sprintf('hist_start_stop_%03d.jpg',randi(999)),'-m2')
%                 saveas(gcf,sprintf('hist_start_stop_%03d.jpg',randi(999)))
%             end
%             end
    end

return








 