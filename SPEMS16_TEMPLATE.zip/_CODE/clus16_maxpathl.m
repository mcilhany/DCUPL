function [ maxpathlreturn ] = clus16_maxpathl(varargin)
close all force
profile off
warning off
global fileroot shapestr prodrunnum prepindex fileprefix dataname 
global sigfigs smallpartnums3 partsize  
global dataptsminmax dataptspartkeep dataindexminmax dataindexpartkeep datapartkeepindex dataminmaxpartindex binadd2 datamin datamax datadelta 
global varnamesshort varnameslong varnamestime
varnamesshort = {'bignum','sigfigs','minpop','minpathl','minpopglobalpathl','threshdist','nvars','databins','datadelta','datamax','datamin','shapestr','partsize','partkeep','partkeepind','memusedmaxpathl','indexminpathl','clustermaxpathl','clustermedoidsp','nclustersp'};
varnameslong  = {''};
varnamestime  = {'timemaxpathl','tstartmaxpathlt','tendmaxpathld'};
dataname      = 'maxpathl';
global pathl wgtmat

load(sprintf('%s/_DATA/prod/prod_prep_%04d_%04d.mat',fileroot,prodrunnum,prepindex));
display(sprintf('%04d - %s - Path Length Weighted Clustering',prodrunnum,fileprefix))

checkfilemaxpathl0 = ls(sprintf('%s/_DATA/%s/prod_%04d_%s_%s_*.mat',fileroot,shapestr,prodrunnum,dataname,fileprefix));
checkfilemaxpathl  = logical(size(checkfilemaxpathl0,2));
if checkfilemaxpathl
   display('MAXPATHL clustering already done.');
end
checkgomaxpathl =  ~(checkfilemaxpathl&(~checkoverwritemaxpathl));
checkremaxpathl =   (checkfilemaxpathl&(checkreclustermaxpathl));
if checkgomaxpathl             % GO!!!!!!!
    display(sprintf('MAXPATHL files:  %1d OVERWRITE MAXPATHL:  %1d   MAXPATHL analysis will be DONE.',checkfilemaxpathl,checkoverwritemaxpathl));

    tstartmaxpathl = now;
    %profile on
    loadname = 'init'; 
    varinfoo = {loadname,'''-regexp'',''^(?!deltaxl1|nn1|dircos|deltar|pathltrue|pathl1true|pathl1corr|pathcount)\w'''};
    loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end
    wgtmat = partkeepwgts*partkeepwgts';

    loadname = 'connpathl'; 
    varinfoo = {loadname,'''-regexp'',''^(?!pathcheck|pathlcount)\w'''};
    loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end

    if plotall2==1
        plotmaxpathl = 1;
    end
    clustershow   = 1e6;
    coloradjustt = 2.1;
    markersizee = 24;

    indexxs(:,1) = 1:partsize;
    maxpathl = max(pathl,[],1); 
    pathltmp        = pathl(indexminpathl,:);
    pathltmp        = pathltmp(:,indexminpathl);
    partkeepwgtstmp = partkeepwgts(indexminpathl);
    indexxstmp      = 1:max(size(indexminpathl)); 
    %indexxstmp      = indexxs(indexminpathl); 
    %nn1tmp          = nn1(indexminpathl,:);
    %nn1tmp          = nn1tmp(:,indexminpathl);
    %pathcounttmp    = pathcount(indexminpathl,:);
    %pathcounttmp    = pathcounttmp(:,indexminpathl);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%
%%%%%  From here on, the index is for the shortened list ONLY, use
%%%%%  indexminpathl to map back to the original index
%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    pathlnum = ceil(sqrt(nvars)/pathlgridsize);
    pathlnum = 1;
    maxl = max(max(pathl));
    for iii = 1:max(size(indexxstmp))
        clear ccc ddd ddd0 eee eeee fff ggg
        ccc = [pathltmp(iii,:)/pathlnum; partkeepwgtstmp'; indexxstmp]';
        ccc(ccc(:,1)==0,:) = [];
        ccc = vertcat([0 partkeepwgtstmp(iii) indexxstmp(iii)],ccc);
    %    ccc = floor(ccc);
        ccc = ceil(ccc);
        eee0 = sortrows(ccc,[1 2]);
    %    eee0 = unique(ccc,'rows');
        eeee = diff(eee0(:,1));
        eeee = [eeee; 1 ];
        fff = [eee0, eeee];
    %    ggg = fff(fff(:,4)==1,:);
        ggg = fff(fff(:,4)>0,:);
        neighborx = ggg(:,1);
        popy = ggg(:,2);
        indexm = ggg(:,3);   
        popmaxl = popy(1);
        indexmaxl = indexm(1);
        checkmax = 0;
        jjj = 1;
        while checkmax==0
            if popy(jjj)>minpopglobalpathl
                if popy(jjj)>popmaxl
                    popmaxl = popy(jjj);
                    indexmaxl = indexm(jjj);
                end
            end
                if popy(jjj)<popmaxl*threshpeak
                    if popy(jjj)>0
                        checkmax = 1;
                    end
                end
            jjj = jjj+1;
            if jjj>size(popy,1)
                checkmax = 1;
            end
        end
        maxx0(iii,:) = [popmaxl, indexmaxl];           %  maxx0 has the population and the index for each maxima found
    end
%%%%%%%%%%%% Sort by the weights so that the greater peaks come first in
%%%%%%%%%%%% the list
    maxx1 = sortrows(maxx0,1);
    maxx1 = unique(maxx1,'rows');
% Inheritance
    maxx00 = maxx0;                                                             %  maxx00 - pop + an index of each maxima found with one
    for iii = 1:size(maxx1,1)                                                   %      entry per partition pointing to a local maxima
        maxxindout  = find(maxx00(:,2)==maxx1(iii,2));                           %  FULL1 index
    %    maxxindout2 = find(indexxs(indexminpathl)==maxx(iii,2));
        maxxindout2 = find(indexxstmp==maxx1(iii,2));                            %  FULL1 index
%%%%%%%%%%%%%% update the indices to "inherit" the higher peak weight
        maxx0(maxxindout,2) = maxx0(maxxindout2,2);                             %  maxx0 - a "pointer" to each maxima for each partition 
    end
    clear maxxindout2 
    maxx2 = unique(maxx0(:,2),'rows');
    for iii = 1:size(maxx2,1)
        maxxindout  = find(maxx0(:,2)==maxx2(iii));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%  This could be changed to the sum of the weights instead of the
%%%%%%%%  sum of the partitions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        maxx0(maxxindout,1) = size(maxxindout,1);                               %  maxx0 - set the first column to the number of partitions pointing to a maxima
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        clear maxxindout
    %    maxx0(maxxindout,1) = sum(maxx0(:,2)==maxx1(iii));
    end
    maxx3 = sortrows(maxx0,1);
    maxx3 = unique(maxx3,'rows');
    maxx3 = flipud(maxx3);
    %maxxl = unique(maxx(:,2));
    %maxxl = maxx(maxx(:,1)>=minpathl,2);
    maxxl = maxx3(:,2);

    losislandsize = 0;

    nclusmaxpathl = max(size(maxxl));
    clustertmp = zeros(nclusmaxpathl,partsize);
    for ii = 1:nclusmaxpathl
        clusterind11(1,:) = indexminpathl(maxx0(:,2)==maxxl(ii));
        clustertmp(ii,1:size(clusterind11,2)) = clusterind11;
        clear clusterind11
    end
    clustertmp(sum(clustertmp,2)==0,:)=[];
    clustertmpc = sum(clustertmp,1);
    clustertmp(:,clustertmpc==0) = [];
    [clustertmp1,ctmp1a,ctmp1b] = unique(clustertmp,'rows');
    clustertmp2 = clustertmp1(ctmp1b,:);
    clustertmp2log = logical(clustertmp2);
    clustertmp2size  = sum(clustertmp2log,2);
    [ca,cb] = sort(clustertmp2size,'descend');
    %spy(clustertmp2log(cb,:))
    clustertmp22 = clustertmp2(cb,:);

    clussize = min([size(clustertmp22,1) clustershow]);
    clustertmp2 = clustertmp22(1:clussize,:);
    clustermaxpathl = clustertmp2;
    checkclussize = (sum(clustermaxpathl>0,2)>minpathlprep);

    nclustersp = size(clustermaxpathl,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%
%%%%%%%  Find the centers of the dense regions - conngroup are the
%%%%%%%  connected maxima
%%%%%%%
    for mm = 1:nclustersp
        [clusmed] = findmedoid_03(clustermaxpathl(mm,:),2);
        clustermedoidsp(mm,1) = clusmed;   
    end
    clustermedoidsp(~checkclussize) = 0;        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'maxpathl';
    titleinfo1   = sprintf('%s Clustering into %d Clusters',upper(plotdataname),nclustersp);
    titleinfo2   = '';
    datainfoo{1} = { eval(sprintf('cluster%s',plotdataname)) clustermedoidsp };
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 };
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 1 plotmedoidsc};
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  PATCHES (CLUSTERS Without clustering - One Big cluster!)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    titlemaxpathl      = titleinfo1;
    clustermaxpathlength{1} = {clustermaxpathl};
    clustermaxpathlength{2} = {clustermedoidsp};
    clustermaxpathlength{3} = {nclustersp};
    clustermaxpathlength{4} = {titlemaxpathl};
    maxpathlreturn     = {clustermaxpathl};
%%%%
%%%%   Save all of the clusters - Clusters now saved in the "Short" file
%%%%
%     varinfoo = {'clustermaxpathl' savemaxpathl 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
%     varinfoo = {'clustermedoidsp' savemaxpathl 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
%%%%
%%%%  Compute memory and timing variables for performance
%%%%
    tendmaxpathl = now;
    durationnmaxpathl = tendmaxpathl-tstartmaxpathl;
    display(sprintf('Ending MAXPATHL Analysis at %s',datestr(datetime('now'))))
    tstartmaxpathlt = datetime(datevec(tstartmaxpathl));
    tendmaxpathld   = datetime(datevec(tendmaxpathl));
    timemaxpathl = rem(durationnmaxpathl,1)*86400;
    display(sprintf('MAXPATHL Analysis Duration: %s',datestr(timemaxpathl/86400, 'HH:MM:SS')));

    workspacee = whos;
    memusedmaxpathl = sum([workspacee.bytes]);
%%%%
%%%%   Save all of the variables
%%%%
    varnamess = {varnamesshort{:} varnameslong{:} varnamestime{:}}; 
    for ii = 1:size(varnamess,2); if size(varnamess{ii},2)>0; eval(sprintf('global %s',varnamess{ii})); end; end;
    saverightend01;
    profile off
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
elseif checkremaxpathl
    display('MAXPATHL files already exists and RECLUSTER MAXPATHL set.  MAXPATHL clustering analysis will be DONE.')
   
    loadname = 'init'; 
    varinfoo = {loadname,'''-regexp'',''^(?!deltaxl1|dircos|deltar|pathltrue|pathl1true|pathl1corr|dataindexminmax|dataptsminmax)\w'''};
    loadright1 = loadright03(varinfoo);for jj=1:size(loadright1,2);varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end;loadright1{jj}=[];end
    wgtmat = partkeepwgts*partkeepwgts';

    loadname = 'connpathl'; 
    varinfoo = {loadname,'''-regexp'',''^(?!pathcheck|pathlcount)\w'''};
    loadright1 = loadright03(varinfoo);for jj=1:size(loadright1,2);varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end;loadright1{jj}=[];end

    dataname = 'maxpathl';
    dataname = sprintf('cluster%s',dataname);
    if ~exist(dataname)|isempty(eval(dataname))
        loadname = plotvars{mod(find(ismember(plotvars,dataname)),size(plotvars,1)),1};
        varinfoo = {loadname,'''short'''}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end;loadright1{jj}=[];end    
        varinfoo = {loadname,'''full'''};  loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end;loadright1{jj}=[];end    
    end    
   
%    clustermaxpathl = clustertmp2;
    nclustersp = size(clustermaxpathl,1);
%%%%%%%  Find the centers of the dense regions
    for mm = 1:nclustersp
        [clusmed] = findmedoid_03(clustermaxpathl(mm,:),1);
        clustermedoidsp(mm,1) = clusmed;
    end
    clustermedoidsp(~checkclussize) = 0;        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'maxpathl';
    titleinfo1   = sprintf('%s Clustering into %d Clusters',upper(plotdataname),nclustersp);
    titleinfo2   = '';
    datainfoo{1} = { eval(sprintf('cluster%s',plotdataname)) clustermedoidsp };
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 };
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 1 plotmedoidsc};
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  CLUSTERS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    titlemaxpathl      = titleinfo1;
    clustermaxpathl{1} = {clustermaxpathl};
    clustermaxpathl{2} = {clustermedoidsp};
    clustermaxpathl{3} = {nclustersp};
    clustermaxpathl{4} = {titlemaxpathl};
    maxpathlreturn     = {clustermaxpathl};%%%%
%%%%   Save all of the variables
%%%%
    varnamess = {varnamesshort{:}}; 
    for ii = 1:size(varnamess,2); if size(varnamess{ii},2)>0; eval(sprintf('global %s',varnamess{ii})); end; end;
    saverightend01;
    profile off
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
else
    display('MAXPATHL files already exists and OVERWRITE MAXPATHL set to ZERO.  MAXPATHL analysis NOT DONE.')
    maxpathlreturn = {1};
end
close all
return 


















