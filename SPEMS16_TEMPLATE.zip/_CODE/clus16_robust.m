function [ robustreturn ] = clus16_robust(varargin)
close all force
profile off
warning off
global fileroot shapestr prodrunnum prepindex fileprefix dataname 
global sigfigs smallpartnums3 partsize  
global dataptsminmax dataptspartkeep dataindexminmax dataindexpartkeep datapartkeepindex dataminmaxpartindex binadd2 datamin datamax datadelta 
global varnamesshort varnameslong varnamestime
varnamesshort = {'bignum','sigfigs','minpop','minpathl','minpopglobalpathl','threshdist','nvars','databins','datadelta','datamax','datamin','shapestr','partsize','partkeep','partkeepind','memusedrobust','indexminpathl','clusterrobust'};
varnameslong  = {''};
varnamestime  = {'timerobust','tstartrobustt','tendrobustd'};
dataname      = 'robust';
global pathl wgtmat clustertot

load(sprintf('%s/_DATA/prod/prod_prep_%04d_%04d.mat',fileroot,prodrunnum,prepindex));
display(sprintf('%04d - %s - Path Length Weighted Clustering',prodrunnum,fileprefix))

checkfilerobust0 = ls(sprintf('%s/_DATA/%s/prod_%04d_%s_%s_*.mat',fileroot,shapestr,prodrunnum,dataname,fileprefix));
checkfilerobust  = logical(size(checkfilerobust0,2));
if checkfilerobust
   display('ROBUST clustering already done.');
end
checkgorobust =  ~(checkfilerobust&(~checkoverwriterobust));
checkrerobust =   (checkfilerobust&(checkreclusterrobust));
if checkgorobust             % GO!!!!!!!
    display(sprintf('ROBUST files:  %1d OVERWRITE ROBUST:  %1d   ROBUST analysis will be DONE.',checkfilerobust,checkoverwriterobust));

    tstartrobust = now;
    %profile on
    loadname = 'init'; 
    varinfoo = {loadname,'''-regexp'',''^(?!deltaxl1|nn1|dircos|deltar|pathltrue|pathl1true|pathl1corr|pathcount)\w'''};
    loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end
    wgtmat = partkeepwgts*partkeepwgts';

%    loadname = 'connpathl'; 
%    varinfoo = {loadname,'''-regexp'',''^(?!pathcheck|pathlcount)\w'''};
%    loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end

    if plotall2==1
        plotrobust = 1;
    end
    threshmajority = 0.75;
    clustershow    = 1e6;
    coloradjustt   = 2.1;
    markersizee    = 24;
%    dorobust1      = 0;
%    dorobust2      = 1;
%    dorobust3      = 0;
%    dorobust4      = 0;
    
    clear loadname
    clusterfiles = ls(sprintf('%s/_DATA/%s/prod_%04d_*_%s_short*.mat',fileroot,shapestr,prodrunnum,fileprefix));
    clusterfilelist = [1 3 5 6 7 8 10];
    clusterf  = {'kmeanmeds','maxglobal','connpathl','maxpathl','maxvismut','spectral','LMHpos'};
    for ii = 1:7
        ii
%        load(sprintf('../_DATA/%s/%s',clusterfiles(ii,:)));
         loadname = clusterf{ii}; 
         varinfoo = {loadname,'''short'''};
         loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end
    end
    for jj = 1:size(clusterspectral,1) 
        tmpp = clusterspectral{jj,1};
        varnames=sprintf('clusterspectral%02d',jj);
        eval(sprintf('%s=cell2mat(tmpp);',varnames));
    end
    for jj = 1:size(clusterspectral,1) 
        tmpp = clusterspectral{jj,2};
        varnames=sprintf('clustermedoidss%02d',jj);
        eval(sprintf('%s=cell2mat(tmpp);',varnames));
    end
    for jj = 1:size(clusterspectral,1) 
        tmpp = clusterspectral{jj,3};
        varnames=sprintf('nclusterss%02d',jj);
        eval(sprintf('%s=cell2mat(tmpp);',varnames));
    end
    for jj = 1:size(clusterspectral,1) 
        tmpp = clusterspectral{jj,4};
        varnames=sprintf('titlespectral%02d',jj);
        eval(sprintf('%s=cell2mat(tmpp);',varnames));
    end    
    indexxs = 1:partsize;

%    clusternames  = {'kmeans','kmedoids','maxglobal','maxpathl','conn','maxvis','maxmut','spectral01','spectral02','spectral03','spectral04','spectral05','spectral06','spectral07','spectral08','spectral09','spectral10','spectral11','spectral12','spectral13','spectral14','spectral15','spectral16','spectral17','spectral18','LMHpos'};
    clusternames  = {'kmeans','kmedoids','maxglobal','maxpathl','conn','maxvis','maxmut','spectral01','spectral02','spectral03','spectral04','spectral05','spectral06','spectral07','spectral08','spectral09','spectral10','spectral11','spectral12','spectral13','spectral14','spectral15','spectral16','spectral17','spectral18'};
    numalgorithms = size(clusternames,2);
    clustertotal = zeros(numalgorithms,partsize);
    for ii = 1:max(size(clusternames))
        eval(sprintf('clustercurrent = cluster%s;',clusternames{ii}));
        clustercurrsize = size(clustercurrent,1);
        for mm = 1:clustercurrsize
            clustertotal(ii,indexxs(clustercurrent(mm,clustercurrent(mm,:)>0))) = mm;
        end
    end
    
    
    
    
    ndims    = numalgorithms;
    ndata    = size(clustertotal,2); 
    dataa    = clustertotal;
    [dataas0,sortpartkeep]   = sortrows(dataa');
    dataas   = dataas0';
    [dataass,dataassi]  = sortrows(dataas);
    dataad   = zeros(ndims,ndata);
    dataadd  = zeros(ndims,ndata);
    for ii = 1:ndims
       dataad(ii,2:end)  = diff(dataas(ii,:)); 
       dataadd(ii,2:end) = diff(dataass(ii,:)); 
    end
    dataadl  = (dataad~=0);
    dataaddl = (dataadd~=0);
    dataaddlsum = sum(dataaddl);
    spy(dataaddl,10)
    %set(ggcf,'Markersize',10)
    axis fill
    maxdiffs =     max(dataaddlsum);
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%    
%%%%%%%%%    Any change of a cluster algorithm advances the Cluster ID
%%%%%%%%%    
%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
if dorobust1==1
    threshmin = 1;
    sumdataadl  = sum(dataadl);
    clid = 1;
    clusterrobust1 = zeros(1,ndata);
    cumchange = zeros(ndims,1);
    for ii = 1:ndata
%        dataass
%        dataaddl
        currentchange = dataadl(:,ii)~=0;
        cumchange = (cumchange + currentchange)>0;
        if sum(cumchange) < threshmin
            clusterrobust1(ii) = clid;
        else
            clid = clid + 1;
            clusterrobust1(ii) = clid;
            cumchange = zeros(ndims,1);
        end
    end
    mm = 0;
    clusterlast = 0;
    clustertmp = zeros(clid,ndata);
    counterr = 0;
    for kk = 1:ndata
        counterr = counterr+1;
        if clusterrobust1(kk)~=clusterlast
            mm = mm+1;
            counterr = 1;
            clustertmp(mm,counterr) = sortpartkeep(kk);
%            clustertmp(mm,counterr) = kk;
            clusterlast = clusterrobust1(kk);
        else
            clustertmp(mm,counterr) = sortpartkeep(kk);
%            clustertmp(mm,counterr) = kk;
        end
    end
    clustertmp(sum(clustertmp,2)==0,:)=[];
    clustertmpc = sum(clustertmp,1);
    clustertmp(:,clustertmpc==0) = [];
    [clustertmp1,ctmp1a,ctmp1b] = unique(clustertmp,'rows');
    clustertmp2 = clustertmp1(ctmp1b,:);
    clustertmp2log = logical(clustertmp2);
    clustertmp2size  = sum(clustertmp2log,2);
    [ca,cb] = sort(clustertmp2size,'descend');
    %spy(clustertmp2log(cb,:))
    clustertmp22 = clustertmp2(cb,:);

    clussize = min([size(clustertmp22,1) clustershow]);
    clustertmp2 = clustertmp22(1:clussize,:);

    clusterrobust1 = clustertmp2;
    nclustersr1 = size(clusterrobust1,1);
    checkclussize = (sum(clusterrobust1>0,2)>minpathlprep);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%  Find the centers of the dense regions - conngroup are the  connected maxima
    for mm = 1:nclustersr1
        [clusmed] = findmedoid_03(clusterrobust1(mm,:),2);
        clustermedoidsr1(mm,1) = clusmed;   
    end
    clustermedoidsr1(~checkclussize) = 0;             
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%    
%%%%%%%%%  A MAJORITY of cluster algorithms must demand a change to advance Cluster ID  
%%%%%%%%%    
%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
if dorobust2==1
    threshmin = ceil(ndims*threshmajority);
    sumdataadl  = sum(dataadl);
    clid = 1;
    clusterrobust2 = zeros(1,ndata);
    cumchange = zeros(ndims,1);
    for ii = 1:ndata
        currentchange = dataadl(:,ii)~=0; 
        cumchange = (cumchange + currentchange)>0;
        if sum(cumchange) < threshmin
            clusterrobust2(ii) = clid;
        else
            clid = clid + 1;
            clusterrobust2(ii) = clid;
            cumchange = zeros(ndims,1);
        end
    end
    mm = 0;
    clusterlast = 0;
    clustertmp = zeros(clid,ndata);
    counterr = 0;
    for kk = 1:ndata
        counterr = counterr+1;
        if clusterrobust2(kk)~=clusterlast
            mm = mm+1;
            counterr = 1;
            clustertmp(mm,counterr) = sortpartkeep(kk);
%            clustertmp(mm,counterr) = kk;
            clusterlast = clusterrobust2(kk);
        else
            clustertmp(mm,counterr) = sortpartkeep(kk);
%            clustertmp(mm,counterr) = kk;
        end
    end
    clustertmp(sum(clustertmp,2)==0,:)=[];
    clustertmpc = sum(clustertmp,1);
    clustertmp(:,clustertmpc==0) = [];
    [clustertmp1,ctmp1a,ctmp1b] = unique(clustertmp,'rows');
    clustertmp2 = clustertmp1(ctmp1b,:);
    clustertmp2log = logical(clustertmp2);
    clustertmp2size  = sum(clustertmp2log,2);
    [ca,cb] = sort(clustertmp2size,'descend');
    %spy(clustertmp2log(cb,:))
    clustertmp22 = clustertmp2(cb,:);

    clussize = min([size(clustertmp22,1) clustershow]);
    clustertmp2 = clustertmp22(1:clussize,:);

    clusterrobust2 = clustertmp2;
    nclustersr2 = size(clusterrobust2,1);
    checkclussize = (sum(clusterrobust2>0,2)>minpathlprep);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%  Find the centers of the dense regions - conngroup are the  connected maxima
    for mm = 1:nclustersr2
        [clusmed] = findmedoid_03(clusterrobust2(mm,:),2);
        clustermedoidsr2(mm,1) = clusmed;   
    end
    clustermedoidsr2(~checkclussize) = 0;             
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%    
%%%%%%%%%  ALL cluster algorithms must demand a change to advance Cluster ID   
%%%%%%%%%    
%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
if dorobust3==1
    threshmin = ndims;
    sumdataadl  = sum(dataadl);
    clid = 1;
    clusterrobust3 = zeros(1,ndata);
    cumchange = zeros(ndims,1);
    for ii = 1:ndata
        currentchange = dataadl(:,ii)~=0; 
        cumchange = (cumchange + currentchange)>0;
        if sum(cumchange) < threshmin
            clusterrobust3(ii) = clid;
        else
            clid = clid + 1;
            clusterrobust3(ii) = clid;
            cumchange = zeros(ndims,1);
        end
    end
    mm = 0;
    clusterlast = 0;
    clustertmp = zeros(clid,ndata);
    counterr = 0;
    for kk = 1:ndata
        counterr = counterr+1;
        if clusterrobust3(kk)~=clusterlast
            mm = mm+1;
            counterr = 1;
            clustertmp(mm,counterr) = sortpartkeep(kk);
%            clustertmp(mm,counterr) = kk;
            clusterlast = clusterrobust3(kk);
        else
            clustertmp(mm,counterr) = sortpartkeep(kk);
%            clustertmp(mm,counterr) = kk;
        end
    end
    clustertmp(sum(clustertmp,2)==0,:)=[];
    clustertmpc = sum(clustertmp,1);
    clustertmp(:,clustertmpc==0) = [];
    [clustertmp1,ctmp1a,ctmp1b] = unique(clustertmp,'rows');
    clustertmp2 = clustertmp1(ctmp1b,:);
    clustertmp2log = logical(clustertmp2);
    clustertmp2size  = sum(clustertmp2log,2);
    [ca,cb] = sort(clustertmp2size,'descend');
    %spy(clustertmp2log(cb,:))
    clustertmp22 = clustertmp2(cb,:);

    clussize = min([size(clustertmp22,1) clustershow]);
    clustertmp2 = clustertmp22(1:clussize,:);

    clusterrobust3 = clustertmp2;
    nclustersr3 = size(clusterrobust3,1);
    checkclussize = (sum(clusterrobust3>0,2)>minpathlprep);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%  Find the centers of the dense regions - conngroup are the  connected maxima
    for mm = 1:nclustersr3
        [clusmed] = findmedoid_03(clusterrobust3(mm,:),2);
        clustermedoidsr3(mm,1) = clusmed;   
    end
    clustermedoidsr3(~checkclussize) = 0;             
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%    
%%%%%%%%%  ALL cluster algorithms must demand a change SIMULTANEOUSLY to advance Cluster ID   
%%%%%%%%%    
%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
if dorobust4==1
    threshmin = ndims;
    sumdataadl  = sum(dataadl);
    clid = 1;
    clusterrobust4 = zeros(1,ndata);
    for ii = 1:ndata
        currentchange = dataadl(:,ii)~=0; 
        if sum(currentchange) < threshmin
            clusterrobust4(ii) = clid;
        else
            clid = clid + 1;
            clusterrobust4(ii) = clid;
        end
    end
    mm = 0;
    clusterlast = 0;
    clustertmp = zeros(clid,ndata);
    counterr = 0;
    for kk = 1:ndata
        counterr = counterr+1;
        if clusterrobust4(kk)~=clusterlast
            mm = mm+1;
            counterr = 1;
            clustertmp(mm,counterr) = sortpartkeep(kk);
%            clustertmp(mm,counterr) = kk;
            clusterlast = clusterrobust4(kk);
        else
            clustertmp(mm,counterr) = sortpartkeep(kk);
%            clustertmp(mm,counterr) = kk;
        end
    end
    clustertmp(sum(clustertmp,2)==0,:)=[];
    clustertmpc = sum(clustertmp,1);
    clustertmp(:,clustertmpc==0) = [];
    [clustertmp1,ctmp1a,ctmp1b] = unique(clustertmp,'rows');
    clustertmp2 = clustertmp1(ctmp1b,:);
    clustertmp2log = logical(clustertmp2);
    clustertmp2size  = sum(clustertmp2log,2);
    [ca,cb] = sort(clustertmp2size,'descend');
    %spy(clustertmp2log(cb,:))
    clustertmp22 = clustertmp2(cb,:);

    clussize = min([size(clustertmp22,1) clustershow]);
    clustertmp2 = clustertmp22(1:clussize,:);

    clusterrobust4 = clustertmp2;
    nclustersr4 = size(clusterrobust4,1);
    checkclussize = (sum(clusterrobust4>0,2)>minpathlprep);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%  Find the centers of the dense regions - conngroup are the  connected maxima
    for mm = 1:nclustersr4
        [clusmed] = findmedoid_03(clusterrobust4(mm,:),2);
        clustermedoidsr4(mm,1) = clusmed;   
    end
    clustermedoidsr4(~checkclussize) = 0;             
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if dorobust1==1
    plotdataname = 'robust1';
    titleinfo1   = sprintf('%s Clustering into %d Clusters',upper(plotdataname),nclustersr1);
    titleinfo2   = '';
    datainfoo{1} = { eval(sprintf('cluster%s',plotdataname)) clustermedoidsr1 };
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 };
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 1 1};
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  PATCHES (CLUSTERS Without clustering - One Big cluster!)
    titlerobust1      = titleinfo1;
    clusterrobust{1,1} = {clusterrobust1};
    clusterrobust{1,2} = {clustermedoidsr1};
    clusterrobust{1,3} = {nclustersr1};
    clusterrobust{1,4} = {titlerobust1};
else
    clusterrobust{1,1} = {0};
    clusterrobust{1,2} = {0};
    clusterrobust{1,3} = {0};
    clusterrobust{1,4} = {0};
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if dorobust2==1
    plotdataname = 'robust2';
    titleinfo1   = sprintf('%s Clustering into %d Clusters',upper(plotdataname),nclustersr2);
    titleinfo2   = '';
    datainfoo{1} = { eval(sprintf('cluster%s',plotdataname)) clustermedoidsr2 };
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 };
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 1 1};
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  PATCHES (CLUSTERS Without clustering - One Big cluster!)
    titlerobust2      = titleinfo1;
    clusterrobust{2,1} = {clusterrobust2};
    clusterrobust{2,2} = {clustermedoidsr2};
    clusterrobust{2,3} = {nclustersr2};
    clusterrobust{2,4} = {titlerobust2};
else
    clusterrobust{2,1} = {0};
    clusterrobust{2,2} = {0};
    clusterrobust{2,3} = {0};
    clusterrobust{2,4} = {0};
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if dorobust3==1
    plotdataname = 'robust3';
    titleinfo1   = sprintf('%s Clustering into %d Clusters',upper(plotdataname),nclustersr3);
    titleinfo2   = '';
    datainfoo{1} = { eval(sprintf('cluster%s',plotdataname)) clustermedoidsr3 };
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 };
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 1 1};
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  PATCHES (CLUSTERS Without clustering - One Big cluster!)
    titlerobust3      = titleinfo1;
    clusterrobust{3,1} = {clusterrobust3};
    clusterrobust{3,2} = {clustermedoidsr3};
    clusterrobust{3,3} = {nclustersr3};
    clusterrobust{3,4} = {titlerobust3};
else
    clusterrobust{3,1} = {0};
    clusterrobust{3,2} = {0};
    clusterrobust{3,3} = {0};
    clusterrobust{3,4} = {0};
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if dorobust4==1
    plotdataname = 'robust4';
    titleinfo1   = sprintf('%s Clustering into %d Clusters',upper(plotdataname),nclustersr4);
    titleinfo2   = '';
    datainfoo{1} = { eval(sprintf('cluster%s',plotdataname)) clustermedoidsr4 };
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 };
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 1 1};
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  PATCHES (CLUSTERS Without clustering - One Big cluster!)
    titlerobust4      = titleinfo1;
    clusterrobust{4,1} = {clusterrobust4};
    clusterrobust{4,2} = {clustermedoidsr4};
    clusterrobust{4,3} = {nclustersr4};
    clusterrobust{4,4} = {titlerobust4};
else
    clusterrobust{4,1} = {0};
    clusterrobust{4,2} = {0};
    clusterrobust{4,3} = {0};
    clusterrobust{4,4} = {0};
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    robustreturn     = {clusterrobust};
%%%%
%%%%   Save all of the clusters - Clusters now saved in the "Short" file
%%%%
%     varinfoo = {'clustermaxpathl' savemaxpathl 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
%     varinfoo = {'clustermedoidsp' savemaxpathl 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
%%%%
%%%%  Compute memory and timing variables for performance
%%%%
    tendrobust = now;
    durationnrobust = tendrobust-tstartrobust;
    display(sprintf('Ending ROBUST Analysis at %s',datestr(datetime('now'))))
    tstartrobustt = datetime(datevec(tstartrobust));
    tendrobustd   = datetime(datevec(tendrobust));
    timerobust = rem(durationnrobust,1)*86400;
    display(sprintf('ROBUST Analysis Duration: %s',datestr(timerobust/86400, 'HH:MM:SS')));

    workspacee = whos;
    memusedrobust = sum([workspacee.bytes]);
%%%%
%%%%   Save all of the variables
%%%%
    varnamess = {varnamesshort{:} varnameslong{:} varnamestime{:}}; 
    for ii = 1:size(varnamess,2); if size(varnamess{ii},2)>0; eval(sprintf('global %s',varnamess{ii})); end; end;
    saverightend01;
    profile off
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
else
    display('ROBUST files already exists and OVERWRITE ROBUST set to ZERO.  ROBUST analysis NOT DONE.')
    robustreturn = {1};
end
close all
return 


















