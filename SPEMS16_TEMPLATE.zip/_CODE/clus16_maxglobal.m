function [ maxglobalreturn ] = clus16_maxglobal(varargin)
close all force
profile off
warning off
% clearvars -except fileroot do* prepindex numprepfiles prepfiles prodrunnum prepindexstart prepindexend tstartfull tstartsingle
global fileroot shapestr prodrunnum prepindex fileprefix dataname 
global sigfigs smallpartnums3 partsize  
global dataptsminmax dataptspartkeep dataindexminmax dataindexpartkeep datapartkeepindex dataminmaxpartindex binadd2 datamin datamax datadelta 
global varnamesshort varnameslong varnamestime
varnamesshort = {'bignum','sigfigs','minpop','minpathl','minpopglobalpathl','threshdist','nvars','databins','datadelta','datamax','datamin','shapestr','partsize','partkeep','partkeepind','memusedmaxglobal','clustermaxglobal','clustermedoidsg','nclustersg'};
varnameslong  = {''};
varnamestime  = {'timemaxglobal','tstartmaxglobalt','tendmaxglobald'};
dataname      = 'maxglobal';
global deltar wgtmat

load(sprintf('%s/_DATA/prod/prod_prep_%04d_%04d.mat',fileroot,prodrunnum,prepindex));
display(sprintf('%04d - %s - Global Weighted Clustering',prodrunnum,fileprefix))


checkfilemaxglobal0 = ls(sprintf('%s/_DATA/%s/prod_%04d_%s_%s_*.mat',fileroot,shapestr,prodrunnum,dataname,fileprefix));
checkfilemaxglobal  = logical(size(checkfilemaxglobal0,2));
if checkfilemaxglobal
   display('MAXGLOBAL clustering already done.');
end
checkgomaxglobal =  ~(checkfilemaxglobal&(~checkoverwritemaxglobal));
checkremaxglobal =   (checkfilemaxglobal&(checkreclustermaxglobal));
if checkgomaxglobal             % GO!!!!!!!
    display(sprintf('MAXGLOBAL files:  %1d OVERWRITE MAXGLOBAL:  %1d   MAXGLOBAL analysis will be DONE.',checkfilemaxglobal,checkoverwritemaxglobal));
       
    tstartmaxglobal = now;
    %profile on
    loadname = 'init'; 
    varinfoo = {loadname,'''-regexp'',''^(?!deltaxl1|dircos|pathcount|pathltrue|pathl1true|pathl1corr)\w'''};
    loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end
    wgtmat = partkeepwgts*partkeepwgts';

    if plotall2==1
        plotmaxglobal = 1;
    end
    clustershow   = 1e6;
    coloradjustt = 2.1;
    markersizee = 24;

    euclideannum = ceil(sqrt(nvars)/euclgridsize);

    maxr = max(max(deltar));
    indexxs(:,1) = 1:partsize;
    for iii = 1:partsize
        clear ccc ddd ddd0 eee eeee fff ggg
        ccc = [deltar(iii,:)/euclideannum; partkeepwgts'; indexxs']';  % normalized Euclidean Distance;  partition pop;  partition index
        ccc(ccc(:,1)==0,:) = [];
        ccc = vertcat([0 partkeepwgts(iii) iii],ccc); % cleanup the "bins" in Delta-r
    %    ccc = floor(ccc);
        ccc = ceil(ccc);
        eee0 = sortrows(ccc,[1 2]); % sort according to distance, then pop
    %    eee0 = unique(ccc,'rows');
        eeee = diff(eee0(:,1));     % Find the change-over points between annuli
        eeee = [eeee; 1 ];
        fff = [eee0, eeee];
    %    ggg = fff(fff(:,4)==1,:);
        ggg = fff(fff(:,4)>0,:);    %  Only keep the maximal pop per annuli
        neighborx = ggg(:,1)*euclideannum;
        popy = ggg(:,2);
        indexm = ggg(:,3);
        popmaxr = popy(1);
        indexmaxr = indexm(1);
        checkmax = 0;
        jjj = 1;
        while checkmax==0
            if popy(jjj)>minpopglobalpathl
                if popy(jjj)>popmaxr
                    popmaxr = popy(jjj);
                    indexmaxr = indexm(jjj);
                end
            end
                if popy(jjj)<popmaxr*threshpeak
                    if popy(jjj)>0
                        checkmax = 1;
                    end
                end
            jjj = jjj+1;
            if jjj>size(popy,1)
                checkmax = 1;
            end
        end      
        maxx0(iii,:) = [popmaxr, indexmaxr];  
    end
    %%%%%%%%%%%% Sort by the weights so that the greater peaks come first in
    %%%%%%%%%%%% the list
    maxx = sortrows(maxx0,1);
    maxx = unique(maxx,'rows');
    % Inheritance
    maxx00 = maxx0;
    for iii = 1:size(maxx,1)
        maxxindout  = find(maxx00(:,2)==maxx(iii,2));
        maxxindout2 = find(indexxs==maxx(iii,2));
    %%%%%%%%%%%%%% update the indices to "inherit" the higher peak weight
        maxx0(maxxindout,2) = maxx0(maxxindout2,2);
    end
    clear maxx maxxindout2
    maxx1 = unique(maxx0(:,2),'rows');
    for iii = 1:size(maxx1,1)             
        maxxindout  = find(maxx0(:,2)==maxx1(iii));
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%  This could be changed to the sum of the weights instead of the
    %%%%%%%%  sum of the partitions
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        maxx0(maxxindout,1) = size(maxxindout,1);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        clear maxxindout
    %    maxx0(maxxindout,1) = sum(maxx0(:,2)==maxx1(iii));
    end
    maxx = sortrows(maxx0,1);
    maxx = unique(maxx,'rows');
    maxx = flipud(maxx);
    %maxxr = unique(maxx(:,2));
    maxxr = maxx(:,2);

    losislandsize = 0;

    nclusmaxglobal = max(size(maxxr));
    clustertmp = zeros(nclusmaxglobal,partsize);
    for ii = 1:nclusmaxglobal
        clusterind11(1,:) = indexxs(maxx0(:,2)==maxxr(ii));
        clustertmp(ii,1:size(clusterind11,2)) = clusterind11;
        clear clusterind11
    end
    clustertmp(sum(clustertmp,2)==0,:)=[];
    clustertmpc = sum(clustertmp,1);
    clustertmp(:,clustertmpc==0) = [];
    [clustertmp1,ctmp1a,ctmp1b] = unique(clustertmp,'rows');
    clustertmp2 = clustertmp1(ctmp1b,:);
    clustertmp2log = logical(clustertmp2);
    clustertmp2size  = sum(clustertmp2log,2);
    [ca,cb] = sort(clustertmp2size,'descend');
    %spy(clustertmp2log(cb,:))
    clustertmp22 = clustertmp2(cb,:);

    clussize = min([size(clustertmp22,1) clustershow]);
    clustertmp2 = clustertmp22(1:clussize,:);
    clustermaxglobal = clustertmp2;
    checkclussize = (sum(clustermaxglobal>0,2)>minpathlprep);
    
    nclustersg = size(clustermaxglobal,1);
%%%%%%%  Find the centers of the dense regions
    for mm = 1:nclustersg
        [clusmed] = findmedoid_03(clustermaxglobal(mm,:),1);
        clustermedoidsg(mm,1) = clusmed;
    end
    clustermedoidsg(~checkclussize) = 0;        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'maxglobal';
    titleinfo1   = sprintf('%s Clustering into %d Clusters',upper(plotdataname),nclustersg);
    titleinfo2   = '';
    datainfoo{1} = { eval(sprintf('cluster%s',plotdataname)) clustermedoidsg };
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 };
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 1 plotmedoidsc};
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  PATCHES (CLUSTERS Without clustering - One Big cluster!)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    titlemaxglobal     = titleinfo1;
    clustermaxglob{1} = {clustermaxglobal};
    clustermaxglob{2} = {clustermedoidsg};
    clustermaxglob{3} = {nclustersg};
    clustermaxglob{4} = {titlemaxglobal};
    maxglobalreturn   = {clustermaxglob};
%%%%
%%%%   Save all of the clusters - Clusters now saved in the "Short" file
%%%%
%     varinfoo = {'clustermaxglobal' savespec 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
%     varinfoo = {'clustermedoidsg'  savespec 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
%%%%
%%%%  Compute memory and timing variables for performance
%%%%
    tendmaxglobal = now;
    durationnmaxglobal = tendmaxglobal-tstartmaxglobal;
    display(sprintf('Ending Global Analysis at %s',datestr(datetime('now'))))
    tstartmaxglobalt = datetime(datevec(tstartmaxglobal));
    tendmaxglobald   = datetime(datevec(tendmaxglobal));
    timemaxglobal = rem(durationnmaxglobal,1)*86400;
    display(sprintf('Global Analysis Duration: %s',datestr(timemaxglobal/86400, 'HH:MM:SS')));

    workspacee = whos;
    memusedmaxglobal = sum([workspacee.bytes]);
%%%%
%%%%   Save all of the variables
%%%%
    varnamess = {varnamesshort{:} varnameslong{:} varnamestime{:}}; 
    for ii = 1:size(varnamess,2); if size(varnamess{ii},2)>0; eval(sprintf('global %s',varnamess{ii})); end; end;
    saverightend01;
    profile off
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
elseif checkremaxglobal
    display('MAXGLOBAL files already exists and RECLUSTER MAXGLOBAL set.  MAXGLOBAL clustering analysis will be DONE.')
   
    loadname = 'init'; 
    varinfoo = {loadname,'''-regexp'',''^(?!deltaxl1|dircos|pathltrue|pathl1true|pathl1corr|dataindexminmax|dataptsminmax)\w'''};
    loadright1 = loadright03(varinfoo);for jj=1:size(loadright1,2);varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end;loadright1{jj}=[];end
    wgtmat = partkeepwgts*partkeepwgts';

    dataname = 'maxglobal';
    dataname = sprintf('cluster%s',dataname);
    if ~exist(dataname)|isempty(eval(dataname))
        loadname = plotvars{mod(find(ismember(plotvars,dataname)),size(plotvars,1)),1};
        varinfoo = {loadname,'''short'''}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end;loadright1{jj}=[];end    
        varinfoo = {loadname,'''full'''};  loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end;loadright1{jj}=[];end    
    end    
   
%    clustermaxglobal = clustertmp2;
    nclustersg = size(clustermaxglobal,1);
%%%%%%%  Find the centers of the dense regions
    for mm = 1:nclustersg
        [clusmed] = findmedoid_03(clustermaxglobal(mm,:),1);
        clustermedoidsg(mm,1) = clusmed;
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'maxglobal';
    titleinfo1   = sprintf('%s Clustering into %d Clusters',upper(plotdataname),nclustersg);
    titleinfo2   = '';
    datainfoo{1} = { eval(sprintf('cluster%s',plotdataname)) clustermedoidsg };
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 };
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 1 plotmedoidsc};
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  CLUSTERS 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    titlemaxglobal    = titleinfo1;
    clustermaxglob{1} = {clustermaxglobal};
    clustermaxglob{2} = {clustermedoidsg};
    clustermaxglob{3} = {nclustersg};
    clustermaxglob{4} = {titlemaxglobal};
    maxglobalreturn   = {clustermaxglob};
%%%%
%%%%   Save all of the variables
%%%%
    varnamess = {varnamesshort{:}}; 
    for ii = 1:size(varnamess,2); if size(varnamess{ii},2)>0; eval(sprintf('global %s',varnamess{ii})); end; end;
    saverightend01;
    profile off
else
    display('MAXGLOBAL files already exists and OVERWRITE MAXGLOBAL set to ZERO.  MAXGLOBAL analysis NOT DONE.')
    maxglobalreturn = {1};
end
close all
return 







