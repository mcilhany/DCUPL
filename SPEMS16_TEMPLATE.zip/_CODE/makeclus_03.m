clear all
%shapestr = {'L' 'C' 'O' 'S' 'Z' 'concentric' 'data2d1' 'data2d2' 'data3d1' 'data3d2' 'clipart_01' 'clipart_02' 'clipart_03' 'clipart_04' 'clipart_05' 'clipart_06' 'clipart_09' 'clipart_11' 'clipart_12' 'plus1' 'plus2' 'plus3' 'concentric2'}
shapestr = {'L' 'C' 'O' 'S' 'Z' 'concentric' 'data2d1' 'data2d2' 'data3d1' 'data3d2' 'plus1' 'plus2' 'plus3' 'concentric2'}
shapestr = {'data2d1' 'data2d2' 'data3d1' 'data3d2'}
xbins(1) = 1200;
xbins(2) = xbins(1);


% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     plotdataname = 'dataptsminmax';
%     figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
%     titleinfo1   = sprintf('For %d of Raw Data - Number of Partitions = %d',sizedataraw,npartitionsr);
%     titleinfo2   = sprintf('');
%     datainfoo{1} = { eval(plotdataname) };
%     fileinfoo{1} = { figinfo titleinfo1 titleinfo2 };
%     flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) plotnow 1 0 1 };
%     plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  SCATTER
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 




nshapes = max(size(shapestr));
for ii = 1:nshapes 
    fshapestr = char(shapestr(ii))
    
    if strcmp(shapestr(ii),'data2d1')
        npts1 = 20000;
        npts2 = 0.5*npts1;
        npts3 = 0.3*npts1;
        npts4 = 0.1*npts1;
        rot1 =   0*pi/180;
        rot2 = -60*pi/180;
        rot3 =  80*pi/180;
        rot4 =   0*pi/180;
        ratio1 = (2/1)^2;
        ratio2 = (2/1)^2;
        ratio3 = (2/1)^2;
        ratio4 = (1/1)^2;
        x1 = -20;
        y1 = +32;
        s1 = 8;
        x2 = -5;
        y2 = -5;
        s2 = 6;
        x3 = 30;
        y3 = 18;
        s3 = 6;
        x4 = +0;
        y4 = +0;
        s4 = 30;
        zz1 = randn(npts1,2)*s1;
        zz2 = randn(npts2,2)*s2;
        zz3 = randn(npts3,2)*s3;
        zz4 = randn(npts4,2)*s4;
        rott1 = [ cos(rot1)  sin(rot1);   -sin(rot1)   cos(rot1)];
        rott2 = [ cos(rot2)  sin(rot2);   -sin(rot2)   cos(rot2)];
        rott3 = [ cos(rot3)  sin(rot3);   -sin(rot3)   cos(rot3)];
        rott4 = [ cos(rot4)  sin(rot4);   -sin(rot4)   cos(rot4)];
        scalee1 = [ 1 0; 0 1/ratio1];
        scalee2 = [ 1 0; 0 1/ratio2];
        scalee3 = [ 1 0; 0 1/ratio3];
        scalee4 = [ 1 0; 0 1/ratio4];
        hey1  = scalee1*zz1';
        hey11 = rott1*hey1;
        hey2  = scalee2*zz2';
        hey22 = rott2*hey2;
        hey3  = scalee3*zz3';
        hey33 = rott3*hey3;
        hey4  = scalee4*zz4';
        hey44 = rott4*hey4;
        zz1 = hey11';
        zz2 = hey22';
        zz3 = hey33';
        zz4 = hey44';

        zz1(:,1) = zz1(:,1)+x1;
        zz1(:,2) = zz1(:,2)+y1;
        zz2(:,1) = zz2(:,1)+x2;
        zz2(:,2) = zz2(:,2)+y2;
        zz3(:,1) = zz3(:,1)+x3;
        zz3(:,2) = zz3(:,2)+y3;
        zz4(:,1) = zz4(:,1)+x4;
        zz4(:,2) = zz4(:,2)+y4;

        [abover,abovec] = find(zz1>+50.5);
        [belowr,belowc] = find(zz1<-50.5);
        outtahere = unique(sort([abover;belowr]));
        zz1(outtahere,:) = [];
        [abover,abovec] = find(zz2>+50.5);
        [belowr,belowc] = find(zz2<-50.5);
        outtahere = unique(sort([abover;belowr]));
        zz2(outtahere,:) = [];
        [abover,abovec] = find(zz3>+50.5);
        [belowr,belowc] = find(zz3<-50.5);
        outtahere = unique(sort([abover;belowr]));
        zz3(outtahere,:) = [];
        [abover,abovec] = find(zz4>+50.5);
        [belowr,belowc] = find(zz4<-50.5);
        outtahere = unique(sort([abover;belowr]));
        zz4(outtahere,:) = [];

        zztot = [];
        zztot = [zztot; zz1(:,1)];
        zztot = [zztot; zz2(:,1)];
        zztot = [zztot; zz3(:,1)];
        zztot = [zztot; zz4(:,1)];
        zztot = [zztot; zz1(:,2)];
        zztot = [zztot; zz2(:,2)];
        zztot = [zztot; zz3(:,2)];
        zztot = [zztot; zz4(:,2)];
        zztotal = [zztot(1:max(size(zztot))/2) zztot(max(size(zztot))/2+1:max(size(zztot)))]; 
        aa11 = zztotal;    
        save(sprintf('../_DATA/%s/%s.mat',fshapestr,fshapestr),'aa11')

%        clf
%        hold on
%         plot(zz1(:,1),zz1(:,2),'.');
%         plot(zz2(:,1),zz2(:,2),'r.');
%         plot(zz3(:,1),zz3(:,2),'c.');
%         plot(zz4(:,1),zz4(:,2),'m.');
% %        title(sprintf('%s',fshapestr),'FontSize',18)
%             axis tight
%             xlim([-50 50]);
%             ylim([-50 50]);
%         saveas(gcf,sprintf('../_DATA/%s/%s.jpg',fshapestr,fshapestr)) 
        figinfo = sprintf('../_DATA/%s/%s.jpg',fshapestr,fshapestr);
        clf('reset');set(gcf, 'Position', [1 1 1600 1000]); hold on;
        plot(zz1(:,1),zz1(:,2), '.','MarkerSize',12)
        plot(zz2(:,1),zz2(:,2),'r.','MarkerSize',12)
        plot(zz3(:,1),zz3(:,2),'c.','MarkerSize',12)
        plot(zz4(:,1),zz4(:,2),'m.','MarkerSize',12)
%         plot3(datainfoo{1}(:,1),datainfoo{1}(:,2),datainfoo{1}(:,3),'.','MarkerSize',12)
%         plot3(datainfoo{1}(:,1),datainfoo{1}(:,2),datainfoo{1}(:,3),'.','MarkerSize',12)
%         plot3(datainfoo{1}(:,1),datainfoo{1}(:,2),datainfoo{1}(:,3),'.','MarkerSize',12)
%        xlabel(xlabel1); ylabel(xlabel2); zlabel(xlabel3);;
        xlabel('X1'); ylabel('X2');
        eval(sprintf('axis equal tight xy'));
        axx = gca;
        axx.FontSize = 16;
%        view(viewaz,viewel);
        export_fig(figinfo,'-m3');    
    
    
%        load('../_DATA/testdata2d1.mat')
    elseif strcmp(shapestr(ii),'data2d2')
        npts1 = 20000;
        npts2 = 0.5*npts1;
        npts3 = 0.3*npts1;
        npts4 = 0.1*npts1;
        rot1 =   0*pi/180;
        rot2 = -60*pi/180;
        rot3 =  80*pi/180;
        rot4 =   0*pi/180;
        ratio1 = (2/1)^2;
        ratio2 = (2/1)^2;
        ratio3 = (2/1)^2;
        ratio4 = (1/1)^2;
        x1 = -20;
        y1 = +32;
        s1 = 8;
        x2 = -5;
        y2 = -5;
        s2 = 6;
        x3 = 0;
        y3 = 18;
        s3 = 6;
        x4 = +0;
        y4 = +0;
        s4 = 30;
        zz1 = randn(npts1,2)*s1;
        zz2 = randn(npts2,2)*s2;
        zz3 = randn(npts3,2)*s3;
        zz4 = randn(npts4,2)*s4;
        rott1 = [ cos(rot1)  sin(rot1);   -sin(rot1)   cos(rot1)];
        rott2 = [ cos(rot2)  sin(rot2);   -sin(rot2)   cos(rot2)];
        rott3 = [ cos(rot3)  sin(rot3);   -sin(rot3)   cos(rot3)];
        rott4 = [ cos(rot4)  sin(rot4);   -sin(rot4)   cos(rot4)];
        scalee1 = [ 1 0; 0 1/ratio1];
        scalee2 = [ 1 0; 0 1/ratio2];
        scalee3 = [ 1 0; 0 1/ratio3];
        scalee4 = [ 1 0; 0 1/ratio4];
        hey1  = scalee1*zz1';
        hey11 = rott1*hey1;
        hey2  = scalee2*zz2';
        hey22 = rott2*hey2;
        hey3  = scalee3*zz3';
        hey33 = rott3*hey3;
        hey4  = scalee4*zz4';
        hey44 = rott4*hey4;
        zz1 = hey11';
        zz2 = hey22';
        zz3 = hey33';
        zz4 = hey44';

        zz1(:,1) = zz1(:,1)+x1;
        zz1(:,2) = zz1(:,2)+y1;
        zz2(:,1) = zz2(:,1)+x2;
        zz2(:,2) = zz2(:,2)+y2;
        zz3(:,1) = zz3(:,1)+x3;
        zz3(:,2) = zz3(:,2)+y3;
        zz4(:,1) = zz4(:,1)+x4;
        zz4(:,2) = zz4(:,2)+y4;

        [abover,abovec] = find(zz1>+50.5);
        [belowr,belowc] = find(zz1<-50.5);
        outtahere = unique(sort([abover;belowr]));
        zz1(outtahere,:) = [];
        [abover,abovec] = find(zz2>+50.5);
        [belowr,belowc] = find(zz2<-50.5);
        outtahere = unique(sort([abover;belowr]));
        zz2(outtahere,:) = [];
        [abover,abovec] = find(zz3>+50.5);
        [belowr,belowc] = find(zz3<-50.5);
        outtahere = unique(sort([abover;belowr]));
        zz3(outtahere,:) = [];
        [abover,abovec] = find(zz4>+50.5);
        [belowr,belowc] = find(zz4<-50.5);
        outtahere = unique(sort([abover;belowr]));
        zz4(outtahere,:) = [];

        zztot = [];
        zztot = [zztot; zz1(:,1)];
        zztot = [zztot; zz2(:,1)];
        zztot = [zztot; zz3(:,1)];
        zztot = [zztot; zz4(:,1)];
        zztot = [zztot; zz1(:,2)];
        zztot = [zztot; zz2(:,2)];
        zztot = [zztot; zz3(:,2)];
        zztot = [zztot; zz4(:,2)];
        zztotal = [zztot(1:max(size(zztot))/2) zztot(max(size(zztot))/2+1:max(size(zztot)))]; 
        aa11 = zztotal;    
        save(sprintf('../_DATA/%s/%s.mat',fshapestr,fshapestr),'aa11')

%         clf
%         hold on
%         plot(zz1(:,1),zz1(:,2),'.');
%         plot(zz2(:,1),zz2(:,2),'r.');
%         plot(zz3(:,1),zz3(:,2),'c.');
%         plot(zz4(:,1),zz4(:,2),'m.');
%         title(sprintf('%s',fshapestr),'FontSize',18)
%             axis tight
%             xlim([-50 50]);
%             ylim([-50 50]);
%        saveas(gcf,sprintf('../_DATA/%s/%s.jpg',fshapestr,fshapestr))  
        figinfo = sprintf('../_DATA/%s/%s.jpg',fshapestr,fshapestr);
        clf('reset');set(gcf, 'Position', [1 1 1600 1000]); hold on;
        plot(zz1(:,1),zz1(:,2), '.','MarkerSize',12)
        plot(zz2(:,1),zz2(:,2),'r.','MarkerSize',12)
        plot(zz3(:,1),zz3(:,2),'c.','MarkerSize',12)
        plot(zz4(:,1),zz4(:,2),'m.','MarkerSize',12)
%         plot3(datainfoo{1}(:,1),datainfoo{1}(:,2),datainfoo{1}(:,3),'.','MarkerSize',12)
%         plot3(datainfoo{1}(:,1),datainfoo{1}(:,2),datainfoo{1}(:,3),'.','MarkerSize',12)
%         plot3(datainfoo{1}(:,1),datainfoo{1}(:,2),datainfoo{1}(:,3),'.','MarkerSize',12)
%        xlabel(xlabel1); ylabel(xlabel2); zlabel(xlabel3);;
        xlabel('X1'); ylabel('X2');
        eval(sprintf('axis equal tight xy'));
        axx = gca;
        axx.FontSize = 16;
%        view(viewaz,viewel);
        export_fig(figinfo,'-m3');




    elseif strcmp(shapestr(ii),'data3d1')
        clear xx1 yy1 zz1 xxx1 yyy1 zzz1 dist1 dist1x dist1y dist1z rrr1 dist1
        clear xx2 yy2 zz2 xxx2 yyy2 zzz2 dist2 dist2x dist2y dist2z rrr2 dist2
        clear xx3 yy3 zz3 xxx3 yyy3 zzz3 dist3 dist3x dist3y dist3z rrr3 dist3
        clear xx4 yy4 zz4 xxx4 yyy4 zzz4 dist4 dist4x dist4y dist4z rrr4 dist4
        npts1 = 5000;
        npts2 = 5000;
        npts3 = 9000;
        npts4 = 4000;

        scaleall = 1.0;
        tx1 = 0;
        ty1 = -35;
        tz1 = -10;
        sx1 = 25;
        sy1 = 3;
        sz1 = 15;
        theta1 = 0*pi/180;
        phi1 = 0*pi/180;
        tx2 = 0;
        ty2 = 15;
        tz2 = -10;
        sx2 = 15;
        sy2 = 3;
        sz2 = 15;
        theta2 = 0*pi/180;
        phi2 = -55*pi/180;
        tx3 = +15;
        ty3 = +15;
        tz3 = 40;
        sx3 = 15;
        sy3 = 3;
        sz3 = 15;
        theta3 = 0*pi/180;
        phi3 = 80*pi/180;
        tx4 = +0;
        ty4 = +0;
        tz4 = +0;
        sx4 = 35;
        sy4 = 35;
        sz4 = 35;
        theta4 = 0*pi/180;
        phi4 = 0*pi/180;

        xx1 = randn(npts1,1)*sx1*scaleall;
        yy1 = randn(npts1,1)*sy1*scaleall;
        zz1 = randn(npts1,1)*sz1*scaleall;        
        rot1 = [ cos(theta1) -sin(theta1)*cos(phi1) sin(theta1)*sin(phi1);  sin(theta1) cos(theta1)*cos(phi1) -cos(theta1)*sin(phi1);  0 sin(phi1) cos(phi1) ];
        rrr1 = rot1*[xx1'; yy1'; zz1'];
        dist1x = rrr1(1,:) + tx1;
        dist1y = rrr1(2,:) + ty1;
        dist1z = rrr1(3,:) + tz1;
        dist1(:,1) = dist1x';
        dist1(:,2) = dist1y';
        dist1(:,3) = dist1z';

        xx2 = randn(npts2,1)*sx2*scaleall;
        yy2 = randn(npts2,1)*sy2*scaleall;
        zz2 = randn(npts2,1)*sz2*scaleall;        
        rot2 = [ cos(theta2) -sin(theta2)*cos(phi2) sin(theta2)*sin(phi2);  sin(theta2) cos(theta2)*cos(phi2) -cos(theta2)*sin(phi2);  0 sin(phi2) cos(phi2) ];
        rrr2 = rot2*[xx2'; yy2'; zz2'];
        dist2x = rrr2(1,:) + tx2;
        dist2y = rrr2(2,:) + ty2;
        dist2z = rrr2(3,:) + tz2;
        dist2(:,1) = dist2x';
        dist2(:,2) = dist2y';
        dist2(:,3) = dist2z';

        xx3 = randn(npts3,1)*sx3*scaleall;
        yy3 = randn(npts3,1)*sy3*scaleall;
        zz3 = randn(npts3,1)*sz3*scaleall;        
        rot3 = [ cos(theta3) -sin(theta3)*cos(phi3) sin(theta3)*sin(phi3);  sin(theta3) cos(theta3)*cos(phi3) -cos(theta3)*sin(phi3);  0 sin(phi3) cos(phi3) ];
        rrr3 = rot3*[xx3'; yy3'; zz3'];
        dist3x = rrr3(1,:) + tx3;
        dist3y = rrr3(2,:) + ty3;
        dist3z = rrr3(3,:) + tz3;
        dist3(:,1) = dist3x';
        dist3(:,2) = dist3y';
        dist3(:,3) = dist3z';

        xx4 = randn(npts4,1)*sx4*scaleall;
        yy4 = randn(npts4,1)*sy4*scaleall;
        zz4 = randn(npts4,1)*sz4*scaleall;        
        rot4 = [ cos(theta4) -sin(theta4)*cos(phi4) sin(theta4)*sin(phi4);  sin(theta4) cos(theta4)*cos(phi4) -cos(theta4)*sin(phi4);  0 sin(phi4) cos(phi4) ];
        rrr4 = rot4*[xx4'; yy4'; zz4'];
        dist4x = rrr4(1,:) + tx4;
        dist4y = rrr4(2,:) + ty4;
        dist4z = rrr4(3,:) + tz4;
        dist4(:,1) = dist4x';
        dist4(:,2) = dist4y';
        dist4(:,3) = dist4z';

        [abover,abovec] = find(dist1>+50.5);
        [belowr,belowc] = find(dist1<-50.5);
        outtahere = unique(sort([abover;belowr]));
        dist1(outtahere,:) = [];
        [abover,abovec] = find(dist2>+50.5);
        [belowr,belowc] = find(dist2<-50.5);
        outtahere = unique(sort([abover;belowr]));
        dist2(outtahere,:) = [];
        [abover,abovec] = find(dist3>+50.5);
        [belowr,belowc] = find(dist3<-50.5);
        outtahere = unique(sort([abover;belowr]));
        dist3(outtahere,:) = [];
        [abover,abovec] = find(dist4>+50.5);
        [belowr,belowc] = find(dist4<-50.5);
        outtahere = unique(sort([abover;belowr]));
        dist4(outtahere,:) = [];

        disttot = [];
        disttot = [disttot; dist1(:,1)];
        disttot = [disttot; dist2(:,1)];
        disttot = [disttot; dist3(:,1)];
        disttot = [disttot; dist4(:,1)];
        disttot = [disttot; dist1(:,2)];
        disttot = [disttot; dist2(:,2)];
        disttot = [disttot; dist3(:,2)];
        disttot = [disttot; dist4(:,2)];
        disttot = [disttot; dist1(:,3)];
        disttot = [disttot; dist2(:,3)];
        disttot = [disttot; dist3(:,3)];
        disttot = [disttot; dist4(:,3)];
        disttotal = [disttot(1:max(size(disttot))/3) disttot(max(size(disttot))/3+1:max(size(disttot))*2/3)  disttot(max(size(disttot))*2/3+1:max(size(disttot))) ]; 
        aa11 = disttotal;    
        save(sprintf('../_DATA/%s/%s.mat',fshapestr,fshapestr),'aa11')

%         clf
%         hold on
%         plot3(dist1(:,1),dist1(:,2),dist1(:,3),'g.');
%         plot3(dist2(:,1),dist2(:,2),dist2(:,3),'r.');
%         plot3(dist3(:,1),dist3(:,2),dist3(:,3),'c.');
%         plot3(dist4(:,1),dist4(:,2),dist4(:,3),'m.');
% 
%         xlabel('X1','Fontsize',18)
%         ylabel('X2','Fontsize',18)
%         zlabel('X3','Fontsize',18)
%         title(sprintf('%s',fshapestr),'FontSize',18)
%             axis equal tight
%             xlim([-50 50]);
%             ylim([-50 50]);
%             zlim([-50 50]);
%             view(16,8)
%             set(get(gca,'zlabel'),'rotation',0)
%             set(get(gca,'xlabel'),'position',[-45,-55,-52])
%             set(get(gca,'ylabel'),'position',[54,35,-52])
%             set(get(gca,'zlabel'),'position',[-53,-58,45])
%             set(gcf,'Visible','on','PaperPositionMode', 'manual','Units','inches','PaperPosition',[0,0,8.2,8.0],'PaperSize',[8.2,8.0])
%             set(gca,'Position',[0.055 0.06 0.90 0.90])
%             saveas(gcf,'onr_01.jpg')
%             axis equal tight
%             xlim([-50 50]);
%             ylim([-50 50]);
%             zlim([-50 50]);
%             view(85,3)
%             set(get(gca,'zlabel'),'rotation',0)
%             set(get(gca,'xlabel'),'position',[-45,-55,-52])
%             set(get(gca,'ylabel'),'position',[58,35,-52])
%             set(get(gca,'zlabel'),'position',[-53,-58,45])
%             set(gcf,'Visible','on','PaperPositionMode', 'manual','Units','inches','PaperPosition',[0,0,8.2,8.0],'PaperSize',[8.2,8.0])
%             set(gca,'Position',[0.06 0.06 0.91 0.90])
%             saveas(gcf,sprintf('../_DATA/%s/%s.jpg',fshapestr,fshapestr));
%        load('../_DATA/testdata3d1.mat')
        figinfo = sprintf('../_DATA/%s/%s.jpg',fshapestr,fshapestr);
        clf('reset');set(gcf, 'Position', [1 1 1600 1000]); hold on;
%         plot(zz1(:,1),zz1(:,2), '.','MarkerSize',12)
%         plot(zz2(:,1),zz2(:,2),'r.','MarkerSize',12)
%         plot(zz3(:,1),zz3(:,2),'c.','MarkerSize',12)
%         plot(zz4(:,1),zz4(:,2),'m.','MarkerSize',12)
        plot3(dist1(:,1),dist1(:,2),dist1(:,3),'g.','MarkerSize',12);
        plot3(dist2(:,1),dist2(:,2),dist2(:,3),'r.','MarkerSize',12);
        plot3(dist3(:,1),dist3(:,2),dist3(:,3),'c.','MarkerSize',12);
        plot3(dist4(:,1),dist4(:,2),dist4(:,3),'m.','MarkerSize',12);
        xlabel('X1'); ylabel('X2'); zlabel('X3');
%         set(get(gca,'zlabel'),'rotation',0)
%         set(get(gca,'xlabel'),'position',[-45,-55,-52])
%         set(get(gca,'ylabel'),'position',[58,35,-52])
%         set(get(gca,'zlabel'),'position',[-53,-58,45])
        eval(sprintf('axis equal tight xy'));
        axx = gca;
        axx.FontSize = 16;
        view(-72,20);
        export_fig(figinfo,'-m3');








    elseif strcmp(shapestr(ii),'data3d2')
        clear xx1 yy1 zz1 xxx1 yyy1 zzz1 dist1 dist1x dist1y dist1z rrr1 dist1
        clear xx2 yy2 zz2 xxx2 yyy2 zzz2 dist2 dist2x dist2y dist2z rrr2 dist2
        clear xx3 yy3 zz3 xxx3 yyy3 zzz3 dist3 dist3x dist3y dist3z rrr3 dist3
        clear xx4 yy4 zz4 xxx4 yyy4 zzz4 dist4 dist4x dist4y dist4z rrr4 dist4
        npts1 = 5000;
        npts2 = 5000;
        npts3 = 9000;
        npts4 = 4000;

        scaleall = 1.0;
        tx1 = 0;
        ty1 = -35;
        tz1 = -10;
        sx1 = 25;
        sy1 = 3;
        sz1 = 15;
        theta1 = 0*pi/180;
        phi1 = 0*pi/180;
        tx2 = 0;
        ty2 = 15;
        tz2 = -10;
        sx2 = 15;
        sy2 = 3;
        sz2 = 20;
        theta2 = 0*pi/180;
        phi2 = -45*pi/180;
        tx3 = +15;
        ty3 = +15;
        tz3 = 20;
        sx3 = 15;
        sy3 = 3;
        sz3 = 15;
        theta3 = 0*pi/180;
        phi3 = 80*pi/180;
        tx4 = +0;
        ty4 = +0;
        tz4 = +0;
        sx4 = 35;
        sy4 = 35;
        sz4 = 35;
        theta4 = 0*pi/180;
        phi4 = 0*pi/180;

        xx1 = randn(npts1,1)*sx1*scaleall;
        yy1 = randn(npts1,1)*sy1*scaleall;
        zz1 = randn(npts1,1)*sz1*scaleall;        
        rot1 = [ cos(theta1) -sin(theta1)*cos(phi1) sin(theta1)*sin(phi1);  sin(theta1) cos(theta1)*cos(phi1) -cos(theta1)*sin(phi1);  0 sin(phi1) cos(phi1) ];
        rrr1 = rot1*[xx1'; yy1'; zz1'];
        dist1x = rrr1(1,:) + tx1;
        dist1y = rrr1(2,:) + ty1;
        dist1z = rrr1(3,:) + tz1;
        dist1(:,1) = dist1x';
        dist1(:,2) = dist1y';
        dist1(:,3) = dist1z';

        xx2 = randn(npts2,1)*sx2*scaleall;
        yy2 = randn(npts2,1)*sy2*scaleall;
        zz2 = randn(npts2,1)*sz2*scaleall;        
        rot2 = [ cos(theta2) -sin(theta2)*cos(phi2) sin(theta2)*sin(phi2);  sin(theta2) cos(theta2)*cos(phi2) -cos(theta2)*sin(phi2);  0 sin(phi2) cos(phi2) ];
        rrr2 = rot2*[xx2'; yy2'; zz2'];
        dist2x = rrr2(1,:) + tx2;
        dist2y = rrr2(2,:) + ty2;
        dist2z = rrr2(3,:) + tz2;
        dist2(:,1) = dist2x';
        dist2(:,2) = dist2y';
        dist2(:,3) = dist2z';

        xx3 = randn(npts3,1)*sx3*scaleall;
        yy3 = randn(npts3,1)*sy3*scaleall;
        zz3 = randn(npts3,1)*sz3*scaleall;        
        rot3 = [ cos(theta3) -sin(theta3)*cos(phi3) sin(theta3)*sin(phi3);  sin(theta3) cos(theta3)*cos(phi3) -cos(theta3)*sin(phi3);  0 sin(phi3) cos(phi3) ];
        rrr3 = rot3*[xx3'; yy3'; zz3'];
        dist3x = rrr3(1,:) + tx3;
        dist3y = rrr3(2,:) + ty3;
        dist3z = rrr3(3,:) + tz3;
        dist3(:,1) = dist3x';
        dist3(:,2) = dist3y';
        dist3(:,3) = dist3z';

        xx4 = randn(npts4,1)*sx4*scaleall;
        yy4 = randn(npts4,1)*sy4*scaleall;
        zz4 = randn(npts4,1)*sz4*scaleall;        
        rot4 = [ cos(theta4) -sin(theta4)*cos(phi4) sin(theta4)*sin(phi4);  sin(theta4) cos(theta4)*cos(phi4) -cos(theta4)*sin(phi4);  0 sin(phi4) cos(phi4) ];
        rrr4 = rot4*[xx4'; yy4'; zz4'];
        dist4x = rrr4(1,:) + tx4;
        dist4y = rrr4(2,:) + ty4;
        dist4z = rrr4(3,:) + tz4;
        dist4(:,1) = dist4x';
        dist4(:,2) = dist4y';
        dist4(:,3) = dist4z';

        [abover,abovec] = find(dist1>+50.5);
        [belowr,belowc] = find(dist1<-50.5);
        outtahere = unique(sort([abover;belowr]));
        dist1(outtahere,:) = [];
        [abover,abovec] = find(dist2>+50.5);
        [belowr,belowc] = find(dist2<-50.5);
        outtahere = unique(sort([abover;belowr]));
        dist2(outtahere,:) = [];
        [abover,abovec] = find(dist3>+50.5);
        [belowr,belowc] = find(dist3<-50.5);
        outtahere = unique(sort([abover;belowr]));
        dist3(outtahere,:) = [];
        [abover,abovec] = find(dist4>+50.5);
        [belowr,belowc] = find(dist4<-50.5);
        outtahere = unique(sort([abover;belowr]));
        dist4(outtahere,:) = [];

        disttot = [];
        disttot = [disttot; dist1(:,1)];
        disttot = [disttot; dist2(:,1)];
        disttot = [disttot; dist3(:,1)];
        disttot = [disttot; dist4(:,1)];
        disttot = [disttot; dist1(:,2)];
        disttot = [disttot; dist2(:,2)];
        disttot = [disttot; dist3(:,2)];
        disttot = [disttot; dist4(:,2)];
        disttot = [disttot; dist1(:,3)];
        disttot = [disttot; dist2(:,3)];
        disttot = [disttot; dist3(:,3)];
        disttot = [disttot; dist4(:,3)];
        disttotal = [disttot(1:max(size(disttot))/3) disttot(max(size(disttot))/3+1:max(size(disttot))*2/3)  disttot(max(size(disttot))*2/3+1:max(size(disttot))) ]; 
        aa11 = disttotal;    
        save(sprintf('../_DATA/%s/%s.mat',fshapestr,fshapestr),'aa11')

%         clf
%         hold on
%         plot3(dist1(:,1),dist1(:,2),dist1(:,3),'g.');
%         plot3(dist2(:,1),dist2(:,2),dist2(:,3),'r.');
%         plot3(dist3(:,1),dist3(:,2),dist3(:,3),'c.');
%         plot3(dist4(:,1),dist4(:,2),dist4(:,3),'m.');
% 
%         xlabel('X1','Fontsize',18)
%         ylabel('X2','Fontsize',18)
%         zlabel('X3','Fontsize',18)
%         title(sprintf('%s',fshapestr),'FontSize',18)
%             axis equal tight
%             xlim([-50 50]);
%             ylim([-50 50]);
%             zlim([-50 50]);
%             view(16,8)
%             set(get(gca,'zlabel'),'rotation',0)
%             set(get(gca,'xlabel'),'position',[-45,-55,-52])
%             set(get(gca,'ylabel'),'position',[54,35,-52])
%             set(get(gca,'zlabel'),'position',[-53,-58,45])
%             set(gcf,'Visible','on','PaperPositionMode', 'manual','Units','inches','PaperPosition',[0,0,8.2,8.0],'PaperSize',[8.2,8.0])
%             set(gca,'Position',[0.055 0.06 0.90 0.90])
%             saveas(gcf,'onr_01.jpg')
%             axis equal tight
%             xlim([-50 50]);
%             ylim([-50 50]);
%             zlim([-50 50]);
%             view(85,3)
%             set(get(gca,'zlabel'),'rotation',0)
%             set(get(gca,'xlabel'),'position',[-45,-55,-52])
%             set(get(gca,'ylabel'),'position',[58,35,-52])
%             set(get(gca,'zlabel'),'position',[-53,-58,45])
%             set(gcf,'Visible','on','PaperPositionMode', 'manual','Units','inches','PaperPosition',[0,0,8.2,8.0],'PaperSize',[8.2,8.0])
%             set(gca,'Position',[0.06 0.06 0.91 0.90])
%             saveas(gcf,sprintf('../_DATA/%s/%s.jpg',fshapestr,fshapestr));
%        load('../_DATA/testdata3d2.mat')
        figinfo = sprintf('../_DATA/%s/%s.jpg',fshapestr,fshapestr);
        clf('reset');set(gcf, 'Position', [1 1 1600 1000]); hold on;
%         plot(zz1(:,1),zz1(:,2), '.','MarkerSize',12)
%         plot(zz2(:,1),zz2(:,2),'r.','MarkerSize',12)
%         plot(zz3(:,1),zz3(:,2),'c.','MarkerSize',12)
%         plot(zz4(:,1),zz4(:,2),'m.','MarkerSize',12)
        plot3(dist1(:,1),dist1(:,2),dist1(:,3),'g.','MarkerSize',12);
        plot3(dist2(:,1),dist2(:,2),dist2(:,3),'r.','MarkerSize',12);
        plot3(dist3(:,1),dist3(:,2),dist3(:,3),'c.','MarkerSize',12);
        plot3(dist4(:,1),dist4(:,2),dist4(:,3),'m.','MarkerSize',12);
        xlabel('X1'); ylabel('X2'); zlabel('X3');
%         set(get(gca,'zlabel'),'rotation',0)
%         set(get(gca,'xlabel'),'position',[-45,-55,-52])
%         set(get(gca,'ylabel'),'position',[58,35,-52])
%         set(get(gca,'zlabel'),'position',[-53,-58,45])
        eval(sprintf('axis equal tight xy'));
        axx = gca;
        axx.FontSize = 16;
        view(-72,20);
        export_fig(figinfo,'-m3');





    else    % not a data set - coming from a 2D image plane:  L C O S Z concentric12 plus123 clipart112
       if strcmp(shapestr(ii),'L')
           clear shapemat 
           shapemat = ones(xbins(1),xbins(2));
           shapemat(1:1200,1:300) = 0;
           shapemat(1:1200,1:300) = 0;
           shapemat(1:1200,1:300) = 0;
           shapemat(1:300,1:1200) = 0;
           shapemat(1:300,1:1200) = 0;
           shapemat(1:300,1:1200) = 0;
       end
       if strcmp(shapestr(ii),'C')
           clear shapemat 
           shapemat = ones(xbins(1),xbins(2));
           shapemat(1:1200,1:300) = 0;
           shapemat(1:1200,1:300) = 0;
           shapemat(1:1200,1:300) = 0;
           shapemat(1:300,1:1200) = 0;
           shapemat(1:300,1:1200) = 0;
           shapemat(1:300,1:1200) = 0;
           shapemat(901:1200,1:1200) = 0;
           shapemat(901:1200,1:1200) = 0;
           shapemat(901:1200,1:1200) = 0;
       end
       if strcmp(shapestr(ii),'O')
           clear shapemat 
           shapemat = ones(xbins(1),xbins(2));
           shapemat(1:1200,1:300) = 0;
           shapemat(1:1200,1:300) = 0;
           shapemat(1:1200,1:300) = 0;
           shapemat(1:300,1:1200) = 0;
           shapemat(1:300,1:1200) = 0;
           shapemat(1:300,1:1200) = 0;
           shapemat(1:1200,901:1200) = 0;
           shapemat(1:1200,901:1200) = 0;
           shapemat(1:1200,901:1200) = 0;
           shapemat(901:1200,1:1200) = 0;
           shapemat(901:1200,1:1200) = 0;
           shapemat(901:1200,1:1200) = 0;
       end
       if strcmp(shapestr(ii),'S')
           clear shapemat 
           shapemat = zeros(xbins(1),xbins(2));
       end
       if strcmp(shapestr(ii),'Z')
           clear shapemat 
           shapemat = ones(xbins(1)+300,xbins(2));
           shapemat(301:1500,1:300) = 0;
           shapemat(301:1500,1:300) = 0;
           shapemat(301:1500,1:300) = 0;
           shapemat(301:600,1:1200) = 0;
           shapemat(301:600,1:1200) = 0;
           shapemat(301:600,1:1200) = 0;
           shapemat(1:300,901:1200) = 0;
           shapemat(1:300,901:1200) = 0;
           shapemat(1:300,901:1200) = 0;
       end
       if strcmp(shapestr(ii),'plus1')
           clear shapemat 
           shapemat = ones(xbins(1),xbins(2));
           shapemat(1:1200,401:800) = 0;
           shapemat(1:1200,401:800) = 0;
           shapemat(1:1200,401:800) = 0;
           shapemat(401:800,1:1200) = 0;
           shapemat(401:800,1:1200) = 0;
           shapemat(401:800,1:1200) = 0;
       end
       if strcmp(shapestr(ii),'plus2')
           clear shapemat 
           shapemat = ones(xbins(1),xbins(2));
           shapemat(1:1200,501:700) = 0;
           shapemat(1:1200,501:700) = 0;
           shapemat(1:1200,501:700) = 0;
           shapemat(501:700,1:1200) = 0;
           shapemat(501:700,1:1200) = 0;
           shapemat(501:700,1:1200) = 0;
       end
       if strcmp(shapestr(ii),'plus3')
           clear shapemat 
           shapemat = ones(xbins(1),xbins(2));
           shapemat(1:1200,201:400) = 0;
           shapemat(1:1200,201:400) = 0;
           shapemat(1:1200,201:400) = 0;
           shapemat(201:400,1:1200) = 0;
           shapemat(201:400,1:1200) = 0;
           shapemat(201:400,1:1200) = 0;
           shapemat(1:1200,801:1000) = 0;
           shapemat(1:1200,801:1000) = 0;
           shapemat(1:1200,801:1000) = 0;
           shapemat(801:1000,1:1200) = 0;
           shapemat(801:1000,1:1200) = 0;
           shapemat(801:1000,1:1200) = 0;
       end
       if strcmp(shapestr(ii),'concentric')
           clear shapemat 
           shapemat = ones(xbins(1),xbins(2));
           [rr,cc] = meshgrid(1:xbins(1),1:xbins(2));
           checkk1 = sqrt((rr-xbins(1)/2).^2+(cc-xbins(2)/2).^2)<=((xbins(1)/2)+1);
           checkk2 = sqrt((rr-xbins(1)/2).^2+(cc-xbins(2)/2).^2)>=((xbins(1)/2*3/6)-1);
           checkk = logical((checkk1+checkk2)>1);
           shapemat(checkk) = 0;
       end
       if strcmp(shapestr(ii),'concentric2')
           clear shapemat 
           shapemat = ones(xbins(1),xbins(2));
           [rr,cc] = meshgrid(1:xbins(1),1:xbins(2));
           checkk1 = sqrt((rr-xbins(1)/2).^2+(cc-xbins(2)/2).^2)<=((xbins(1)/2*6/6)+1);
           checkk2 = sqrt((rr-xbins(1)/2).^2+(cc-xbins(2)/2).^2)>=((xbins(1)/2*5/6)-1);
           checkk = logical((checkk1+checkk2)>1);
           shapemat(checkk) = 0;
           checkk1 = sqrt((rr-xbins(1)/2).^2+(cc-xbins(2)/2).^2)<=((xbins(1)/2*4/6)+1);
           checkk2 = sqrt((rr-xbins(1)/2).^2+(cc-xbins(2)/2).^2)>=((xbins(1)/2*3/6)-1);
           checkk = logical((checkk1+checkk2)>1);
           shapemat(checkk) = 0;
           checkk1 = sqrt((rr-xbins(1)/2).^2+(cc-xbins(2)/2).^2)<=((xbins(1)/2*1.5/6)+1);
           shapemat(checkk1) = 0;
       end
        shapemat = uint8(shapemat);
        map = colormap(gray(2));
        shapemat = flipud(shapemat);
        imwrite(shapemat,map,sprintf('../_DATA/%s/%s.jpg',fshapestr,fshapestr));
    end
end

clf
basen = 80;
ii=1;
%ii=nshapes;
fshapestr = char(shapestr(ii))
aaa = imread(sprintf('../_DATA/%s/%s.jpg',fshapestr,fshapestr));
aa1 = aaa(:,:,1);
%    aa1 = flipud(aa1);
aa11 = aa1<100; 
xrawmax(1) = size(aa11,2);
xrawmax(2) = size(aa11,1);
xrawmin(1) = 0;
xrawmin(2) = 0;
sizevars = size(aa11);

xbins(1) = basen;
xbins(2) = ceil(xbins(1)*xrawmax(2)/xrawmax(1));
spy(aa11)
[xmesh,ymesh] = meshgrid(1:sizevars(2),1:sizevars(1));
xpts = xmesh(aa11(:));
ypts = ymesh(aa11(:));
xdelta(1) = (xrawmax(1)-xrawmin(1))/xbins(1);
xdelta(2) = (xrawmax(2)-xrawmin(2))/xbins(2);
xedges = 0:xbins(1);
yedges = 0:xbins(2);
xindex = floor((xpts-1)/xdelta(1));
xindex(xindex>(xbins(1)-1)) = xbins(1)-1;
yindex = floor((ypts-1)/xdelta(2));
yindex(yindex>=(xbins(2)-1)) = xbins(2)-1;

heyindex = [xindex,yindex];
nindex = (heyindex(:,2))*(xbins(1)) + (heyindex(:,1));
hedges = -0.5:1:max(nindex)+1;
hh = histogram(nindex,hedges);
wgts =  hh.Values;
hindex = hedges+0.5;
hhedges = -0.5:1:max(hh.Values)+1;
hhh = histogram(wgts,hhedges);
hvals = hhh.Values;
hbinedges = hhh.BinEdges(1:max(size(hhh.Values)))+0.5;
subplot(2,1,1)
plot(hvals.*hbinedges)
histcumsum = cumsum(hvals.*hbinedges)';
subplot(2,1,2)
plot(histcumsum)
if regexp(fshapestr,regexptranslate('wildcard','data*'))
    hmax = histcumsum(end)*distthresh;
    hdistindex = (histcumsum>hmax);
    hcheck = hbinedges(hdistindex);
    hcut = hcheck(1)-1;
    hindexkeep = hindex(wgts>hcut);
    wgtp = wgts(wgts>hcut);
else
    wgtsmax = max(wgts);
    hindexkeep = hindex(wgts>(wgtsmax/4));
    wgtp = wgts(wgts>(wgtsmax/4));
end
npp = max(size(hindexkeep));
for pp = 1:npp
   hpindex(1,pp) = mod(hindexkeep(pp),xbins(1));
   hpindex(2,pp) = floor(hindexkeep(pp)/xbins(1));
end
hpkeepx = hpindex(1,:);
hpkeepy = hpindex(2,:);
[hkeepx,hkeepy] = meshgrid(hpkeepx,hpkeepy);
maxsize = max(size(hindexkeep));

clf
hold on
cmapklm = colormap(jet(maxsize));
nvals = 1:maxsize;  
xvals = mod(hindexkeep,xbins(1));
yvals = floor(hindexkeep/xbins(1));
cval = cmapklm(nvals,:);
for jj = 1:max(size(xvals))
   poss = [(xvals(jj)*xdelta(1)+xrawmin(1)) ((yvals(jj)*xdelta(2))+xrawmin(2)) xdelta(1) xdelta(2)];
   rectangle('Position',poss,'FaceColor',cval(jj,:));
   if maxsize<250
       text(poss(1)+xdelta(1)/2*.8,(poss(2)+xdelta(2)/2*1.05),num2str(jj),'Color',[0.75 0.65 0.65],'FontSize',16);
   end
end
axis([xrawmin(1) xrawmax(1) xrawmin(2) xrawmax(2)])
axis equal
axis tight
set(gca,'Ydir','reverse')
if maxsize<250
    saveas(gcf,sprintf('../_FIGS/%s/labeled_%s.jpg',fshapestr,fshapestr));
end

