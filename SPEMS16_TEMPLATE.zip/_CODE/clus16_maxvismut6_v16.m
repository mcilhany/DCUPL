function [ maxvismutreturn ] = clus16_maxvismut6_v16(varargin)
close all force
profile off
warning off
global fileroot shapestr prodrunnum prepindex fileprefix dataname 
global sigfigs smallpartnums3 partsize  
global dataptsminmax dataptspartkeep dataindexminmax dataindexpartkeep datapartkeepindex dataminmaxpartindex binadd2 datamin datamax datadelta 
global varnamesshort varnameslong varnamestime 

varnamesshort = {'bignum','sigfigs','minpop','minpathl','threshdist','fixedbins','threshoverlap0','threshoverlap2','threshoverlap3','threshtype','peakthresh0','threshmin0','resurgethresh0','stddevnum','nsmooth','losmode','clustermode','shapestr','fileprefix','nvars','databins','datadelta','datamax','datamin','partsize','partkeep','partkeepind','memusedmaxvismut','clustermaxmut','clustermedoidsm','nclustersm','clustermaxvis','clustermedoidsv','nclustersv'};
varnameslong  = {''};
varnamestime  = {'timemaxvismut','tstartmaxvismutt','tendmaxvismutd'};
dataname      = 'maxvismut';
global pathl wgtmat

load(sprintf('%s/_DATA/prod/prod_prep_%04d_%04d.mat',fileroot,prodrunnum,prepindex));
display(sprintf('%04d - %s - LOS GATHERING for Visibility and Pluarity',prodrunnum,fileprefix))

checkfilemaxvismut0 = ls(sprintf('%s/_DATA/%s/prod_%04d_%s_%s_*.mat',fileroot,shapestr,prodrunnum,dataname,fileprefix));
checkfilemaxvismut  = logical(size(checkfilemaxvismut0,2));
if checkfilemaxvismut
   display('LOS GATHERING clustering already done.');
end
checkgomaxvismut =  ~(checkfilemaxvismut&(~checkoverwritemaxvismut));
checkgomaxvismut =   (checkgomaxvismut|checkreclustermaxvismut);
if checkgomaxvismut             % GO!!!!!!!
    display(sprintf('LOS GATHERING files:  %1d OVERWRITE LOSGATHERING:  %1d   GATHERING analysis will be DONE.',checkfilemaxvismut,checkoverwritemaxvismut));

    tstartmaxvismut = now;
    %profile on

    loadname = 'init'; 
    varinfoo = {loadname,'''-regexp'',''^(?!dircos|deltar|pathcount|pathltrue|pathl1true|pathl1corr|deltaxl1|nn1)\w'''};
    loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end
    loadname = 'connpathl'; 
    varinfoo = {loadname,'''-regexp'',''^(?!connmat|pathcheck|pathlcount|pathltrue)\w'''};
    loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end
    loadname = 'LOS'; 
    varinfoo = {loadname,'''-regexp'',''^(?!sdeltax|sdccount|pathl|pathlcount)\w'''};
    loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end
    wgtmat = partkeepwgts*partkeepwgts';
    losmat = single(losmat);
    kk = 0;
    for ii = 1:length(binaddu)
       mapindex  = find(partkeep==binaddu(ii));
       if ~isempty(mapindex)
           if mapindex>0
               kk = kk+1;
               partmap(kk) = mapindex;
           end
       end
       clear mapindex
    end
%    losmat = losmat(partkeepind,partkeepind);
    losmat = losmat(partmap,partmap);
%    losmat = losmat(indexminpathl,indexminpathl);
    losmat0 = losmat;
    losmat0(1:max(size(losmat0))+1:end) = 1;
    
    if plotall2==1
        plotclusters           = 1;
        plotpathweights        = 1;
    end
    bignum2 = bignum/10^3;
    nrows = partsize;
    indexxs = 1:nrows;
    indexxxs = logical(ones(1,nrows));
    pindex = 1:partsize;
    clustershow   = 1e6;
    clusterid = 0;

    flagcollectiveind = 1           % flagcollectiveind=1 - use the full LLL matrix for the histogram, else use individual partitions
% Parameters for Diagnostics
    histcheck         = 0;
    histcheck = 1;
    fixedbins         = 100;
    gotooverlap2      = 0;          % Once the first overlapping clusters have been found, the search can be skipped
% Parameters for finding the breaks    
%    navgpts           = partsize;
%    navgpts           = ceil(sqrt(partsize));
%    navgpts           = ceil(sqrt(partsize)/1.2);
    navgpts           = 5;
% Parameters for the "gathering" phase
    threshoverlap0    =  0.05;      % Difference from the Larger to Smaller overlap percentage
    threshoverlap2    =  0.90;      % the cluster overlap percentage - higher = more clusters - for smaller up to larger clusters
    threshoverlap3    =  0.30;
    threshtype        =  5;          % 1=std, 2=mean, 3=abs(mean-std), 4=max(mean std), 5=min(mean std)         
%  Parameters for the marker seeking routine    
    peakthresh0       = 0.25;
    threshmin0        = 0.01;
    resurgethresh0    = 0.30;
    stddevnum         = 1;
    nsmooth           = 1;    
    plotflag          = 0;
    skipmaxvis        = 0;
    skipmaxmut        = 0;
    clustermaxvismut  = [];
%
% the partition overlap percentage in LLL, keep high to allow for more clusters to form
% higher for more clusters

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%  Place all of the "Islands" into one large group
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    l2 = losmat*losmat;
    lll = l2.*losmat;
    losislands = pindex(max(lll)<minpathlprep);   
    flaglosislands = ~isempty(losislands);
    if flaglosislands
        losmat(losislands,:) = 0;
        losmat(:,losislands) = 0;
    end
%    numrollback = flaglosislands;
    numrollback = 0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    l2 = losmat*losmat;
    lll = l2.*losmat;
    [llla,lllb] = hist(lll(lll(:)>0),10*fixedbins);
    lllc = cumsum(llla);
    llln = 1:(10*fixedbins);
    lllnc = lllc>(lllc(end)*threshmin0);
    llln2 = llln(lllnc);
    llld = lllb(llln2);
    llldmin = min(llld);
    llldmax = max(llld);
    lllbmin = min(lllb);
    lllbins = ceil((llldmax-lllbmin)/(llldmax-llldmin)*fixedbins);  
    lllbins = ceil((llldmax-0)/(llldmax-llldmin)*fixedbins);  
    lllbinwidth = (llldmax-0)/lllbins;
    lllbins = lllbins+2;
    llledges = linspace(0-lllbinwidth,llldmax+lllbinwidth,lllbins);

    if skipmaxvis==0
    if gotooverlap2==0
        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%  Begin Maximum Visibilty Clustering
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        clustermaxvis = zeros(partsize,partsize);
        maxvismut         = 1;          % maxvismut=1 - maximum visibility   
        pindexremaining = logical(ones(size(pindex)));
        partitioncount=1;
        while partitioncount>0
            [maxlllp,maxllli] = max(lll);
            maxlllh           = max(maxlllp);
            maxpindex         = maxllli(maxlllp==maxlllh);
            sizemaxpindex     = length(maxpindex);
            maxpindex         = maxpindex(ceil(sizemaxpindex/2));

            llldiag = diag(lll);
            l4 = zeros(size(lll));
            for kkk = 1:partsize
                l4(kkk,:) = lll(kkk,:)/llldiag(kkk);
            end
            for kkk = maxpindex
                ltest1 = l4(kkk,:);
                ltest2 = sort(ltest1);
                ltest2(ltest2==0) = [];
                ltest2 = [0 ltest2 ltest2(end)];
                ltest3 = diff(ltest2);
                kernel = ones(2*navgpts+1,1)/(2*navgpts);
                lavg = conv(ltest3(2:end), kernel, 'same');
                lavg = [0 lavg];
                    if threshtype==1
                    labovethresh = std(lavg)/1.0;
                elseif threshtype==2
                    labovethresh = mean(lavg)/1.0;
                elseif threshtype==3
                    labovethresh = abs(mean(lavg)-std(lavg));
                elseif threshtype==4
                    labovethresh = max([mean(lavg) std(lavg)]);
                elseif threshtype==5
                    labovethresh = min([mean(lavg) std(lavg)]);
                    end
                if histcheck==1
                    clf
                    subplot(4,1,1)
                    hold on
                    plot(ltest2(2:end),ltest3,'b-')
                    plot(ltest2(2:end),ltest3,'bo')
                    line([0 1],[std(ltest3) std(ltest3)]);
                    subplot(4,1,2)
                    plot(ltest2(2:end),lavg,'r-')
                    line([0 1],[labovethresh labovethresh]);
                    subplot(4,1,3)
                    histbins = linspace(0,1,fixedbins+1);
                    histcnts = histcounts(ltest1,histbins);
                    histcenters = (histbins(1:end-1) + histbins(2:end))/2;
                    bar(histcenters(2:end), histcnts(2:end))
                    axis tight
                    subplot(4,1,4)
                    plot(ltest2,'.','Markersize',6)
                    axis tight
                    drawnow
                end
                lindex = 1:size(lavg,2);
                labove = lindex(lavg>labovethresh);
                if isempty(labove)
                    labove2 = 1;
                else
                    labovediff = diff(labove);
                    labovediff = [1 labovediff ];
                    lindex2 = labove;
                    labove2 = lindex2(labovediff>1);
                    if isempty(labove2)
                        labove2 = lindex2(1);
                    end
                end
            end
            threshoverlap = ltest2(labove2(end));
            threshoverlap1 = threshoverlap + threshoverlap0;
            threshoverlap1 = min([threshoverlap1 0.9999999]);
            threshoverlap1 = max([threshoverlap1 0.00]);
            if histcheck==1
                subplot(4,1,3)
                line([threshoverlap threshoverlap],[-0.1 max(histcnts(2:end)/3)],'Color','r','LineWidth',2);
            end
            l5 = (l4>threshoverlap);
            l6 = l5&(l4'>threshoverlap1);
            flaglll = l6(maxpindex,:)&pindexremaining;
            pindexremaining(flaglll) = 0;        

            goodset   = pindex(flaglll);
            sizegoodset = size(goodset,2);
            clusterid = clusterid+1;
            clustermaxvis(clusterid,1:sizegoodset) = goodset;
            clustervisibility0(clusterid) = maxlllh;
            lll(goodset,:) = 0;
            lll(:,goodset) = 0;        
            partitioncount = sum(logical(sum(lll)));
            display(sprintf('ID: %d   Parts Remain:  %d    labovethr = %6.4f   throverlap = %6.4f  clussize = %d',clusterid,partitioncount,labovethresh,threshoverlap,sizegoodset));
            if histcheck==1
                display('Press a key to continue...');pause
                clf
                subplot(2,2,1);
                spy(losmat0);
                subplot(2,2,2);
                spy(l2);
                subplot(2,2,3);
                spy(l2.*losmat0);
                subplot(2,2,4);
                spy(lll);
                 display('Press a key to continue...');pause
                clf
                subplot(2,1,1);
                hist(l2(l2>0),100);
                subplot(2,1,2);
                l2diag = diag(l2);
                hist(l2diag(l2diag>0),100);
           end
        end
        clustertmp = clustermaxvis;
        clustertmp(sum(clustertmp,2)==0,:)=[];
        clustertmpc = sum(clustertmp,1);
        clustertmp(:,clustertmpc==0) = [];
        [clustertmp1,clos1a,clos1b] = unique(clustertmp,'rows');
        clustertmp2 = clustertmp1(clos1b,:);
        clustertmp2 = clustertmp;

        clustertmp2log = logical(clustertmp2);
        clustertmp2size  = sum(clustertmp2log,2);
        [ca,cb] = sort(clustertmp2size,'descend');
        clustertmp22 = clustertmp2(cb,:);

        clussize = min([size(clustertmp22,1) clustershow]);
        clustertmp23 = clustertmp22(1:clussize,:);
        clustermaxvis0 = clustertmp23;
        clustermaxvis0 = clustertmp2;
        nclustersv = size(clustermaxvis0,1);
    %     if flaglosislands
    %         clusterid = clusterid+1;
    %         clustermaxvis0(clusterid,1:length(losislands)) = losislands;
    %     end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%
%%%%%%%  Find the centers of the dense regions - conngroup are the
%%%%%%%  connected maxima
%%%%%%%
        for clusterid = 1:nclustersv
            [clusmed] = findmedoid_03(clustermaxvis0(clusterid,:),2);
            clustermedoidsv0(clusterid,1) = clusmed;   
        end
        for ii = 1:numrollback
            clustermedoidsv0(end+1-ii,1) = 0;
        end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    else
        loadname = 'maxvismut'; 
        varinfoo = {loadname,''''''};
        loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end
        clustermaxvis0   = clustermaxvis;
        clustermedoidsv0 = clustermedoidsv;
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%    Computer overlap percentages between clusters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
   clustersizes   = sum(clustermaxvis0>0,2); 
   l2 = losmat0*losmat0;
   llllog = logical(l2.*losmat0);
   mmm = nclustersv-numrollback;
   cindex = 1:(nclustersv-numrollback);
   clustermergel1 = clustermaxvis0;
   
   for mm = (nclustersv-numrollback):-1:1
%   for mm = 1:(nclustersv-numrollback)
   
   for mmp = 1:nclustersv-numrollback
        pindtmp = clustermaxvis0(mmp,clustermaxvis0(mmp,:)>0);
        sizecluster = length(pindtmp);
        clusterpartlisttmp = [];
        for kk = 1:sizecluster
            clusterpartlisttmp = [clusterpartlisttmp pindex(llllog(pindtmp(kk),:))];
        end
        clusterpartlisttmp = unique(clusterpartlisttmp);
        sizeclustertmp = length(clusterpartlisttmp);
        if ~isempty(clusterpartlisttmp)
            clusterpartlist(mmp,1:sizeclustertmp) = clusterpartlisttmp;
        end
   end
   clusterpartsizes = sum(clusterpartlist>0,2);
   [clusterpa,clusterpi] = sort(clusterpartsizes,'descend');
   clusterpartlist = clusterpartlist(clusterpi,:);
   clusteroverl1 = zeros(nclustersv-numrollback,partsize);
   for mmp = 1:nclustersv-numrollback
       clusteroverl1(mmp,clusterpartlist(mmp,clusterpartlist(mmp,:)>0)) = 1;
   end
   clusteroverl20 = clusteroverl1*clusteroverl1';
   for mmp = 1:nclustersv-numrollback
       clusteroverl2(mmp,:) = clusteroverl20(mmp,:)/clusteroverl20(mmp,mmp);
   end
   clusteroverl2(1:nclustersv+1:end) = 0; 
   clustersizesmat = repmat(clustersizes,1,nclustersv);
   clusteroverl3   = clustersizesmat./clusteroverl20;
   clusteroverl2(1:nclustersv+1:end) = 0; 
   clusteroverl4 = ones(size(clusteroverl3));
   clusteroverl4 = tril(clusteroverl3); 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%    Regroup the current clusters combining any that have an overlap
%%%    greater than threshoverlap = 90%.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
       mmi = 0;
       cmaxindex = cindex(clusteroverl2(mm,:)>threshoverlap2);
       [cmaxp,cmaxi] = sort(clusteroverl2(mm,clusteroverl2(mm,:)>threshoverlap2),'descend');
       cmaxindex = cmaxindex(cmaxi);
       cmaxindex(cmaxindex>mm) = [];
       if ~isempty(cmaxindex)
           pathlclus = [];
           for ii = cmaxindex
               if clusteroverl4(mm,ii)<threshoverlap3
                   mmi = mmi+1;
                   pathlclus(mmi)  = pathl(clustermedoidsv0(mm),clustermedoidsv0(ii));
                   clusteridd(mmi) = ii;
               end
           end
           if ~isempty(pathlclus)
               [pathclusa,pathclusi] = sort(pathlclus);
               cmaxindex = clusteridd(pathclusi(1));
               display(sprintf('mm = %d',mm));
               clear pathlclus
           else
               cmaxindex = [];
           end
       end
       mergelistlogical = zeros(1,partsize);
       mergelistlogical(clustermaxvis0(mm,clustermaxvis0(mm,:)>0)) = 1;
       mergelistlogical(clustermergel1(mm,clustermergel1(mm,:)>0)) = 1;
       if ~isempty(cmaxindex)
           donemerge = 0;
           for ii = cmaxindex
               if donemerge==0
                   if clusteroverl4(mm,ii)<threshoverlap3
                       mergelistlogical(clustermergel1(ii,clustermergel1(ii,:)>0)) = 1;
                       sizemerge = sum(mergelistlogical,2);
                       clustermergel1(ii,1:sizemerge) = pindex(logical(mergelistlogical));
                       clustermergel1(mm,:) = 0;
                       donemerge = 1;
                   end
               end           
           end
          if donemerge==0
              sizemerge = sum(mergelistlogical,2);
              clustermergel1(mm,1:sizemerge) = pindex(logical(mergelistlogical));             
          end
       else
           sizemerge = sum(mergelistlogical,2);
           clustermergel1(mm,1:sizemerge) = pindex(logical(mergelistlogical));             
       end
       clear cmaxindex mergelistlogical 
   end
   clustermergel1(sum(clustermergel1,2)==0,:) = [];
   clustermergel1(:,sum(clustermergel1,1)==0) = [];
   sizeclustermerge = sum(clustermergel1,2);
   [sizeclusm,indclusm] = sort(sizeclustermerge,'descend');
   clustermerge = clustermergel1(indclusm,:);
   nclustersv = size(clustermerge,1);
   clustermaxvis = clustermaxvis0;
   clustermaxvis = clustermerge;
   nclustersv = size(clustermaxvis,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%
%%%%%%%  Find the centers of the dense regions - conngroup are the
%%%%%%%  connected maxima
%%%%%%%
    for clusterid = 1:nclustersv
        [clusmed] = findmedoid_03(clustermaxvis(clusterid,:),2);
        clustermedoidsv(clusterid,1) = clusmed;   
    end
    for ii = 1:numrollback
        clustermedoidsv(end+1-ii,1) = 0;
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%
%%%%    Plot results from LOS Maximum Visibility Gathering 
%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        plotdataname = 'maxvis';
        extrainfo    = sprintf('');
        extrainfo    = sprintf('__%4.2f__%4.2f__%4.2f__%d__%d',threshoverlap0,threshoverlap2,threshoverlap3,threshtype,navgpts);
        titleinfo1   = sprintf('%s Clustering into %d Clusters%s',upper(plotdataname),nclustersv,extrainfo);
        titleinfo2   = 'LOS Gathering by Maximum Visibility';
        datainfoo{1} = { eval(sprintf('cluster%s',plotdataname)) clustermedoidsv };
        figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname,extrainfo);
        fileinfoo{1} = { figinfo titleinfo1 titleinfo2};
        flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 1 plotmedoidsc};
        plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  PATCHES (CLUSTERS Without clustering - One Big cluster!)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    titlemaxvis           = titleinfo1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%  Intermezzo - reset parameters for the next cluster search
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    else
        clustermaxvis   = 0;
        clustermedoidsv = 0;
        nclustersv      = 0;
        titlemaxvis     = 'a';
    end
    clustermaxvismut{1,1} = {clustermaxvis};
    clustermaxvismut{1,2} = {clustermedoidsv};
    clustermaxvismut{1,3} = {nclustersv};
    clustermaxvismut{1,4} = {titlemaxvis};
    if skipmaxmut==0
    clear clustert*
    l2  = losmat0*losmat0;
    lll = l2.*losmat0;
    maxmutedgeset  = [];
    clusterid = 0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%       Do mutual visibility clustering
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    clustermaxmut = zeros(partsize,partsize);
    maxvismut      = 0;          % maxvismut=0 - maximal mutual visibility
    partitioncount = 1;
    while partitioncount>0
        for kkk = 1:partsize
            pindexnonzero = pindex(lll(kkk,:)>0);
            if ~isempty(pindexnonzero)
                [histt,histbins,mapuniquetowgts] = histcounts(lll(kkk,lll(kkk,:)>0),llledges);
                if sum(histt)>0
                    [histmaxv,histmaxi] = max(histt);
                    maxhistv(kkk)       = max(histt);
                    maxpindexmuti0      = pindex(pindexnonzero(mapuniquetowgts==histmaxi(histmaxv==maxhistv(kkk))));
                    maxpindexmuti(kkk)  = maxpindexmuti0(ceil(end/2));
                    maxpindexv(kkk)     = lll(kkk,maxpindexmuti(kkk));
                else
                    maxhistv(kkk)       = 0;
                    maxpindexmuti(kkk)  = 0;
                    maxpindexv(kkk)     = 0;
                end
            else
                maxhistv(kkk)       = 0;
                maxpindexmuti(kkk)  = 0;
                maxpindexv(kkk)     = 0;
            end
        end
        maxlllvv = max(maxhistv);
        maxlllvi = pindex(maxhistv==maxlllvv);
        maxlllvi = maxlllvi(ceil(end/2));
        [maxlllp,maxllli] = max(lll);
        [sortmaxlpa,sortmaxlpi] = sort(maxlllp,'descend');
        lllvec0 = lll(maxlllvi,:);
        lllvec = lllvec0(lllvec0(:)>0);
        [histt,histbins,mapuniquetowgts]= histcounts(lllvec,llledges);
        maxhistv   = max(histt);
        if maxhistv>0
            maxpindexv = maxllli(histt==maxhistv);

            [losmarkerstart,losmarkerend,histtlosmax] = findmarkers_01(histt,histbins,fixedbins,peakthresh0,threshmin0,resurgethresh0,stddevnum,nsmooth,maxvismut,plotflag);

            [histlosmaxz,histlosmaxi] = max(histtlosmax);
            flaglll = pindex((lll(maxlllvi,:)>histbins(losmarkerstart(histlosmaxi)))&(lll(maxlllvi,:)<=histbins(losmarkerend(histlosmaxi))));
            goodset   = pindex(flaglll);
            sizegoodset = size(goodset,2);
            lll(goodset,:) = 0;
            lll(:,goodset) = 0;       
            partitioncount = sum(logical(sum(lll)))  
            clusterid = clusterid+1
            clustermaxmut(clusterid,1:sizegoodset) = goodset;
        end
    end
    clustertmp = clustermaxmut;
    clustertmp(sum(clustertmp,2)==0,:)=[];
    clustertmpc = sum(clustertmp,1);
    clustertmp(:,clustertmpc==0) = [];
    [clustertmp1,clos1a,clos1b] = unique(clustertmp,'rows');
    clustertmp2 = clustertmp1(clos1b,:);

    clustertmp2log = logical(clustertmp2);
    clustertmp2size  = sum(clustertmp2log,2);
    [ca,cb] = sort(clustertmp2size,'descend');
    clustertmp22 = clustertmp2(cb,:);

    clussize = min([size(clustertmp22,1) clustershow]);
    clustertmp2 = clustertmp22(1:clussize,:);
    clustermaxmut0 = clustertmp2;
        
    flaglosmaxmutedges = ~isempty(maxmutedgeset);
    if flaglosmaxmutedges
        clusterid = clusterid+1;
        clustermaxmut0(clusterid,1:length(maxmutedgeset)) = maxmutedgeset;
    end
    if flaglosislands
        clusterid = clusterid+1;
        clustermaxmut0(clusterid,1:length(losislands)) = losislands;
    end
    clustermaxmut = clustermaxmut0;
    nclustersm    = size(clustermaxmut,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%
%%%%%%%  Find the centers of the dense regions - conngroup are the
%%%%%%%  connected maxima
%%%%%%%
    for clusterid = 1:nclustersm
        [clusmed] = findmedoid_03(clustermaxmut(clusterid,:),2);
        clustermedoidsm(clusterid,1) = clusmed;   
    end    
    for ii = 1:numrollback
        clustermedoidsm(end+1-ii,1) = 0;
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%
%%%%    Plot results from LOS Maximum Mutual Visibility Gathering 
%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        plotdataname = 'maxmut';
        titleinfo1   = sprintf('%s Clustering into %d Clusters',upper(plotdataname),nclustersm);
        titleinfo2   = 'LOS Gathering by Maximum Mutual Visibility';
        datainfoo{1} = { eval(sprintf('cluster%s',plotdataname)) clustermedoidsm };
        figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
        fileinfoo{1} = { figinfo titleinfo1 titleinfo2 };
        flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 1 plotmedoidsc};
        plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  PATCHES (CLUSTERS Without clustering - One Big cluster!)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
    titlemaxmut           = titleinfo1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
    else
        clustermaxmut   = 0;
        clustermedoidsm = 0;
        nclustersm      = 0;
        titlemaxmut     = 'a';
    end
    clustermaxvismut{2,1} = {clustermaxmut};
    clustermaxvismut{2,2} = {clustermedoidsm};
    clustermaxvismut{2,3} = {nclustersm};
    clustermaxvismut{2,4} = {titlemaxmut};

    if isempty(clustermaxvismut); clustermaxvismut = 1; end
    maxvismutreturn = {clustermaxvismut};
%%%%
%%%%   Save all of the clusters - Clusters now saved in the "Short" file
%%%%
%     varinfoo = {'clustermaxvis'   savemaxvismut 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
%     varinfoo = {'clustermedoidsv' savemaxvismut 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
%     varinfoo = {'clustermaxmut'   savemaxvismut 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
%     varinfoo = {'clustermedoidsm' savemaxvismut 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
%%%%
%%%%  Compute memory and timing variables for performance
%%%%
    tendmaxvismut = now;
    durationnmaxvismut = tendmaxvismut-tstartmaxvismut;
    display(sprintf('Ending LOS GATHERING Analysis at %s',datestr(datetime('now'))))
    tstartmaxvismutt = datetime(datevec(tstartmaxvismut));
    tendmaxvismutd   = datetime(datevec(tendmaxvismut));
    timemaxvismut = rem(durationnmaxvismut,1)*86400;
    display(sprintf('LOS GATHERING Analysis Duration: %s',datestr(timemaxvismut/86400, 'HH:MM:SS')));

    workspacee = whos;
    memusedmaxvismut = sum([workspacee.bytes]);
%%%%
%%%%   Save all of the variables
%%%%
    varnamess = {varnamesshort{:} varnameslong{:} varnamestime{:}}; 
    for ii = 1:size(varnamess,2); if size(varnamess{ii},2)>0; eval(sprintf('global %s',varnamess{ii})); end; end;
    saverightend01;
    profile off
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
else
    display('LOS GATHERING files already exists and OVERWRITE LOSGATHER set to ZERO.  LOS GATHERING analysis NOT DONE.')
    maxvismutreturn = {1};
end
close all
return 











% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%% Different regrouping
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
%    cindex = 1:(nclustersv-numrollback);
%    ccindex = 1:size(clusteroverl2,2);
%    clustermergel1 = clustermaxvis0;
% 
%     cindexremaining = logical(ones(size(cindex)));
%     for mmm = (nclustersv-numrollback):-1:1
%         ctest1 = clusteroverl2(mmm,:);
%         ctest2 = sort(ctest1);
%         ctest2(ctest2==0) = [];
%         ctest2 = [0 ctest2 ctest2(end)];
%         ctest3 = diff(ctest2);
%         kernel = ones(2*navgpts2+1,1)/(2*navgpts2);
%         cavg = conv(ctest3, kernel, 'same');
% %        cabovethresh = abs(mean(cavg)-std(cavg));
%         cabovethresh = std(cavg);
%         if histcheck2==1
%             clf
%             subplot(4,1,1)
%             hold on
%             plot(ctest2(2:end),ctest3,'b-')
%             plot(ctest2(2:end),ctest3,'bo')
%             line([0 1],[std(ctest3) std(ctest3)]);
%             subplot(4,1,2) 
%             plot(ctest2(2:end),cavg,'r-')
%             line([0 1],[cabovethresh cabovethresh]);
%             subplot(4,1,3)
%             histbins = linspace(0,1,fixedbins+1);
%             histcnts = histcounts(ctest1,histbins);
%             histcenters = (histbins(1:end-1) + histbins(2:end))/2;
%             bar(histcenters(2:end), histcnts(2:end))
%             axis tight
%             subplot(4,1,4)
%             plot(ltest2,'-','LineWidth',3)
%             axis tight
%             drawnow
%             display(sprintf('m = %d  stdev(cavg) = %f',mmm,cabovethresh));
%             display('Press a key to continue...');pause
%         end
%         cindex = 1:size(cavg,2);
%         cabove = cindex(cavg>cabovethresh);
%         if isempty(cabove)
%             cabove2 = 1;
%         else
%             cabovediff = diff(cabove);
%             cabovediff = [1 cabovediff ];
%             cindex2 = cabove;
%             cabove2 = cindex2(cabovediff>1);
%             if isempty(cabove2)
%                 cabove2 = cindex2(end);
%             end
%         end
%         threshoverlap2 = ctest2(cabove2(end))*0.99999
%         threshoverlap3 = threshoverlap2 + 0.05;
%         threshoverlap3 = min([threshoverlap3 0.999]);
%         c5 = (clusteroverl2>threshoverlap2);
%         c6 = c5&(clusteroverl2'>threshoverlap3);
%         
%         for mm = (nclustersv-numrollback):-1:1
%            cmaxindex = ccindex(clusteroverl2(mm,:)>threshoverlap2);
%            [cmaxp,cmaxi] = sort(clusteroverl2(mm,clusteroverl2(mm,:)>threshoverlap2),'descend');
%            cmaxindex = cmaxindex(cmaxi);
%            mergelistlogical = zeros(1,partsize);
%            mergelistlogical(clustermaxvis0(mm,clustermaxvis0(mm,:)>0)) = 1;
%            mergelistlogical(clustermergel1(mm,clustermergel1(mm,:)>0)) = 1;
%            if ~isempty(cmaxindex)
%                donemerge = 0;
%                for ii = cmaxindex
%                    if donemerge==0
%                        if clusteroverl2(ii,mm)>threshoverlap3
%                            mergelistlogical(clustermergel1(ii,clustermergel1(ii,:)>0)) = 1;
%                            sizemerge = sum(mergelistlogical,2);
%                            clustermergel1(ii,1:sizemerge) = pindex(logical(mergelistlogical));
%                            clustermergel1(mm,:) = 0;
%                            donemerge = 1;
%                        end
%                    end           
%                end
%               if donemerge==0
%                   sizemerge = sum(mergelistlogical,2);
%                   clustermergel1(mm,1:sizemerge) = pindex(logical(mergelistlogical));             
%               end
%            else
%                sizemerge = sum(mergelistlogical,2);
%                clustermergel1(mm,1:sizemerge) = pindex(logical(mergelistlogical));             
%            end
%            clear cmaxindex mergelistlogical 
%         end
%     end
%     clustermergel1(sum(clustermergel1,2)==0,:) = [];
%     clustermergel1(:,sum(clustermergel1,1)==0) = [];
%     sizeclustermerge = sum(clustermergel1,2);
%     [sizeclusm,indclusm] = sort(sizeclustermerge,'descend');
%     clustermerge = clustermergel1(indclusm,:);
%     nclustersv = size(clustermerge,1);







