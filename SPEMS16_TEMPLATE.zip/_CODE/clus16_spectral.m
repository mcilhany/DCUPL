function [ spectralreturn ] = clus16_spectral(varargin)
close all force
profile off
warning off
global fileroot shapestr prodrunnum prepindex fileprefix dataname 
global sigfigs smallpartnums3 partsize  
global dataptsminmax dataptspartkeep dataindexminmax dataindexpartkeep datapartkeepindex dataminmaxpartindex binadd2 datamin datamax datadelta 
global varnamesshort varnameslong varnamestime
varnamesshort = {'bignum','sigfigs','minpop','minpathl','threshdist','nvars','databins','datadelta','datamax','datamin','shapestr','partsize','partkeep','partkeepind','memusedspectral','eigvec1','eigvec2','gathertype','gathertype2','gathertype3','clusspecdata','clusterspectral'};
varnameslong  = {''};
varnamestime  = {'timespectral','tstartspectralt','tendspectrald'};
dataname      = 'spectral';

load(sprintf('%s/_DATA/prod/prod_prep_%04d_%04d.mat',fileroot,prodrunnum,prepindex));
display(sprintf('%04d - %s - %s Clustering',prodrunnum,fileprefix,upper(dataname)))


checkfilespectral0 = ls(sprintf('%s/_DATA/%s/prod_%04d_%s_%s*.mat',fileroot,shapestr,prodrunnum,dataname,fileprefix));
checkfilespectral  = logical(size(checkfilespectral0,2));
if checkfilespectral
   display(sprintf('%s clustering already done.',upper(dataname)));
end
checkgospectral =  ~(checkfilespectral&(~checkoverwritespectral));
checkrespectral =   checkgospectral;
if checkgospectral             % GO!!!!!!!
    display(sprintf('%s files:  %1d OVERWRITE %s:  %1d   %s analysis will be DONE.',upper(dataname),checkfilespectral,upper(dataname),checkoverwritespectral,upper(dataname)));
  
    tstartspectral = now;
    loadname = 'init'; 
    varinfoo = {loadname,'''-regexp'',''^(?!deltaxl1|deltar|dircos|nn1|pathcount|pathltrue|pathl1true|pathl1corr)\w'''};
    loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end

%     loadname = 'connpathl'; 
%     varinfoo = {loadname,['''pathl''']};
%     loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end

    if plotall2==1
        plotspectral = 1;
    end

    threshhist    = 0;
    islandthresh  = 0;
    coloradjustt  = 2.1;
    clustershow   = 1e6;
    sigfigsspec   = 5;
%    partsize = max(size(nn1));
    clusspeckmeansnum   = min([clusspeckmeansnum partsize]);
    clusspeckmedoidsnum = min([clusspeckmedoidsnum partsize]);
    % clusspecgather = 3;
    % clusspecdata = 3;
    % eigvec1 = 1;
    % eigvec2 = 2;
    % clusspechistobins = 16;
    % plotspectral = 1;
%    radialsigma     = 1/1;
%    radialthresh    = 10e-16;
    wgtmat = partkeepwgts*partkeepwgts' - diag(partkeepwgts);

    spectralid = 0;
for clusspecdata = 1:3          % Three spectral Laplacians, based on:  NN1, LOS, RADIAL
for clusspeceig = 1:2:3         % Two eigenvector sets:  [1,2]  and [2,3]
for clusspecgather = 1:3        % Three gathering modes in the eigenspace:  2D histogram, kmeans, kmedoids
% for clusspeceig = 1:1         % Two eigenvector sets:  [1,2]  and [2,3]
% for clusspecgather = 1:1        % Three gathering modes in the eigenspace:  2D histogram, kmeans, kmedoids
    
    spectralid = spectralid + 1;     % Spectral analysis ID:
                                     %  1=[NN1,eig1,2dhis]  2=[NN1,eig1,kmean]  3=[NN1,eig1,kmeds]  4=[NN1,eig3,2dhis]  5=[NN1,eig3,kmean]  6=[NN1,eig3,kmeds] 
                                     %  7=[LOS,eig1,2dhis]  8=[LOS,eig1,kmean]  9=[LOS,eig1,kmean] 10=[LOS,eig3,2dhis] 11=[LOS,eig3,kmean] 12=[LOS,eig3,kmeds] 
                                     % 13=[RAD,eig1,2dhis] 14=[RAD,eig1,kmeds] 15=[RAD,eig1,kmeds] 16=[RAD,eig3,2dhis] 17=[RAD,eig3,kmean] 18=[RAD,eig3,kmeds] 
    eigvec1       = clusspeceig;
    eigvec2       = 2;
    maxeigvecs = max([eigvec1 eigvec2]);
    if clusspecdata==1
        if ~exist('lapll')
            if ~exist('nn1')
                loadname = 'init'; 
                varinfoo = {loadname,'''nn1'''};
                loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end
                nn1(1:partsize+1:end) = 0;
            end    
            memlaplmat = whos('nn1');
            nn1 = nn1.*wgtmat;
            if ( nnz(nn1)/(memlaplmat.size(1)*memlaplmat.size(2))>0.10)                     %    use full matricies, otherwise use sparse
                lapll =        diag(sum(logical(nn1)))-logical(nn1);
%                lapll =        diag(sum(logical(nn1)))-logical(nn1).*nn1;
                flagusesparse = 0;
            else                                                                       %    use Sparse 
                lapll = sparse(diag(sum(logical(nn1)))-logical(nn1));
                lapllz = sum(logical(nn1),2);
%                lapll = sparse(diag(sum(logical(nn1)))-logical(nn1).*nn1);
                flagusesparse = 1;
            end
            clear nn1
            lapll = (1/basebins^2)*lapll;
        end
    elseif clusspecdata==2
        if ~exist('lapll')
            if ~exist('losmat')
                loadname = 'LOS'; 
                varinfoo = {loadname,'''losmat'''};
                loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end
            end
            memlaplmat = whos('losmat');
            if ( nnz(losmat)/(memlaplmat.size(1)*memlaplmat.size(2))>0.10)                     %    use full matricies, otherwise use sparse
                lapll =        diag(sum(losmat)+1)-losmat;
                flagusesparse = 0;
            else                                                                       %    use Sparse 
                lapll = sparse(diag(sum(losmat)+1)-losmat);
                flagusesparse = 1;
            end
            clear losmat
        end
    elseif clusspecdata==3
        if ~exist('lapll')
            if ~exist('deltar')
                global deltar
                loadname = 'init'; 
                varinfoo = {loadname,'''deltar'''};
                loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end
            end
%             % Radial Basis goes here  -GAUSSIAN
%             if radialsigma==0
%                 sigmaa = sqrt(basebins);
%             elseif radialsigma>0
%                 sigmaa = max(max(deltar))*radialsigma;
%             else
%                 sigmaa = -radialsigma;
%             end
%             sigmaa = max([1 sigmaa]);
%             gaussexp = -(0.5)*(deltar.*deltar)/(sigmaa^2);
%             gaussr = 1/(sigmaa*sqrt(2*pi))*((deltar.*deltar-2*sigmaa^2)/(sigmaa^4)).*exp(gaussexp);
% %            gaussr = exp(gaussexp);
%             clear gaussexp
%             gaussr = gaussr.*(abs(gaussr)>radialthresh);
%             plot(gaussr(100,:))
%             axis auto
%             drawnow
%             memlaplmat = whos('gaussr');
%             if ( nnz(gaussr)/(memlaplmat.size(1)*memlaplmat.size(2))>0.10)                     %    use full matricies, otherwise use sparse
%                 lapll =        gaussr;        
% %                lapll =        diag(sum(gaussr)-1)-gaussr;
%                 plot(lapll(100,:))
%                 drawnow             
%                 flagusesparse = 0;
%             else                                                                       %    use Sparse 
%                 lapll = sparse(gaussr);
%                 lapll = sparse(diag(sum(gaussr)-1)-gaussr);
%                 flagusesparse = 1;
%             end
%             clear gaussr
            % Radial Basis goes here  -GAUSSIAN
            if radialsigma==0
                sigmaa = sqrt(basebins);
            elseif radialsigma>0
                sigmaa = max(max(deltar))*radialsigma;
            else
                sigmaa = -radialsigma;
            end
            sigmaa = max([1 sigmaa]);
            gaussexp = -(0.5)*(deltar.*deltar)/(sigmaa^2);
            gaussr = 1/(sigmaa*sqrt(2*pi))*((deltar.*deltar-2*sigmaa^2)/(sigmaa^4)).*exp(gaussexp);
%            gaussr = exp(gaussexp);
            clear gaussexp
            gaussr = gaussr.*(abs(gaussr)>radialthresh);
            plot(gaussr(100,:))
            axis auto
            drawnow
            memlaplmat = whos('gaussr');
            if ( nnz(gaussr)/(memlaplmat.size(1)*memlaplmat.size(2))>0.10)                     %    use full matricies, otherwise use sparse
                lapll =        gaussr;        
%                lapll =        diag(sum(gaussr)-1)-gaussr;
                plot(lapll(100,:))
                drawnow             
                flagusesparse = 0;
            else                                                                       %    use Sparse 
                lapll = sparse(gaussr);
%                lapll = sparse(diag(sum(gaussr)-1)-gaussr);
                flagusesparse = 1;
            end
            clear gaussr
        end
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%  Do spectral clustering....
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    
%    lapll = lapll + 10*epss*sparse(diag(lapllz==0));
    lapll = lapll + 10*epss*speye(partsize);
%    if flagusesparse==0
%        [V,D] = eig(lapll);
%    else
        [V,D] = eigs(lapll,maxeigvecs,'sm');
%    end
    eignums = diag(D);
    V = fliplr(V);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    
    eignums = flipud(eignums);
    xxx = real(round(V(:,eigvec1)*10^sigfigsspec)/10^sigfigsspec);
    yyy = real(round(V(:,eigvec2)*10^sigfigsspec)/10^sigfigsspec);
    minnx = min(xxx)-epss;
    minny = min(yyy)-epss;
    maxxx = max(xxx)+epss;
    maxxy = max(yyy)+epss;

    binhistx = linspace(minnx,maxxx,clusspechistobins);
    binhisty = linspace(minny,maxxy,clusspechistobins);
    [histnums,bbb,ccc] = histcounts2(xxx,yyy,binhistx,binhisty);
    [histkeepc,histkeepr] = find(histnums>0);

    indexxx = (1:partsize)';
    indexx = (1:max(size(xxx)))';
    numkeep = max(size(histkeepr));
    clustertmp = zeros(numkeep,partsize);
    clusterid = 0;
    XX = [xxx yyy];
    
    if     clusspecdata==1
        gathertype0 = 'NN1';
    elseif clusspecdata==2
        gathertype0 = 'LOS';
    elseif clusspecdata==3
        gathertype0 = 'RAD';
    end
    if clusspecgather==1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%
%%%%  Histogram clustering of the spectral space (default)
%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        for ii = 1:numkeep
            keepx = binhistx(histkeepc(ii));
            keepy = binhisty(histkeepr(ii));
            keepxp1 = binhistx(histkeepc(ii)+1);
            keepyp1 = binhisty(histkeepr(ii)+1);
            checkx = (xxx>=keepx)&(xxx<keepxp1);
            checky = (yyy>=keepy)&(yyy<keepyp1);
            checkxy = checkx&checky;
            keepind= indexx(checkxy);
            clusterid = clusterid+1;
            clustertmphisto(clusterid,1:size(keepind,1)) = keepind;
            clear keepind keepsx keepy keepxp1 keepyp1 checkx checky checkxy
        end
        clustertmp = clustertmphisto;
        clear clustertmphisto
        gathertype = sprintf('2D Histogram and %dx%d Bins for the %s Matrix',clusspechistobins,clusspechistobins,gathertype0);
        gathertype2 = 'HISTO';
        gathertype3 = sprintf('%dx%d',clusspechistobins,clusspechistobins);
    elseif clusspecgather==2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%
%%%%   K Means clustering of the spectral space
%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        optskmeans = statset('Display','final');
%        [kmeansindex,CC] = kmeans(XX,clusspeckmeansnum,'EmptyAction','drop');
        [kmeansindex,CC] = kmeans(XX,clusspeckmeansnum,'Distance','sqeuclidean','Replicates',5,'Options',optskmeans,'EmptyAction','drop');
        for ii = 1:clusspeckmeansnum
            keepind = indexx(kmeansindex==ii);
            clusterid = clusterid+1;
            clustertmpkmeans(clusterid,1:size(keepind,1)) = keepind;
            clear keepind
        end
        clustertmp = clustertmpkmeans;
        clear clustertmpkmeans kmeansindex
        gathertype = sprintf('K-Means and # Sought: %d for the %s Matrix',clusspeckmeansnum,gathertype0);
        gathertype2 = 'KMEAN';
        gathertype3 = sprintf('%d',clusspeckmeansnum);
    elseif clusspecgather==3
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%
%%%%   K Medoids clustering of the spectral space
%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        optskmeds = statset('Display','iter');
%        [kmedoidsindex,CC] = kmedoids(XX,clusspeckmedoidsnum);
        [kmedoidsindex,CC] = kmedoids(XX,clusspeckmedoidsnum,'Distance','sqeuclidean','Options',optskmeds);
        for ii = 1:clusspeckmedoidsnum
            keepind = indexx(kmedoidsindex==ii);
            clusterid = clusterid+1;
            clustertmpkmedoids(clusterid,1:size(keepind,1)) = keepind;
            clear keepind
        end
        clustertmp = clustertmpkmedoids;
        clear clustertmpkmedoids kmedoidsindex
        gathertype = sprintf('K-Medoids and # Sought: %d for the %s Matrix',clusspeckmedoidsnum,gathertype0);
        gathertype2 = 'KMEDS';
        gathertype3 = sprintf('%d',clusspeckmedoidsnum);
    end
    clear XX xxx yyy

    clustertmp(sum(clustertmp,2)==0,:)=[];
    clustertmpc = sum(clustertmp,1);
    clustertmp(:,clustertmpc==0) = [];
    [clustertmp1,clos1a,clos1b] = unique(clustertmp,'rows');
    clustertmp2 = clustertmp1(clos1b,:);

    clustertmp2log = logical(clustertmp2);
    clustertmp2size  = sum(clustertmp2log,2);
    [ca,cb] = sort(clustertmp2size,'descend');
    clustertmp22 = clustertmp2(cb,:);

    clussize = min([size(clustertmp22,1) clustershow]);
    clustertmp2 = clustertmp22(1:clussize,:);
    eval(sprintf('clusterspectral%02d = clustertmp2;',spectralid));
    eval(sprintf('clusterspectralnow = clusterspectral%02d;',spectralid)); 
    eval(sprintf('nclusters%02d = size(clusterspectralnow,1);',spectralid));
    eval(sprintf('nclustersnow = nclusters%02d;',spectralid));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    if (medoidtypespec(spectralid)==1)|(medoidtypespec(spectralid)==3)
        clear pathl
        if ~exist('deltar')
            global deltar
            loadname = 'init'; 
            varinfoo = {loadname,'''deltar'''};
            loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end
        end
    end
    if (medoidtypespec(spectralid)==2)|(medoidtypespec(spectralid)==4)
        if clusspecdata<3
            clear deltar
        end
        if ~exist('pathl')
            global pathl
            loadname = 'connpathl'; 
            varinfoo = {loadname,'''pathl'''};
            loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj}); for ii=1:size(varnames,1); eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); end; loadright1{jj}=[]; end
        end
    end
    if medoidtypespec(spectralid)>=3
        global wgtmat
        wgtmat = partkeepwgts*partkeepwgts';
    end    
%%%%%%%  Find the centers of the dense regions
    for mm = 1:nclustersnow
        [clusmed] = findmedoid_03(clusterspectralnow(mm,:),medoidtypespec(spectralid));
        clustermedoidsnow(mm,1) = clusmed;
    end
    eval(sprintf('clustermedoids%02d = clustermedoidsnow;',spectralid));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = sprintf('spectral%02d',spectralid);
    titleinfo1   = sprintf('%s Clustering #%d into %d Clusters Using %s, %s, Eigen Vectors: [%d,%d]',upper(dataname),spectralid,nclustersnow,gathertype0,gathertype2,eigvec1,eigvec2);
    titleinfo2   = sprintf('Gathering Using: %s',gathertype);
    datainfoo{1} = { eval(sprintf('cluster%s',plotdataname)) clustermedoidsnow };
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 };
    flaginfoo{1} = { plotspectral printspectral plotnow 1 1 plotmedoidsc};
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    eval(sprintf('titlespectral%02d = titleinfo1;',spectralid));
    eval(sprintf('clusterspectral{spectralid,1} = {clusterspectral%02d};',spectralid));
    eval(sprintf('clusterspectral{spectralid,2} = {clustermedoids%02d};',spectralid));
    eval(sprintf('clusterspectral{spectralid,3} = {nclusters%02d};',spectralid));
    eval(sprintf('clusterspectral{spectralid,4} = {titlespectral%02d};',spectralid));
    clear clusterspectralnow clustermedoidsnow nclustersnow
end
end
clear lapll
end
    
    spectralreturn = {clusterspectral};
%%%%
%%%%   Save all of the clusters - Clusters now saved in the "Short" file
%%%%
%     for ii = 1:18
%         vartemp = {sprintf('clusterspectral%02d',ii)}; varinfoo = {vartemp{:} savespec 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
%     end
%%%%
%%%%  Compute memory and timing variables for performance
%%%%
    workspacee = whos;
    memusedspectral = sum([workspacee.bytes]);

    tendspectral = now;
    durationnspectral = tendspectral-tstartspectral;
    display(sprintf('Ending %s Analysis at %s',upper(dataname),datestr(datetime('now'))))
    tstartspectralt = datetime(datevec(tstartspectral));
    tendspectrald   = datetime(datevec(tendspectral));
    timespectral = rem(durationnspectral,1)*86400;
    display(sprintf('%s Analysis Duration: %s',upper(dataname),datestr(timespectral/86400, 'HH:MM:SS')));

%%%%
%%%%   Save all of the variables
%%%%
    varnamess = {varnamesshort{:} varnameslong{:} varnamestime{:}}; 
    for ii = 1:size(varnamess,2); if size(varnamess{ii},2)>0; eval(sprintf('global %s',varnamess{ii})); end; end;
    saverightend01;
%    save('%s/_DATA/prod_fileprefix.mat','fileprefix','shapestr')
    profile off
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
else
    display(sprintf('%s files already exists and OVERWRITE %s set to ZERO.  %s analysis NOT DONE.',upper(dataname),upper(dataname),upper(dataname)));
    spectralreturn = {1};
end
close all
return 




