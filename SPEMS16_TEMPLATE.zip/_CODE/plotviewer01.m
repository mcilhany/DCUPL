%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%
%%%%    Patch Viewer of Data in 2D or 3D:
%%%%    Syntax:     patchviewer01(data matrix,fileinfo,flag1,flag2,flag3)
%%%%                data matrix:  data is assumed to be arranged by
%%%%                clusters with each row a different cluster
%%%%                fileinfo: information about the file, shape, title,
%%%%                axes, etc....
%%%%                flag1:  1 = clusters     2 = surface
%%%%                flag2:  1 = clusters     2 = surface
%%%%                flag3:  1 = clusters     2 = surface
%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ plotviewer1 ] = plotviewer01(varargin)

global fileroot shapestr prodrunnum prepindex fileprefix dataname 
global sigfigs smallpartnums3 partsize  
global dataptsminmax dataptspartkeep dataindexminmax dataindexpartkeep datapartkeepindex dataminmaxpartindex binadd2 datamin datamax datadelta 

if isempty(dataptsminmax)
    loadname = 'init'; varinfoo = {loadname,'''dataptsminmax'''}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end;loadright1{jj}=[];end
end
if isempty(dataindexminmax)
    loadname = 'init'; varinfoo = {loadname,'''dataindexminmax'''}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end;loadright1{jj}=[];end
end
load(sprintf('%s/_DATA/prod/prod_prep_%04d_%04d.mat',fileroot,prodrunnum,prepindex));
plottitles = 0;
if nargin>2    
    if nargin==3
        if ~isempty(dataptsminmax); nvars = size(dataptsminmax,2); end
        plothistogram     = 0;
        plotspy           = 0;
        plotsurface       = 0;
        plotcluster       = 0;
        plotscatter       = 0;
        datainfoo         = varargin{1};
        fileinfoo         = varargin{2};
        flaginfoo         = varargin{3};
        datainfoo         = datainfoo{:};
        fileinfoo         = fileinfoo{:};
        flaginfoo         = flaginfoo{:};
        if size(flaginfoo,2)==4             % Histograms
            flagplot      = flaginfoo{1};
            flagprint     = flaginfoo{2};
            flagview      = flaginfoo{3};
            flaghistogram = flaginfoo{4};
            xlabel1       = fileinfoo{4};
            xlabel2       = fileinfoo{5};
            flagdata      = 0;    
            flagsurf      = 0;    
            flagcluster   = 0;    
            flagmedoids   = 0;    
            plothistogram = 1;
            nvars         = 2;
        elseif size(flaginfoo,2)==5         % Spy or Surfaces  of MATRICES  (2-dimensional only)
            if size(size(datainfoo{1}),2)==2
                flagplot      = flaginfoo{1};
                flagprint     = flaginfoo{2};
                flagview      = flaginfoo{3};
                flagdata      = flaginfoo{4};   % Matrix plot:  data=1, surf=0  SPY plot 
                flagsurf      = flaginfoo{5};   % Matrix plot:  data=1, surf=1  Surface plot 
                flagcluster   = 0;    
                flagmedoids   = 0;    
                flaghistogram = 0;
                if flagsurf==0
                    plotspy       = 1;
                else
                    plotsurface   = 1;
                end
                if size(fileinfoo,2)>3
                    xlabel1       = fileinfoo{4};
                    xlabel2       = fileinfoo{5};
                else
                    xlabel1       = 'X1';
                    xlabel2       = 'X2';
                end
                if flagdata==0
                    transparencymat = 1.0;
                else
                    transparencymat = transparencyfactor;
                end
                nvars         = 2;
            end
        elseif size(flaginfoo,2)==6             % Cluster Patch Plots with Medoids
            flagplot      = flaginfoo{1};
            flagprint     = flaginfoo{2};
            flagview      = flaginfoo{3};
            flagdata      = flaginfoo{4};       % Cluster plot:  data on - use transparency else 100%
            flagcluster   = flaginfoo{5};       % Cluster plot:  cluster on , if off, then just a scatter plot of data
            flagmedoids   = flaginfoo{6};       % Cluster plot:  medoids on or off 
            flagsurf      = 0;    
            flaghistogram = 0;
            if (flagcluster==1)                 % clusters
                if flagmedoids==1               % medoids too
                    matmedoids    = datainfoo{2};
%                    datainfoo     = datainfoo{1};  
                end
                plotcluster = 1;               
            elseif (flagcluster==0)             %  scatter data plot
                flagdata    = 1;
                plotscatter = 1;
                plotpartitions = flagmedoids;
                if plotpartitions==1            % Draw the partition boundaries as well
                    datapartitions = unique(dataindexminmax,'rows')-1;
                    npartitions = max(size(datapartitions));
                end
            end
            if flagdata==0
                transparencyclus = 1.0;
            else
                if nvars==2
                    transparencyclus = transparencyfactor;
                elseif nvars==3
                    transparencyclus = transparencyfactor3d;
                end
            end
        end        
        figinfo       = fileinfoo{1};
        titleinfo1    = fileinfoo{2};
        titleinfo2    = fileinfoo{3};
        if ~isempty(titleinfo2)
            dotitle = sprintf('%s',titleinfo1),sprintf('%s',titleinfo2);
        else
            dotitle = sprintf('%s',titleinfo1);
        end
        if nvars==3
            viewaz = -60;
            viewel = 20;
            viewaz = -72;
            viewel = 20;
            if size(fileinfoo,2)>3
                xlabel1       = fileinfoo{4};
                xlabel2       = fileinfoo{5};
                xlabel3       = fileinfoo{6};
            else
                xlabel1       = 'X1';
                xlabel2       = 'X2';
                xlabel3       = 'X3';
            end
        elseif nvars==2   
            viewaz = 0;
            viewel = 90;
            if size(fileinfoo,2)>3
                xlabel1       = fileinfoo{4};
                xlabel2       = fileinfoo{5};
            else
                xlabel1       = 'X1';
                xlabel2       = 'X2';
            end
        else
            viewaz = 0;
            viewel = 90;
            xlabel1       = 'X1';
            xlabel2       = 'X2';
        end 
        if isempty(datainfoo{1})
            loadname = 'init'; varinfoo = {loadname,'''dataptsminmax'''}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end;loadright1{jj}=[];end    
        end
    end
else
    display('Not enough/incorrect inputs.  Stopping.');
    flagplot = 0;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
if flagplot==1    
    if plotscatter==1
        if isempty(datamin); dataminn = minn; else; dataminn = datamin; end
        %clf('reset');set(gcf, 'Position', get(0, 'Screensize'));
        clf('reset');set(gcf, 'Position', [1 1 1600 1000]);
        if flagview==0; set(gcf,'Visibile','off'); end
        if flagdata==1
            if realdata
                if nvars == 2
                    if max(size(datainfoo{1}))>smallpartnums1
                        scatter(datainfoo{1}(:,1),datainfoo{1}(:,2),'.')
                    else
                        scatter(datainfoo{1}(:,1),datainfoo{1}(:,2),'.','MarkerSize',8)
                    end
                    if plotaxes==1;   xlabel(xlabel1); ylabel(xlabel2);    end;
                    if realdata; eval(sprintf('axis equal tight xy')); else; eval(sprintf('axis equal tight ij')); end
                elseif nvars == 3
                    if max(size(datainfoo{1}))>smallpartnums1
                        plot3(datainfoo{1}(:,1),datainfoo{1}(:,2),datainfoo{1}(:,3),'.','MarkerSize',12)
                    else
                        plot3(datainfoo{1}(:,1),datainfoo{1}(:,2),datainfoo{1}(:,3),'.','MarkerSize',8)
                    end
                    if plotaxes==1;   xlabel(xlabel1); ylabel(xlabel2); zlabel(xlabel3);  end;
                    if realdata; eval(sprintf('axis equal tight xy')); else; eval(sprintf('axis equal tight ij')); end
                end
            else
                if max(size(datainfoo{1}))>smallpartnums1
                    scatter(datainfoo{1}(:,1),datainfoo{1}(:,2),'.')
                else
                    scatter(datainfoo{1}(:,1),datainfoo{1}(:,2),'.','MarkerSize',8)
                end
                if plotaxes==1;   xlabel(xlabel1); ylabel(xlabel2);    end;
                if realdata; eval(sprintf('axis equal tight xy')); else; eval(sprintf('axis equal tight xy')); end
            end
        end
        if plotpartitions==1
            hold on
            if nvars==2
                for kk = 1:npartitions
                    if basebins<=60
                        plot((datapartitions(kk,1)+0.5)*datadelta(1)+dataminn(1),(datapartitions(kk,2)+0.5)*datadelta(2)+dataminn(2),'ro')
                    end
                    rectangle('Position',[datapartitions(kk,1)*datadelta(1)+dataminn(1) datapartitions(kk,2)*datadelta(2)+dataminn(2) datadelta(1) datadelta(2)])
                end
                if plotaxes==1;   xlabel(xlabel1); ylabel(xlabel2);    end;
            end
        end
        if plottitles==1; eval(sprintf('title({dotitle},''FontSize'',24)')); end
        axx = gca;
        axx.FontSize = 16;
        view(viewaz,viewel);
        if flagprint
            eval(sprintf('export_fig(figinfo,''-m%d'')',magprint));
        end
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%          
    if plotcluster==1
               
        coloradjustt  = 2.1;
        clustershow   = 1e6;
        sigfigsspec   = 5;
        indexxs       = 1:partsize;
        plotlosview   = 0;
        realdata      = 1;
        nvars         = size(datamin,2);
%        transparencyfactor = 0.5;
%        transparencyfactor3d = 0.4;

        %clf('reset');set(gcf, 'Position', get(0, 'Screensize'));
        clf('reset');set(gcf, 'Position', [1 1 1600 1000]);
        if flagview==0; set(gcf,'Visibile','off'); end
        hold on
        if flagdata==1
            if realdata
                if nvars == 2
                    if partsize>smallpartnums1
                        phand = scatter(dataptsminmax(:,1),dataptsminmax(:,2),'.');
                        phand.MarkerFaceAlpha = transparencyclus;
                        phand.MarkerEdgeAlpha = transparencyclus;
                    else
                        phand = scatter(dataptsminmax(:,1),dataptsminmax(:,2),72,'.');
                        phand.MarkerFaceAlpha = transparencyclus;
                        phand.MarkerEdgeAlpha = transparencyclus;
                    end
                elseif nvars == 3
                    if partsize>smallpartnums1
                        phand = scatter3(dataptsminmax(:,1),dataptsminmax(:,2),dataptsminmax(:,3),'.');
                        phand.MarkerFaceAlpha = transparencyfactorpts;
                        phand.MarkerEdgeAlpha = transparencyfactorpts;
                    else
                        phand = scatter3(dataptsminmax(:,1),dataptsminmax(:,2),dataptsminmax(:,3),'.');
                    end
                end
            else
                if partsize>smallpartnums1
                    phand = scatter(dataptsminmax(:,1),dataptsminmax(:,2),'.');
                    phand.MarkerFaceAlpha = transparencyclus;
                    phand.MarkerEdgeAlpha = transparencyclus;
                else
                    phand = scatter(dataptsminmax(:,1),dataptsminmax(:,2),72,'.')
                end
            end
        end
        if nvars==2
            datapartitions = unique(dataindexminmax,'rows')-1;
            npartitions = max(size(datapartitions));
            for kkk = 1:npartitions
                rectangle('Position',[datapartitions(kkk,1)*datadelta(1)+datamin(1) datapartitions(kkk,2)*datadelta(2)+datamin(2) datadelta(1) datadelta(2)])
            end
        end
        if partsize>smallpartnums1
            if realdata; eval(sprintf('axis equal tight xy')); else; eval(sprintf('axis equal tight xy')); end
        else
            if realdata; eval(sprintf('axis equal xy')); else; eval(sprintf('axis equal xy')); end
        end
        
        
        hold on
        if (size(datainfoo{1},1)+size(datainfoo{1},2))>2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Patches are Clusters
            if isempty(binadd2)
                loadname = 'init'; varinfoo = {loadname,'''binadd2'''}; loadright1 = loadright03(varinfoo); for jj=1:size(loadright1,2); varnames=fieldnames(loadright1{jj});for ii=1:size(varnames,1);eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii}));end;loadright1{jj}=[];end
            end
            
            nclusters = size(datainfoo{1},1);
            numcolors = max([ceil(nclusters*coloradjustt)]);
            cmapklm = colormap(colorcube(numcolors));
            cmapfloor = floor(cmapklm);
            sumcmap = sum(cmapfloor,2);
            cmapremove = find(sumcmap==3);
            cmapklm(cmapremove,:) = [];
            cmapfloor = floor(cmapklm);
            sumcmap = sum(cmapfloor,2);
            cmapremove = find(sumcmap==2);
            cmapklm(cmapremove,:) = [];
            cmapfloor = floor(cmapklm);
            sumcmap = sum(cmapfloor,2);
            cmapremove = find(sumcmap==1);
            cmapklm(cmapremove,:) = [];
            sumcmap = sum(cmapklm,2);
            cmapremove = find(sumcmap<0.5);
            cmapklm(cmapremove,:) = [];
            prodcmap = cmapklm(:,1).*cmapklm(:,2).*cmapklm(:,3);
            cmapremove = find(prodcmap>0.8);
            cmapklm(cmapremove,:) = [];
            cmapklm = (cmapklm*0.8)+0.1;
            cmapklm = [cmapklm; 1 0 0];
            cmapklm = [cmapklm; 0 1 0];
            cmapklm = [cmapklm; 0 0 1];
            cmapklm = [cmapklm; 1 0 1];
            cmapklm = [cmapklm; 1 1 0];
            cmapklm = [cmapklm; 0 1 1];
            cmapklm = [cmapklm; 0.1 0.1 0.1];
            cmapklm = circshift(cmapklm,+7,1);
            cmapklm = cmapklm(1:nclusters,:);
            cmapklm = flipud(cmapklm);

            colormap(cmapklm); 
            cnums = 1:nclusters;
            ncmap = size(cmapklm,1);
            caxis([1-0.0001 nclusters+0.0001]);
            % cmapklm = colormap(jet(numclusters+1));
            if strcmp(dataname,'LMHpos')
                global binadd2LMH datadeltaLMH 
                binadd2plots   = binadd2LMH;
                datadeltaplots = datadeltaLMH;
            else
                binadd2plots   = binadd2;
                datadeltaplots = datadelta;
            end
            datadeltaplotss = datadeltaplots;
            dataminn        = datamin;
            if strcmp(dataname,'kmeanmeds')
                global kloop
%                if kloop==2; binadd2plots = dataindexpartkeep; end
                if kloop==2; binadd2plots = binadd2; end
                if kloop==3; binadd2plots = dataptspartkeep; datadeltaplotss(1:3) = 1; dataminn(1:3)= 0; end
            end
            for ii = 1:nclusters
                clusterind2 = datainfoo{1}(ii,:);
                clusterind2(clusterind2==0) = [];
                if exist('kloop')&(kloop>2)
                    patchxx = (binadd2plots(clusterind2,1))*datadeltaplotss(1)+dataminn(1);
                    patchyy = (binadd2plots(clusterind2,2))*datadeltaplotss(2)+dataminn(2);
                    if nvars>2;        patchzz = zeros(1,size(clusterind2,2)); end
                    if nvars>2
                        patchzz = (binadd2plots(clusterind2,3))*datadeltaplotss(3)+dataminn(3);
                    end
                    patchcc = ncmap+1-cnums(ii);
                    if nvars==2
                        phand = scatter(patchxx,patchyy,36,cmapklm(patchcc,:),'.');
                    elseif nvars>2
                        phand = scatter3(patchxx,patchyy,patchzz,36,cmapklm(patchcc,:),'.');
                        phand = scatter3(patchxx,patchyy,patchzz,36,cmapklm(patchcc,:),'.');
                        phand = scatter3(patchxx,patchyy,patchzz,36,cmapklm(patchcc,:),'.');
                    end
                    phand.MarkerFaceAlpha = transparencyclus;
                    phand.MarkerEdgeAlpha = transparencyclus;
%                    phand.MarkerFaceAlpha = 1.0;
%                    phand.MarkerEdgeAlpha = 1.0;
                else
                    patchxx = zeros(4,size(clusterind2,2));
                    patchyy = zeros(4,size(clusterind2,2));
                    if nvars>2;        patchzz = zeros(4,size(clusterind2,2)); end
                    patchcc = zeros(4,size(clusterind2,2));
                    patchxx(1,:) = (binadd2plots(clusterind2,1)-1)*datadeltaplotss(1)+dataminn(1);
                    patchxx(2,:) = (binadd2plots(clusterind2,1)+0)*datadeltaplotss(1)+dataminn(1);
                    patchxx(3,:) = (binadd2plots(clusterind2,1)+0)*datadeltaplotss(1)+dataminn(1);
                    patchxx(4,:) = (binadd2plots(clusterind2,1)-1)*datadeltaplotss(1)+dataminn(1);
                    patchyy(1,:) = (binadd2plots(clusterind2,2)-1)*datadeltaplotss(2)+dataminn(2);
                    patchyy(2,:) = (binadd2plots(clusterind2,2)-1)*datadeltaplotss(2)+dataminn(2);
                    patchyy(3,:) = (binadd2plots(clusterind2,2)+0)*datadeltaplotss(2)+dataminn(2);
                    patchyy(4,:) = (binadd2plots(clusterind2,2)+0)*datadeltaplotss(2)+dataminn(2);
                    if nvars>2
                        patchzz(1,:) = (binadd2plots(clusterind2,3)-1)*datadeltaplotss(3)+dataminn(3);
                        patchzz(2,:) = (binadd2plots(clusterind2,3)-1)*datadeltaplotss(3)+dataminn(3);
                        patchzz(3,:) = (binadd2plots(clusterind2,3)-1)*datadeltaplotss(3)+dataminn(3);
                        patchzz(4,:) = (binadd2plots(clusterind2,3)-1)*datadeltaplotss(3)+dataminn(3);
                    end
                    patchcc(1,:) = ncmap+1-cnums(ii);
                    patchcc(2,:) = ncmap+1-cnums(ii);
                    patchcc(3,:) = ncmap+1-cnums(ii);
                    patchcc(4,:) = ncmap+1-cnums(ii);
                    if nvars==2
                        patch(patchxx,patchyy,patchcc,'FaceAlpha',transparencyclus)
                    elseif nvars>2
                        patch(patchxx,patchyy,patchzz,patchcc,'FaceAlpha',transparencyclus)
                        patch(patchxx,patchyy,patchzz,patchcc,'FaceAlpha',transparencyclus)
                        patch(patchxx,patchyy,patchzz,patchcc,'FaceAlpha',transparencyclus)
                    end
                    clear patchxx patchyy patchcc clusterind2 xvals yvals
                end
            end        
            if flagmedoids==1
                for jj = 1:nclusters
                    if matmedoids(jj)>0
                    if size(matmedoids,2)==1
                        kk = matmedoids(jj);
                        if nvars==2
                            clusterz = 0.5;
                            minz = 0;
                            deltaz = 0;
                        elseif nvars==3
                            clusterz = binadd2plots(kk,3);
                            minz = dataminn(3);
                            deltaz = datadeltaplotss(3);
                        end
                        plot3((binadd2plots(kk,1)-0.5)*datadeltaplotss(1)+dataminn(1),(binadd2plots(kk,2)-0.5)*datadeltaplotss(2)+dataminn(2),(clusterz-0.5)*deltaz+minz,'ko','MarkerEdgeColor',cmapklm(ncmap+1-jj,:),'MarkerSize',markersizee,'LineWidth',3);
                        plot3((binadd2plots(kk,1)-0.5)*datadeltaplotss(1)+dataminn(1),(binadd2plots(kk,2)-0.5)*datadeltaplotss(2)+dataminn(2),(clusterz-0.5)*deltaz+minz,'ko','MarkerSize',markersizee/1.3,'LineWidth',3);
                        plot3((binadd2plots(kk,1)-0.5)*datadeltaplotss(1)+dataminn(1),(binadd2plots(kk,2)-0.5)*datadeltaplotss(2)+dataminn(2),(clusterz-0.5)*deltaz+minz,'ko','MarkerEdgeColor',cmapklm(ncmap+1-jj,:),'MarkerSize',markersizee,'LineWidth',3);
                        plot3((binadd2plots(kk,1)-0.5)*datadeltaplotss(1)+dataminn(1),(binadd2plots(kk,2)-0.5)*datadeltaplotss(2)+dataminn(2),(clusterz-0.5)*deltaz+minz,'ko','MarkerSize',markersizee/1.3,'LineWidth',3);
                        plot3((binadd2plots(kk,1)-0.5)*datadeltaplotss(1)+dataminn(1),(binadd2plots(kk,2)-0.5)*datadeltaplotss(2)+dataminn(2),(clusterz-0.5)*deltaz+minz,'ko','MarkerEdgeColor',cmapklm(ncmap+1-jj,:),'MarkerSize',markersizee,'LineWidth',3);
                        plot3((binadd2plots(kk,1)-0.5)*datadeltaplotss(1)+dataminn(1),(binadd2plots(kk,2)-0.5)*datadeltaplotss(2)+dataminn(2),(clusterz-0.5)*deltaz+minz,'ko','MarkerSize',markersizee/1.3,'LineWidth',3);
                        plot3((binadd2plots(kk,1)-0.5)*datadeltaplotss(1)+dataminn(1),(binadd2plots(kk,2)-0.5)*datadeltaplotss(2)+dataminn(2),(clusterz-0.5)*deltaz+minz,'ko','MarkerEdgeColor',cmapklm(ncmap+1-jj,:),'MarkerSize',markersizee,'LineWidth',3);
                        plot3((binadd2plots(kk,1)-0.5)*datadeltaplotss(1)+dataminn(1),(binadd2plots(kk,2)-0.5)*datadeltaplotss(2)+dataminn(2),(clusterz-0.5)*deltaz+minz,'ko','MarkerSize',markersizee/1.3,'LineWidth',3);
                        if flagdata==0
                            innercolorr = [1 1 1];
                        else
                            innercolorr = cmapklm(ncmap+1-jj,:);
                        end
                        plot3((binadd2plots(kk,1)-0.5)*datadeltaplotss(1)+dataminn(1),(binadd2plots(kk,2)-0.5)*datadeltaplotss(2)+dataminn(2),(clusterz-0.5)*deltaz+minz,'ko','MarkerEdgeColor',innercolorr,'MarkerSize',markersizee/2,'LineWidth',3);
                        plot3((binadd2plots(kk,1)-0.5)*datadeltaplotss(1)+dataminn(1),(binadd2plots(kk,2)-0.5)*datadeltaplotss(2)+dataminn(2),(clusterz-0.5)*deltaz+minz,'ko','MarkerEdgeColor',innercolorr,'MarkerSize',markersizee/2,'LineWidth',3);
                        plot3((binadd2plots(kk,1)-0.5)*datadeltaplotss(1)+dataminn(1),(binadd2plots(kk,2)-0.5)*datadeltaplotss(2)+dataminn(2),(clusterz-0.5)*deltaz+minz,'ko','MarkerEdgeColor',innercolorr,'MarkerSize',markersizee/2,'LineWidth',3);
                        plot3((binadd2plots(kk,1)-0.5)*datadeltaplotss(1)+dataminn(1),(binadd2plots(kk,2)-0.5)*datadeltaplotss(2)+dataminn(2),(clusterz-0.5)*deltaz+minz,'ko','MarkerEdgeColor',innercolorr,'MarkerSize',markersizee/2,'LineWidth',3);
                        plot3((binadd2plots(kk,1)-0.5)*datadeltaplotss(1)+dataminn(1),(binadd2plots(kk,2)-0.5)*datadeltaplotss(2)+dataminn(2),(clusterz-0.5)*deltaz+minz,'ko','MarkerEdgeColor',innercolorr,'MarkerSize',markersizee/2,'LineWidth',3);
                        plot3((binadd2plots(kk,1)-0.5)*datadeltaplotss(1)+dataminn(1),(binadd2plots(kk,2)-0.5)*datadeltaplotss(2)+dataminn(2),(clusterz-0.5)*deltaz+minz,'ko','MarkerEdgeColor',innercolorr,'MarkerSize',markersizee/2,'LineWidth',3);
                        plot3((binadd2plots(kk,1)-0.5)*datadeltaplotss(1)+dataminn(1),(binadd2plots(kk,2)-0.5)*datadeltaplotss(2)+dataminn(2),(clusterz-0.5)*deltaz+minz,'ko','MarkerEdgeColor',innercolorr,'MarkerSize',markersizee/2,'LineWidth',3);
                        plot3((binadd2plots(kk,1)-0.5)*datadeltaplotss(1)+dataminn(1),(binadd2plots(kk,2)-0.5)*datadeltaplotss(2)+dataminn(2),(clusterz-0.5)*deltaz+minz,'ko','MarkerEdgeColor',innercolorr,'MarkerSize',markersizee/2,'LineWidth',3);
                    else
                        kk = matmedoids(jj,:);
                        if nvars==2
                            clusterz = 0.5;
                            minz = 0;
                            deltaz = 0;
                        elseif nvars==3
                            clusterz = kk(3);
                            minz = dataminn(3);
                            deltaz = datadeltaplotss(3);
                        end
                        plot3((kk(1)-0.5)*datadeltaplotss(1)+dataminn(1),(kk(2)-0.5)*datadeltaplotss(2)+dataminn(2),(clusterz-0.5)*deltaz+minz,'ko','MarkerEdgeColor',cmapklm(ncmap+1-jj,:),'MarkerSize',markersizee,'LineWidth',3);
                        plot3((kk(1)-0.5)*datadeltaplotss(1)+dataminn(1),(kk(2)-0.5)*datadeltaplotss(2)+dataminn(2),(clusterz-0.5)*deltaz+minz,'ko','MarkerSize',markersizee/1.3,'LineWidth',3);
                        plot3((kk(1)-0.5)*datadeltaplotss(1)+dataminn(1),(kk(2)-0.5)*datadeltaplotss(2)+dataminn(2),(clusterz-0.5)*deltaz+minz,'ko','MarkerEdgeColor',cmapklm(ncmap+1-jj,:),'MarkerSize',markersizee,'LineWidth',3);
                        plot3((kk(1)-0.5)*datadeltaplotss(1)+dataminn(1),(kk(2)-0.5)*datadeltaplotss(2)+dataminn(2),(clusterz-0.5)*deltaz+minz,'ko','MarkerSize',markersizee/1.3,'LineWidth',3);
                        plot3((kk(1)-0.5)*datadeltaplotss(1)+dataminn(1),(kk(2)-0.5)*datadeltaplotss(2)+dataminn(2),(clusterz-0.5)*deltaz+minz,'ko','MarkerEdgeColor',cmapklm(ncmap+1-jj,:),'MarkerSize',markersizee,'LineWidth',3);
                        plot3((kk(1)-0.5)*datadeltaplotss(1)+dataminn(1),(kk(2)-0.5)*datadeltaplotss(2)+dataminn(2),(clusterz-0.5)*deltaz+minz,'ko','MarkerSize',markersizee/1.3,'LineWidth',3);
                        plot3((kk(1)-0.5)*datadeltaplotss(1)+dataminn(1),(kk(2)-0.5)*datadeltaplotss(2)+dataminn(2),(clusterz-0.5)*deltaz+minz,'ko','MarkerEdgeColor',cmapklm(ncmap+1-jj,:),'MarkerSize',markersizee,'LineWidth',3);
                        plot3((kk(1)-0.5)*datadeltaplotss(1)+dataminn(1),(kk(2)-0.5)*datadeltaplotss(2)+dataminn(2),(clusterz-0.5)*deltaz+minz,'ko','MarkerSize',markersizee/1.3,'LineWidth',3);
                        if flagdata==0
                            innercolorr = [1 1 1];
                        else
                            innercolorr = cmapklm(ncmap+1-jj,:);
                        end
                        plot3((kk(1)-0.5)*datadeltaplotss(1)+dataminn(1),(kk(2)-0.5)*datadeltaplotss(2)+dataminn(2),(clusterz-0.5)*deltaz+minz,'ko','MarkerEdgeColor',innercolorr,'MarkerSize',markersizee/2,'LineWidth',3);
                        plot3((kk(1)-0.5)*datadeltaplotss(1)+dataminn(1),(kk(2)-0.5)*datadeltaplotss(2)+dataminn(2),(clusterz-0.5)*deltaz+minz,'ko','MarkerEdgeColor',innercolorr,'MarkerSize',markersizee/2,'LineWidth',3);
                        plot3((kk(1)-0.5)*datadeltaplotss(1)+dataminn(1),(kk(2)-0.5)*datadeltaplotss(2)+dataminn(2),(clusterz-0.5)*deltaz+minz,'ko','MarkerEdgeColor',innercolorr,'MarkerSize',markersizee/2,'LineWidth',3);
                        plot3((kk(1)-0.5)*datadeltaplotss(1)+dataminn(1),(kk(2)-0.5)*datadeltaplotss(2)+dataminn(2),(clusterz-0.5)*deltaz+minz,'ko','MarkerEdgeColor',innercolorr,'MarkerSize',markersizee/2,'LineWidth',3);
                        plot3((kk(1)-0.5)*datadeltaplotss(1)+dataminn(1),(kk(2)-0.5)*datadeltaplotss(2)+dataminn(2),(clusterz-0.5)*deltaz+minz,'ko','MarkerEdgeColor',innercolorr,'MarkerSize',markersizee/2,'LineWidth',3);
                        plot3((kk(1)-0.5)*datadeltaplotss(1)+dataminn(1),(kk(2)-0.5)*datadeltaplotss(2)+dataminn(2),(clusterz-0.5)*deltaz+minz,'ko','MarkerEdgeColor',innercolorr,'MarkerSize',markersizee/2,'LineWidth',3);
                        plot3((kk(1)-0.5)*datadeltaplotss(1)+dataminn(1),(kk(2)-0.5)*datadeltaplotss(2)+dataminn(2),(clusterz-0.5)*deltaz+minz,'ko','MarkerEdgeColor',innercolorr,'MarkerSize',markersizee/2,'LineWidth',3);
                        plot3((kk(1)-0.5)*datadeltaplotss(1)+dataminn(1),(kk(2)-0.5)*datadeltaplotss(2)+dataminn(2),(clusterz-0.5)*deltaz+minz,'ko','MarkerEdgeColor',innercolorr,'MarkerSize',markersizee/2,'LineWidth',3);
                    end
                    end
                        
                end
            end
        else
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Patches are the partitions colored by the Rainbow (jet)
            cmapklm = colormap(jet(partsize+1));
            nvals = 1:partsize;  
            patchxx = zeros(4,partsize);
            patchyy = zeros(4,partsize);
            if nvars>2
                patchzz = zeros(4,partsize);
            end
            patchcc = zeros(4,partsize);
            for kk = 1:partsize
                patchxx(1,kk) = (binadd2(kk,1)-1)*datadelta(1)+datamin(1);
                patchxx(2,kk) = (binadd2(kk,1)+0)*datadelta(1)+datamin(1);
                patchxx(3,kk) = (binadd2(kk,1)+0)*datadelta(1)+datamin(1);
                patchxx(4,kk) = (binadd2(kk,1)-1)*datadelta(1)+datamin(1);
                patchyy(1,kk) = (binadd2(kk,2)-1)*datadelta(2)+datamin(2);
                patchyy(2,kk) = (binadd2(kk,2)-1)*datadelta(2)+datamin(2);
                patchyy(3,kk) = (binadd2(kk,2)+0)*datadelta(2)+datamin(2);
                patchyy(4,kk) = (binadd2(kk,2)+0)*datadelta(2)+datamin(2);
                if nvars>2
                    patchzz(1,kk) = (binadd2(kk,3)-1)*datadelta(3)+datamin(3);
                    patchzz(2,kk) = (binadd2(kk,3)-1)*datadelta(3)+datamin(3);
                    patchzz(3,kk) = (binadd2(kk,3)-1)*datadelta(3)+datamin(3);
                    patchzz(4,kk) = (binadd2(kk,3)-1)*datadelta(3)+datamin(3);
                end
                patchcc(1,kk) = kk;
                patchcc(2,kk) = kk;
                patchcc(3,kk) = kk;
                patchcc(4,kk) = kk;
                if nvars==2
                    patch(patchxx(:,kk),patchyy(:,kk),patchcc(:,kk),'FaceAlpha',transparencyclus)
                elseif nvars>2
                    patch(patchxx(:,kk),patchyy(:,kk),patchzz(:,kk),patchcc(:,kk),'FaceAlpha',transparencyclus)
                    patch(patchxx(:,kk),patchyy(:,kk),patchzz(:,kk),patchcc(:,kk),'FaceAlpha',transparencyclus)
                    patch(patchxx(:,kk),patchyy(:,kk),patchzz(:,kk),patchcc(:,kk),'FaceAlpha',transparencyclus)
                end
            end
        end
        
        if partsize<smallpartnums1
        if nvars==2
            xvals = binadd2(:,1)-1;
            yvals = binadd2(:,2)-1;
            for jj = 1:max(size(xvals))
                x1 = xvals(jj)*datadelta(1)+datamin(1);
                x2 = xvals(jj)*datadelta(1)+datamin(1) + datadelta(1);
                y1 = yvals(jj)*datadelta(2)+datamin(2);
                y2 = yvals(jj)*datadelta(2)+datamin(2) + datadelta(2);
                poss = [(xvals(jj)*datadelta(1)+datamin(1)) ((yvals(jj)*datadelta(2))+datamin(2)) datadelta(1) datadelta(2)];
               text(poss(1)+datadelta(1)/2*.3,(poss(2)+datadelta(2)/2*1.05),num2str(jj),'Color',[0.7 0.5 0.3],'FontSize',14);
            end
        end
        end
        view(viewaz,viewel);
        hclb = colorbar;
        if nvars==3; set(hclb,'Position',[0.78 0.1233 0.0167 0.7883]); end
        hclb.Ticks = [];
        axis([datamin(1) datamax(1) datamin(2) datamax(2)])
        if realdata; eval(sprintf('axis equal tight xy')); else; eval(sprintf('axis equal tight xy')); end
        if plottitles==1; eval(sprintf('title({dotitle},''FontSize'',24)')); end
        if nvars==2;         
            if plotaxes==1;   xlabel(xlabel1); ylabel(xlabel2);    end;
        elseif nvars==3
            if plotaxes==1;   xlabel(xlabel1); ylabel(xlabel2);  zlabel(xlabel3);    end;
        end
        axx = gca;
        axx.FontSize = 16;
        if partsize>smallpartnums1
            set(unique(findall(findobj(gcf),'Type','patch')),'EdgeColor','none')
        end
%        if nvars>2; view(-60,45); end
%        if nvars>2; view(-81,23); end
%        pos=get(gca,'pos');
%        set(gca,'pos',[pos(1) pos(2) pos(3)*0.72 pos(4)]);
%        pos=get(gca,'pos');
%        if nvars==2; colorbarshift=0; elseif nvars==3; colorbarshift=pos(1); end;
%        hclb = colorbar('location','eastoutside','position',[colorbarshift+pos(3) pos(2) 0.015 pos(4)]);
%        hclb = colorbar('location','eastoutside');
%        % set(hclb,'yaxisloc','right');
%        hclb.Ticks = [];
%        if realdata; eval(sprintf('axis equal tight xy')); else; eval(sprintf('axis equal tight xy')); end
        
        if flagprint
            eval(sprintf('export_fig(figinfo,''-m%d'')',magprint));
%            export_fig(figinfo,'-m3');
        end
        
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        
    if (plotspy==1)|(plotsurface==1)
        clf('reset');set(gcf, 'Position', [1 1 1600 1000]);
        if flagview==0; set(gcf,'Visibile','off'); end
        if plotspy==1                %   SPY
            if partsize>smallpartnums2
                spy(datainfoo{1});
            else
                spy(datainfoo{1},30);
            end
        else                         %   SURFACE
            handx = imagesc(datainfoo{1});
            hanc = colorbar;
            set(hanc,'FontSize',16)
            handx.AlphaData = transparencymat;
        end
        if plottitles==1; eval(sprintf('title({dotitle},''FontSize'',24)')); end
        if plotaxes==1;   xlabel(xlabel1); ylabel(xlabel2);    end;
        axx = gca;
        axx.FontSize = 16;
        view(viewaz,viewel);
        if realdata; eval(sprintf('axis equal tight ij')); else; eval(sprintf('axis equal tight ij')); end
        if flagprint
            eval(sprintf('export_fig(figinfo,''-m%d'')',magprint));
%            export_fig(figinfo,'-m3');        
        end
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        
%     if plothistogram==1              % HISTOGRAM
%         clf('reset');set(gcf, 'Position', [1 1 1600 1000]);
%         if flagview==0; set(gcf,'Visibile','off'); end
%         bar(datainfoo{1},datainfoo{2},'LineWidth',2)
% %         baa = bar(log10(datainfoo{1}),log10(datainfoo{2}),'LineWidth',2)
% %         baa.BarWidth = max(size(baa.XData))/30;
% %         xarrow = [0.33 0.30];
% %         yarrow = [0.88 0.72];
% %         aaa = annotation('textarrow',xarrow,yarrow,'String',sprintf('    Cut at Population=%d',2),'FontSize',16,'LineWidth',4); 
% %         xarrow = [0.45 0.42];
% %         yarrow = [0.80 0.65];
% %         aa = annotation('textarrow',xarrow,yarrow,'String',sprintf('    Cut at %4.2f%% total',0.05),'FontSize',16,'LineWidth',4); 
% %         if plotaxes==1;   xlabel('Log10(populations)'); ylabel('Log10(Counts)');    end;
%         if plottitles==1; eval(sprintf('title({dotitle},''FontSize'',24)')); end
%          if plotaxes==1;   xlabel(xlabel1); ylabel(xlabel2);    end;
%         axx = gca;
%         axx.FontSize = 16;
%         view(viewaz,viewel);
%         if realdata; eval(sprintf('axis tight xy')); else; eval(sprintf('axis tight xy')); end
%         if flagprint
%             eval(sprintf('export_fig(figinfo,''-m%d'')',magprint));
% %            export_fig(figinfo,'-m3');
%         end
%     end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        
end
plotviewer = {1};
return
    

