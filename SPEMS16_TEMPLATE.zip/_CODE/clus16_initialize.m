function [ initializereturn ] = clus16_initialize(varargin)
close all force
profile off
warning off
global fileroot shapestr prodrunnum prepindex fileprefix dataname 
global sigfigs smallpartnums3 partsize  
global dataptsminmax dataptspartkeep dataindexminmax dataindexpartkeep datapartkeepindex dataminmaxpartindex binadd2 datamin datamax datadelta 
global varnamesshort varnameslong varnamestime
varnamesshort = {'bignum','sigfigs','threshpeak','minpop','minpathl','threshdist','nvars','databins','datadelta','datamin','datamax','shapestr','partsize','partkeep','partkeepwgts','partkeepind','memusedinit','realdata','binfactor3','fillnorm','maxpathcount','ppnn1c','qqnn1c','rrnn1c','ssnn1c','ttnn1c','uunn1c','realdata','sizedataraw','npartitionsr','sizedatagood','sizedatakeep','partkeepnum','minn','maxx','mapdataorder2'};
varnameslong  = {'binadd2','dataindexminmax','dataptsminmax','nn1','deltar','deltaxl1','pathltrue','pathl1true','pathl1corr','pathcount','binaddu','wgtp','dataptspartkeep','dataindexpartkeep','datapartkeepindex','dataminmaxpartindex'};
varnamestime  = {'timeinit','tstartinitt','tendinitd'};
dataname      = 'init';

load(sprintf('%s/_DATA/prod/prod_prep_%04d_%04d.mat',fileroot,prodrunnum,prepindex));
display(sprintf('%04d - %s - Initial Binning',prodrunnum,fileprefix))

tstartinit = now;

checkfileinit0 = ls(sprintf('%s/_DATA/%s/prod_%04d_%s_*.mat',fileroot,shapestr,prodrunnum,dataname));
checkfileinit  = logical(size(checkfileinit0,2));
if checkfileinit
   display('INITIALIZE clustering already done.');
end
checkgoinit =  ~(checkfileinit&(~checkoverwriteinitialize));
if checkgoinit             % GO!!!!!!!
    display(sprintf('INITIALIZE files:  %1d OVERWRITE INITIALIZE:  %1d   INITIALIZE analysis will be DONE.',checkfileinit,checkoverwriteinitialize));

nvars = 2;
if (shapeindex==13)|(shapeindex==14); nvars = 3; end
if (shapeindex<=10); userminmax = 1; end
if (shapeindex==4); userminmax = 0; end
if nvars==2; dataorder(3) = 0; else dataorder(3) = 3; end
realdata = strcmp(shapestr(1:min([max(size(shapestr)) 4])),'data');
display(sprintf('EI        Names:  alpha rroc vfast vslow velasym beta betaang ke omega ow qcriterion sigma'));
display(sprintf('EI ordering now: [  %d    %d     %d     %d      %d     %d      %d     %d    %d   %d     %d        %d  ]',dataorder(1),dataorder(2),dataorder(3),dataorder(4),dataorder(5),dataorder(6),dataorder(7),dataorder(8),dataorder(9),dataorder(10),dataorder(11),dataorder(12)));
datacode = sprintf('%01d%01d%01d%01d%01d%01d%01d%01d%01d%01d%01d%0d',dataorder(1),dataorder(2),dataorder(3),dataorder(4),dataorder(5),dataorder(6),dataorder(7),dataorder(8),dataorder(9),dataorder(10),dataorder(11),dataorder(12));
nvars = sum(dataorder~=0);
fileprefix = sprintf('%s_%03d_%03d_%12d',shapestr,basebinstitle,minpop,eval(datacode));
fileprefix = sprintf('%s_%03d',shapestr,basebinstitle);
save(sprintf('%s/_DATA/prod/prod_prep_%04d_%04d.mat',fileroot,prodrunnum,prepindex),'nvars','-append');
save(sprintf('%s/_DATA/prod/prod_prep_%04d_%04d.mat',fileroot,prodrunnum,prepindex),'realdata','-append');
save(sprintf('%s/_DATA/prod/prod_prep_%04d_%04d.mat',fileroot,prodrunnum,prepindex),'dataorder','-append');
save(sprintf('%s/_DATA/prod/prod_prep_%04d_%04d.mat',fileroot,prodrunnum,prepindex),'datacode','-append');
save(sprintf('%s/_DATA/prod/prod_prep_%04d_%04d.mat',fileroot,prodrunnum,prepindex),'fileprefix','-append');
save(sprintf('%s/_DATA/prod/prod_prep_%04d_%04d.mat',fileroot,prodrunnum,prepindex),'userminmax','-append');

if realdata
    load(sprintf('%s/_DATA/_SETS/%s.mat',fileroot,shapestr));
    if exist('aa11')
        dataraw = aa11;
    end
    clear aa11;
    nvars = size(dataraw,2);
else
    aaa = imread(sprintf('%s/_DATA/_SETS/%s.jpg',fileroot,shapestr));
    aa1 = (single(aaa(:,:,1))+single(aaa(:,:,2))+single(aaa(:,:,3)))/3;
    dataraw = aa1<200;
    clear aa1 aaa;
    if strcmp(shapestr,'L')
        dataraw = fliplr(dataraw);
    end
    if strcmp(shapestr,'L2')
        dataraw = fliplr(dataraw);
    end
    [datapts(:,2),datapts(:,1)] = find(dataraw);
    datapts(:,2) = size(dataraw,1)+1-datapts(:,2);
    datapts = datapts-0.5;
%    rawdatasizes(1) = size(dataraw,2); 
%    rawdatasizes(2) = size(dataraw,1); 
    nvars = 2;
%    dataraw = datapts;
%    realdata = 1;
end
% maxrandind = max(size(datapts));
% [srii,sortrandind] =sort(rand(maxrandind,1));
% datapts(sortrandind(1:ceil(maxrandind*0.95)),:) = [];
% histogram2(datapts(:,1),datapts(:,2));
% pause
for vari = 1:nvars
    if realdata
        datapts(:,vari) = dataraw(:,dataorder(dataorder==vari));
    end
    maxx(vari) = max(datapts(:,vari))+0.001*max(datapts(:,vari));
    minn(vari) = min(datapts(:,vari))-0.001*min(datapts(:,vari));
end
sizemode = 1;                 % assume x size is greater than y size
[sizedatay,sizedatax] = size(dataraw);            %   Remember that rows are the y-direction and columns are the x-direction  
if sizedatay>sizedatax;   sizemode=2;     end     %   OK, then y size is greater than x size
clear dataraw
% datapts(1,2) = nan;
% datapts(end+1,1) = nan;
sizedataraw = max(size(datapts));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if userminmax==1
    for vari = 1:nvars
        minn(vari) = minnuser(vari);
        maxx(vari) = maxxuser(vari);
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for vari = 1:nvars
    testinan(:,vari) = isnan(datapts(:,vari));
end
testnan    = false(sizedataraw,1);
for vari = 1:nvars
    testnan    = or(testnan,testinan(:,vari));
end
dataptsnan = datapts(~testnan,:);
sizedatanan = max(size(dataptsnan));

testminmax = true(sizedatanan,1);
for vari = 1:nvars
    testimin(:,vari) = dataptsnan(:,vari)>=minn(vari);
    testimax(:,vari) = dataptsnan(:,vari)<=maxx(vari);
    testminmax = and(testminmax,testimin(:,vari));
    testminmax = and(testminmax,testimax(:,vari));
end
dataptsminmax = dataptsnan(testminmax,:);

clear datapts dataptsnan

if strcmp(shapestr(1:min([max(size(shapestr)) 4])),'data')
else
    if sizemode==1
        binfactor = [   1   (maxx(2)-minn(2))/(maxx(1)-minn(1))    1       1        1        1       1       1     1      1        1         1 ];
    else
        binfactor = [   (maxx(1)-minn(1))/(maxx(2)-minn(2))   1    1       1        1        1       1       1     1      1        1         1 ];
    end    
end
for vari = 1:nvars
    databins(vari) = basebins*binfactor(dataorder==vari); 
%    datadelta(vari) = ceil((maxx(vari)-minn(vari))/databins(vari));
    datadelta(vari) = (maxx(vari)-minn(vari))/databins(vari);
    dataindexminmax(:,vari) = floor((dataptsminmax(:,vari)-minn(vari))/datadelta(vari));
    dataindexminmax(dataindexminmax(:,vari)>(databins(vari)-1),vari) = ceil(databins(vari)-1);
end
dataindexminmax = dataindexminmax+1;
datadeltaavg = sum(datadelta)/nvars;
datamin = minn;
datapartitions = unique(dataindexminmax,'rows')-1;
npartitionsr = max(size(datapartitions));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'dataptsminmax';
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    titleinfo1   = sprintf('For %d of Raw Data - Number of Partitions = %d',sizedataraw,npartitionsr);
    titleinfo2   = sprintf('');
    datainfoo{1} = { eval(plotdataname) };
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 };
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 0 1 };
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  SCATTER
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
mapdatarawtonan                 = (1:max(size(testnan)))';
mapdatarawtonan(testnan)        = [];
mapdatanantominmax              = (1:max(size(testminmax)))';
mapdatanantominmax(~testminmax) = [];

[mapdataorder1,mapdataorder2]   = sort(dataorder); 
mapdataorder2(mapdataorder1==0) = [];
mapdataorder1(mapdataorder1==0) = [];
namess3    = datanames(mapdataorder2);
if userminmax==1
    minnn3     = minnuser(mapdataorder2);
    maxxx3     = maxxuser(mapdataorder2);
else
    minnn3     = minn(mapdataorder2);
    maxxx3     = maxx(mapdataorder2);
end
binfactor3 = binfactor(mapdataorder2);
nvars = max(size(mapdataorder2));
datamin = minnn3;
datamax = maxxx3;
%
% Drop from all vars down to only 7 - ke, omega, sigma, beta, velasym, rroc, alpha
%  Also, histogram the data without actually using "histogram" command
%
clear binadd dataptstmp
for vari = 1:nvars
    dataptstmp = dataptsminmax(:,mapdataorder2(vari));
    nbinss = basebins*binfactor3(vari);
    binadd(:,vari) = ceil((dataptstmp-datamin(vari)+epss)/(datamax(vari)-datamin(vari))*(nbinss));
%    binadd(:,vari) = ceil((dataptstmp-minnn3(vari)+epss)/(rawdatasizes(vari))*(nbinss));
%    binadd(:,vari) = ceil((dataptstmp-minnn3(vari))/(maxxx3(vari)-minnn3(vari))*(nbinss));
%    binaddfix = binadd(:,vari)>nbinss;
%    binadd(binaddfix,vari) = nbinss;
end
clear dataptstmp testimin testimax testminmax testinan testnan
%
%  Form the partition ID from the bin coordinates
%
sizedatagood = max(size(binadd));
binaddress = zeros(sizedatagood,1);
binshift = 1;
for vari = 1:nvars
    nbinss = basebins*binfactor3(vari);
    databins(vari) = nbinss;
    binaddress(:) = binaddress(:) + (binadd(:,vari)-1)*binshift; 
    binshift = binshift*nbinss;
end
binaddress = binaddress+1;
maxbinaddress = max(binaddress);
clear ba1 ba2 ba3 ba4 ba5 bau* bins* histt* test* mouth* hey* dd mapdatanantominmax mapdatafulltonan eiall103 binadd

%
%  Form a unique list of partition IDs
%
[binaddu,u2,mapbintounique] = unique(binaddress);
datasizepart = max(size(binaddu))
binu = (0.5:datasizepart+0.5)';
[wgtp,tmp2,mapuniquetowgts]= histcounts(mapbintounique,binu);
wgtp = wgtp';
clear tmp2
binwgtp = (0.5:max(wgtp)+0.5)';
[histwgtp]= histcounts(wgtp,binwgtp);
binwgtp = ceil(binwgtp); binwgtp(end) = [];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    barmax       = min([max(size(binaddu)) smallpartnums3]);
    barmax       = min([max(size(binaddu))]);
    plotdataname = 'binaddu';
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    titleinfo1   = 'Unique Partition Bin Addresses vs Populations (Weights)';
    titleinfo2   = sprintf('');
    xlabel1      = 'Bin Addresses';
    xlabel2      = 'Populations';
    datainfoo{1} = { binaddu(1:barmax) wgtp(1:barmax) };
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 xlabel1 xlabel2};
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 };
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  HISTOGRAM
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    barmax       = min([max(size(binaddu)) smallpartnums3]);
    barmax       = max(wgtp)+1;
    plotdataname = 'wgtp';
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    titleinfo1   = 'Unique Partition Bin Addresses vs Populations (Weights)';
    titleinfo2   = sprintf('');
    xlabel1      = 'Bin Addresses';
    xlabel2      = 'Populations';
    datainfoo{1} = { binwgtp histwgtp };
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 xlabel1 xlabel2};
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 };
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  HISTOGRAM
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear mapuniquetowgts
%
%  Histogram the weights of the partitions - this finds out how dense the
%  data is within the space and allows the lowest density bins to be
%  eliminated.
%   h3   = number of partitions with a particular amount of data
%   h4   = 
%   hind = 
%
% binu2 = (1:max(wgtp))';
% [h3,h4] = histc(wgtp,binu2);
binu2 = (0.5:max(wgtp)+0.5)';
[h3,h5,h4] = histcounts(wgtp,binu2);
clear h5
h3 = h3';
hind = (1:max(size(h3)))';
h3orig   = h3;
h4orig   = h4;
hindorig = hind;
hind(h3==0) = [];
h3(h3==0) = [];

checkpop = cumsum(h3orig.*hindorig);
threshdists = (0:0.001:1)';
threshnums = max(size(threshdists));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%   Application of the Threshdist to remove the low density bins
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for ii = 1:threshnums
    checkhind = ((checkpop/sizedatagood)<=threshdists(ii));
    keeppartlimit = sum(checkhind);
    checkpart = (h4orig>keeppartlimit);
    partkeepnums(ii,1) = sum(checkpart);
end
partkeepnums(end) = 0;
partmatmax2 = min([abs(partmatmax) datasizepart]);
partkeepnums = partkeepnums + epss*rand(size(partkeepnums));
threshdistlookup = max(threshdists(partkeepnums>partmatmax2));
%threshdistinterp = interp1(partkeepnums,threshdists,partmatmax2)
if partmatmax<0
    checkhind = ((checkpop/sizedatagood)<threshdist);
    checkhind(h3orig==0) = [];   
else
%    checkhind = ((checkpop/sizedatagood)<threshdistinterp);
    checkhind = ((checkpop/sizedatagood)<threshdistlookup);
    checkhind(h3orig==0) = [];   
end
keeppartlimit = sum(checkhind);
keeppartlimit = max([0 keeppartlimit]);
checkpart1 = h4orig>keeppartlimit;
partkeep1num = sum(checkpart1);
partkeep1 = binaddu(checkpart1);
partkeep1wgts =  wgtp(checkpart1);
keeppartlimit = max([0 keeppartlimit]);

checkpart2 =(h4orig>=minpop);
partkeep2num = sum(checkpart2);
partkeep2 = binaddu(checkpart2);
partkeep2wgts = wgtp(checkpart2);

partindices  = 1:length(h4orig);
partkeep3num = min([partkeep1num partkeep2num]);
if partkeep3num==partkeep1num
    partkeep = partkeep1;
    partkeepwgts = partkeep1wgts;
    partkeepnum = partkeep1num;
    partkeepind = partindices(checkpart1);
else
    partkeep = partkeep2;
    partkeepwgts = partkeep2wgts;
    partkeepnum = partkeep2num;
    partkeepind = partindices(checkpart2);
end
sizedatakeep = sum(partkeepwgts);
threshdist = eval(sprintf('%5.3f',1-sizedatakeep/sizedatagood))
minpop = max([minpop keeppartlimit]);
% fileprefix = sprintf('%s_%03d_%03d_%12d',shapestr,basebins,minpop,eval(datacode));
% fileprefix = sprintf('%s_%03d',shapestr,basebins);
% filenamess     = ls(sprintf('%s/_DATA/%s/prod_%04d_init_%s_*',fileroot,shapestr,prodrunnum,fileprefix));
% for ii = 1:size(filenamess,1)
%     delete(sprintf('%s/_DATA/%s/%s',fileroot,shapestr,char(filenamess(ii,:))))
% end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%             Special histograms (see the end of the code)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
binaddresstmp = partkeep-1;
binadd2 = zeros(max(size(binaddresstmp)),nvars);
for vari = nvars:-1:1
    binshift = 1;
    for jj = 1:(vari-1)
        nbinss = basebins*binfactor3(jj); 
        binshift = binshift*nbinss;
    end
    binadd2(:,vari) = floor(binaddresstmp/binshift)+1;
    binaddresstmp = binaddresstmp-(binadd2(:,vari)-1)*binshift;
end
partsize = size(binadd2,1)

dataptspartkeep   = zeros(size(dataptsminmax));
dataindexpartkeep = zeros(size(dataindexminmax));
dataminmaxpartindex = binaddress;
datapartkeepindex = zeros(size(dataminmaxpartindex));
kk = 0;
for ii = 1:partsize
   keeppartindices  = find(binaddress==(partkeep(ii)));
   wgtpartkeep = size(keeppartindices,1);
   for jj=1:wgtpartkeep
       kk = kk+1;
       dataptspartkeep(kk,:)   = dataptsminmax(keeppartindices(jj),:);
       dataindexpartkeep(kk,:) = dataindexminmax(keeppartindices(jj),:);
%       datapartkeepindex(keeppartindices(jj),1) = ii;
       datapartkeepindex(kk,1) = ii;
   end  
end
dataptspartkeep((dataptspartkeep(:,1)==0)&(dataptspartkeep(:,2)==0),:) = [];
dataindexpartkeep((dataindexpartkeep(:,1)==0)&(dataindexpartkeep(:,2)==0),:) = [];

clear binu*  u2 h3* h4* hind* check* binaddresstmp
%%%%%%%%%%%   Delta X-L1  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
deltaxl1 = zeros(partsize,partsize);
for vari = 1:nvars
    vartmp = binadd2(:,vari);
    varmat = repmat(vartmp,1,max(size(vartmp)));
    clear vartmp
    vardiff = varmat - varmat';
    clear varmat 
    deltaxl1 = deltaxl1 + abs(vardiff);
    clear vardiff
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'deltaxl1';
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    titleinfo1   = sprintf('Sum of abs(Delta X) ');
    titleinfo2   = sprintf('');
    xlabel1      = 'Partition #';
    xlabel2      = 'Partition #';
    datainfoo{1} = { eval(plotdataname) };
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 xlabel1 xlabel2};
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 1 };
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  SURFACE
varinfoo = {plotdataname eval(sprintf('save%s',plotdataname)) 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Delta R, NN1 (First Nearest Neighbor matrix =  Weighted Adjacency matrix) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
checkvar1nn = zeros(partsize,partsize);
checkvar1nncum = true(partsize,partsize);
deltar  = zeros(partsize,partsize);
for vari = 1:nvars
    vartmp = binadd2(:,vari);
    varmat = repmat(vartmp,1,max(size(vartmp)));
    clear vartmp
    vardiff = varmat - varmat';
    clear varmat 
    checkvar1nn = abs(vardiff)<=1.1;
    checkvar1nncum = checkvar1nncum&checkvar1nn;
    clear checkvar1nn 
    deltar  = deltar  +  vardiff.^2;   
    clear vardiff
end
nn1 = sqrt(deltar.*checkvar1nncum);
clear checkvar1nncum
nn1(1:partsize+1:end) = 0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'nn1';
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    titleinfo1   = sprintf('First Nearest Neighbor matrix - NN1');
    titleinfo2   = sprintf('');
    xlabel1      = 'Partition #';
    xlabel2      = 'Partition #';
    datainfoo{1} = { eval(plotdataname) };
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 xlabel1 xlabel2};
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 0 };
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  SPY
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
nn1(1:partsize+1:end) = 1/bignum;
[ppnn1c,qqnn1c,rrnn1c,ssnn1c,ttnn1c,uunn1c] = dmperm(sparse(nn1));
nn1perm = nn1(ppnn1c,qqnn1c);
nn1(1:partsize+1:end) = 0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'nn1perm';
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    titleinfo1   = sprintf('First Nearest Neighbor matrix - NN1 (permuted)');
    titleinfo2   = sprintf('');
    xlabel1      = 'Partition #';
    xlabel2      = 'Partition #';
    datainfoo{1} = { eval(plotdataname) };
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 xlabel1 xlabel2};
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 0 };
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  SPY
varinfoo = {'nn1' savenn1 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% DeltaR   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
deltar = sqrt(deltar);
deltar(1:partsize+1:end) = 1/bignum;
deltar(1:partsize+1:end) = 10^(-sigfigs);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'deltar';
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    titleinfo1   = sprintf('Euclidean Distance - \\Delta r - from (k,l)');
    titleinfo2   = sprintf('');
    xlabel1      = 'Partition #';
    xlabel2      = 'Partition #';
    datainfoo{1} = { eval(plotdataname) };
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 xlabel1 xlabel2};
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 1 };
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  SURFACE
varinfoo = {plotdataname eval(sprintf('save%s',plotdataname)) 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear  pathltrue pathl1true pathcount pathl1corr
pathltrue   = zeros(partsize);
pathl1true  = zeros(partsize);
pathl1corr  = zeros(partsize);
pathcount   = zeros(partsize);
cornervec  = [];
for vari = 1:nvars
    cornervec  = [cornervec; sqrt(nvars-vari+1)];
end
for ii = 1:partsize
    deltaxbins = zeros(1,partsize);
    for vari = 1:nvars
        vartmp = binadd2(:,vari)';
        vardiff = vartmp(ii) - vartmp;
        deltaxbins = [deltaxbins;vardiff];
    end
    deltaxbins2 = sort(abs(deltaxbins));
    deltaxbins3 = diff(deltaxbins2);
    deltaxbins4 = bsxfun(@times,cornervec,deltaxbins3);
    pathcount(ii,:) = max(deltaxbins2);
    pathltrue(ii,:) = sum(deltaxbins4);
end
pathcount(1:partsize+1:end) = 10^(-sigfigs);
for ii = 1:partsize
    cvl = [];
    for vari = 1:nvars
        vartmp = binadd2(:,vari)';
        vardiff = abs(vartmp(ii) - vartmp);
        cvl = [cvl;vardiff];
    end
    l1farcorner = sum(cvl,1);
    pathl1truee = (max(cvl)+1)/2.*l1farcorner;
    pathl1true(ii,:) = pathl1truee;
    pathl1corr(ii,:) = pathl1truee + l1farcorner + 1;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'pathltrue';
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    titleinfo1   = sprintf('True Path Length from (k,l)');
    titleinfo2   = sprintf('');
    xlabel1      = 'Partition #';
    xlabel2      = 'Partition #';
    datainfoo{1} = { eval(plotdataname) };
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 xlabel1 xlabel2};
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 1 };
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  SURFACE
varinfoo = {plotdataname eval(sprintf('save%s',plotdataname)) 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'pathl1true';
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    titleinfo1   = sprintf('True Path Length (L1) from (k,l)');
    titleinfo2   = sprintf('');
    xlabel1      = 'Partition #';
    xlabel2      = 'Partition #';
    datainfoo{1} = { eval(plotdataname) };
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 xlabel1 xlabel2};
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 1 };
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  SURFACE
varinfoo = {plotdataname eval(sprintf('save%s',plotdataname)) 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
varinfoo = {'pathl1corr' savepathl1corr 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'pathcount';
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    titleinfo1   = sprintf('Path Count (# of neighborhoods) from (k,l)');
    titleinfo2   = sprintf('');
    xlabel1      = 'Partition #';
    xlabel2      = 'Partition #';
    datainfoo{1} = { eval(plotdataname) };
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 xlabel1 xlabel2};
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 1 };
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  SURFACE
maxpathcount = max(max(pathcount));
for jjj=1:maxpathcount
    fillnorm(jjj) = (2*jjj+1)^nvars-(2*jjj-1)^nvars;
end
varinfoo = {plotdataname eval(sprintf('save%s',plotdataname)) 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotdataname = 'dataptsminmax';
    titleinfo1   = sprintf('For %d of Processed Data - Final Number of Partitions = %d',sizedatagood,partkeepnum);
    titleinfo2   = '';
    datainfoo{1} = { eval(plotdataname) };
    figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname);
    datainfoo{1} = { 1 };                                   %  When displaying patches without clusters, just assign one cluster
    fileinfoo{1} = { figinfo titleinfo1 titleinfo2 };
    flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 0 1 0};
    plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  PATCHES (CLUSTERS Without clustering - One Big cluster!)
varinfoo = {plotdataname eval(sprintf('save%s',plotdataname)) 1};eval(sprintf('global %s',varinfoo{1}));saveright01(varinfoo);
varinfoo = {'dataindexminmax' savedeltaxl1 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
varinfoo = {'binadd2' savedeltaxl1 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
workspacee = whos;
memusedinit = sum([workspacee.bytes]);

tendinit = now;
durationninit = tendinit-tstartinit;
display(sprintf('Ending Initialization at %s',datestr(datetime('now'))))
tstartinitt = datetime(datevec(tstartinit));
tendinitd   = datetime(datevec(tendinit));
timeinit = rem(durationninit,1)*86400;
display(sprintf('Initialization Duration: %s',datestr(timeinit/86400, 'HH:MM:SS')));


save(sprintf('%s/_DATA/prod/prod_prep_%04d_%04d.mat',fileroot,prodrunnum,prepindex),'fileprefix','-append');
save(sprintf('%s/_DATA/prod/prod_prep_%04d_%04d.mat',fileroot,prodrunnum,prepindex),'minpop','-append');
save(sprintf('%s/_DATA/prod/prod_prep_%04d_%04d.mat',fileroot,prodrunnum,prepindex),'threshdist','-append');
save(sprintf('%s/_DATA/prod/prod_prep_%04d_%04d.mat',fileroot,prodrunnum,prepindex),'shapestr','-append');

%%%%
%%%%   Save all of the variables
%%%%
    varnamess = {varnamesshort{:} varnameslong{:} varnamestime{:}}; 
    for ii = 1:size(varnamess,2); eval(sprintf('global %s',varnamess{ii}));  end;
    saverightend01;
    profile off

initializereturn = 1;

else
    display('INITIALIZE files already exists and OVERWRITE INITIALIZE set to ZERO.  INITIALIZE analysis NOT DONE.')
    filenamess = ls(sprintf('%s/_DATA/%s/prod_%04d_%s_%s_*_short.mat',fileroot,shapestr,prodrunnum,dataname,shapestr));
    fileprefix = filenamess(16:26);
    fileprefix = sprintf('%s_%03d',shapestr,basebinstitle);
    save(sprintf('%s/_DATA/prod/prod_prep_%04d_%04d.mat',fileroot,prodrunnum,prepindex),'fileprefix','-append');

    initializereturn = {1};
end
return
















