function [ kmeanmedsreturn ] = clus16_kmeanmeds(varargin)
close all force
profile off
warning off
% clearvars -except fileroot do* prepindex numprepfiles prepfiles prodrunnum prepindexstart prepindexend tstartfull tstartsingle
global fileroot shapestr prodrunnum prepindex fileprefix dataname 
global sigfigs smallpartnums3 partsize  
global dataptsminmax dataptspartkeep dataindexminmax dataindexpartkeep datapartkeepindex dataminmaxpartindex binadd2 datamin datamax datadelta 
global varnamesshort varnameslong varnamestime
varnamesshort = {'bignum','sigfigs','minpop','minpathl','threshdist','nvars','databins','datadelta','datamax','datamin','shapestr','partsize','partkeep','partkeepind','memusedkmeanmeds','clusterkmeans','clustermedoidsn','nclustersn','clusterkmedoids','clustermedoidsd','nclustersd','kloop'};
varnameslong  = {'kmeanmedsmat'};
varnamestime  = {'timekmeanmeds','tstartkmeanmedst','tendkmeanmedsd'};
dataname      = 'kmeanmeds';
global deltar wgtmat kloop

load(sprintf('%s/_DATA/prod/prod_prep_%04d_%04d.mat',fileroot,prodrunnum,prepindex));
display(sprintf('%04d - %s - Calculate KMEANMEDS',prodrunnum,fileprefix))

tstartkmeanmeds = now;
%profile on
loadname = 'init'; 
varinfoo = {loadname,'''-regexp'',''^(?!deltar|deltaxl1|dircos|pathcount|pathl1true|pathl1corr|dataindexminmax|dataptsminmax)\w'''};
loadright1 = loadright03(varinfoo); 
for jj=1:size(loadright1,2); 
    varnames=fieldnames(loadright1{jj}); 
    for ii=1:size(varnames,1); 
        eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); 
    end; 
    loadright1{jj}=[]; 
end

checkfilekmeanmeds0 = ls(sprintf('%s/_DATA/%s/prod_%04d_%s_%s_*.mat',fileroot,shapestr,prodrunnum,dataname,fileprefix));
checkfilekmeanmeds  = logical(size(checkfilekmeanmeds0,2));
if checkfilekmeanmeds
   display('KMEANMEDS clustering already done.');
end
checkgokmeanmeds =  ~(checkfilekmeanmeds&(~checkoverwritekmeanmeds));
if checkgokmeanmeds             % GO!!!!!!!
    display(sprintf('KMEANMEDS files:  %1d OVERWRITE KMEANMEDS:  %1d   KMEANMEDS analysis will be DONE.',checkfilekmeanmeds,checkoverwritekmeanmeds));

    tstartconnpathl = now;
    %profile on
    loadname = 'init'; 
    varinfoo = {loadname,'''-regexp'',''^(?!deltaxl1|dircos|pathcount|pathltrue|pathl1true|pathl1corr)\w'''};
    loadright1 = loadright03(varinfoo); 
    for jj=1:size(loadright1,2); 
        varnames=fieldnames(loadright1{jj}); 
        for ii=1:size(varnames,1); 
            eval(sprintf('%s=loadright1{jj}.%s;',varnames{ii},varnames{ii})); 
        end; 
        loadright1{jj}=[]; 
    end
    wgtmat = partkeepwgts*partkeepwgts'-diag(partkeepwgts);

    if plotall2==1
        plotkmeanmeds = 1;
    end
    
    clustershow       = bignum;
    kloopstart        = kmeanmedsmode;
    kloopend          = kmeanmedsmode;
    if kmeanmedsmode==0; kloopstart = 1; kloopend = 3; end
    for kloop = kloopstart:kloopend
        if kloop==1; partindexsize = partsize;     datasett = binadd2;           end
        if kloop==2; partindexsize = sizedatakeep; datasett = dataindexpartkeep; end
        if kloop==3; partindexsize = sizedatakeep; datasett = dataptspartkeep;   end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%`  KMeans
        partdataindex = 1:partindexsize;
        optskmeans = statset('Display','final');
        [idxmean,Cmean] = kmeans(datasett,cluskmeanmedsknum,'Distance','sqeuclidean','Replicates',5,'Options',optskmeans,'EmptyAction','drop');
%        [idxmean,Cmean] = kmeans(datasett,cluskmeanmedsknum,'Distance','cityblock','Replicates',5,'Options',optskmeans);
%        [idxmean,Cmean] = klmeans(datasett,cluskmeanmedsknum,'Options',optskmeans);
        nclustersn = max(idxmean);
        clustertmp = zeros(nclustersn,partsize);
        for ii = 1:nclustersn
%            clustertmp0(1,:)                     = partdataindex(idxmean==ii);
            clustertmp0(1,:)                     = unique(datapartkeepindex(partdataindex(idxmean==ii)));
            clustertmp(ii,1:size(clustertmp0,2)) = clustertmp0;
            clear clustertmp0
        end            
            clustertmp(sum(clustertmp,2)==0,:)=[];
            clustertmpc = sum(clustertmp,1);
            clustertmp(:,clustertmpc==0) = [];
            [clustertmp1,ctmp1a,ctmp1b] = unique(clustertmp,'rows');
            clustertmp2 = clustertmp1(ctmp1b,:);
            clustertmp2log = logical(clustertmp2);
            clustertmp2size  = sum(clustertmp2log,2);
            [ca,cb] = sort(clustertmp2size,'descend');
            clf
            spy(clustertmp2log(cb,:))
            axis normal
            clustertmp22 = clustertmp2(cb,:);
            Cmean = Cmean(cb,:);

            clussize = min([size(clustertmp22,1) clustershow]);
            clustertmp2 = clustertmp22(1:clussize,:);
            clear clusterkmeans clustermedoidsn
            clusterkmeans = clustertmp2;
            checkclussize = (sum(clusterkmeans>0,2)>minpathlprep);
            nclustersn = size(clusterkmeans,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%
%%%%%%%  Find the centers of the dense regions 
%%%%%%%
            for mm = 1:nclustersn
                if     kloop==1
                    clustermedoidsn(mm,:) =  Cmean(mm,:);   
                elseif kloop==2
                    clustermedoidsn(mm,:) =  Cmean(mm,:);
                elseif kloop==3
                    clustermedoidsn(mm,:) =  Cmean(mm,:);
                end
            end
            clustermedoidsn(~checkclussize) = 0;        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            plotdataname = 'kmeans';
            figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s_%d.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname,kloop);
            titleinfo1   = sprintf('%s Clustering into %d Clusters    Mode= %d',upper(plotdataname),nclustersn,kloop);
            titleinfo2   = sprintf('');
            datainfoo{1} = { eval(sprintf('cluster%s',plotdataname)) clustermedoidsn};
            fileinfoo{1} = { figinfo titleinfo1 titleinfo2 };
            flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 1 plotmedoidsc};
            plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  CLUSTER
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    titlekmeans           = titleinfo1;
    clusterkmeanmeds{1,1} = {clusterkmeans};
    clusterkmeanmeds{1,2} = {clustermedoidsn};
    clusterkmeanmeds{1,3} = {nclustersn};
    clusterkmeanmeds{1,4} = {titlekmeans};
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  MEDOIDS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
        optskmeds = statset('Display','iter');
        [idxmed,Cmeds,sumd,d,midx,infoo] = kmedoids(datasett,cluskmeanmedsknum,'Distance','sqeuclidean','Options',optskmeds);
%        [idxmed,Cmeds,sumd,d,midx,infoo] = kmedoids(datasett,cluskmeanmedsknum,'Distance','cityblock','Options',optskmeds);
        infoo
        nclustersd = max(idxmed);
        clear clustertmp*
        clustertmp = zeros(nclustersd,partsize);
        for ii = 1:nclustersd
%            clustertmp0(1,:)                     = partdataindex(idxmed==ii);
            clustertmp0(1,:)                     = unique(datapartkeepindex(idxmed==ii));
            clustertmp(ii,1:size(clustertmp0,2)) = clustertmp0;
            clear clustertmp0
        end
            clustertmp(sum(clustertmp,2)==0,:)=[];
            clustertmpc = sum(clustertmp,1);
            clustertmp(:,clustertmpc==0) = [];
            [clustertmp1,ctmp1a,ctmp1b] = unique(clustertmp,'rows');
            clustertmp2 = clustertmp1(ctmp1b,:);
            clustertmp2log = logical(clustertmp2);
            clustertmp2size  = sum(clustertmp2log,2);
            [ca,cb] = sort(clustertmp2size,'descend');
            clf
            spy(clustertmp2log(cb,:))
            axis normal
            clustertmp22 = clustertmp2(cb,:);
            Cmeds = Cmeds(cb,:);
            
            clussize = min([size(clustertmp22,1) clustershow]);
            clustertmp2 = clustertmp22(1:clussize,:);
            clear clusterkmedoids clustermedoidsd
            clusterkmedoids = clustertmp2;    
            checkclussize = (sum(clusterkmedoids>0,2)>minpathlprep);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            kmeanmedsmat  = [1 1; 2 2];
        varinfoo = {'kmeanmedsmat' savekmeanmeds 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    clusterkmeans = [1 1; 2 2];
%    clusterkmedoids = [1 1; 2 2];
            nclustersd = size(clusterkmedoids,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%
%%%%%%%  Find the centers of the dense regions 
%%%%%%
            for mm = 1:nclustersd
                if     kloop==1
                    if exist('deltar'); medoidtype = 1; else;  medoidtype = 2; end
                    [clusmed] = findmedoid_03(clusterkmedoids(mm,:),medoidtype);
                    clustermedoidsd(mm,1) = clusmed;   
                elseif kloop==2
%                    [clusmed] = findmedoid_03(clusterkmedoids(mm,:),1);
%                    clustermedoidsd(mm,1) = clusmed;
%                    med1 = (dataindexpartkeep(:,1)==Cmeds(mm,1))&(dataindexpartkeep(:,2)==Cmeds(mm,2));
%                    med2 = partdataindex(med1);
%            clustertmp0(1,:)                     = partdataindex(idxmed==ii);
%                     clustermedoidsd(mm,1) =  med2(ceil(end/2));
%                    med1 = (binadd2(:,1)==Cmeds(mm,1))&(binadd2(:,2)==Cmeds(mm,2));
%                     clustermedoidsd(mm,1) = partkeepind(med1);
                     clustermedoidsd(mm,:) =  Cmeds(mm,:);
                elseif kloop==3
                    med1 = (dataptspartkeep(:,1)==Cmeds(mm,1))&(dataptspartkeep(:,2)==Cmeds(mm,2));
                    med2 = partdataindex(med1);
                    clustermedoidsd(mm,1) =  med2(ceil(end/2));
                end
            end
            clustermedoidsd(~checkclussize) = 0;        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            plotdataname = 'kmedoids';
            figinfo      = sprintf('%s/_FIGS/%s/prod_%04d_%s_%s_%d.jpg',fileroot,shapestr,prodrunnum,fileprefix,plotdataname,kloop);
            titleinfo1   = sprintf('%s Clustering into %d Clusters    Mode= %d',upper(plotdataname),nclustersn,kloop);
            titleinfo2   = sprintf('');
            datainfoo{1} = { eval(sprintf('cluster%s',plotdataname)) clustermedoidsd};
            fileinfoo{1} = { figinfo titleinfo1 titleinfo2 };
            flaginfoo{1} = { eval(sprintf('plot%s',plotdataname)) eval(sprintf('print%s',plotdataname)) plotnow 1 1 plotmedoidsc};
            plotviewer01(datainfoo,fileinfoo,flaginfoo);            %  CLUSTER
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    end
    titlekmedoids         = titleinfo1;
    clusterkmeanmeds{2,1} = {clusterkmedoids};
    clusterkmeanmeds{2,2} = {clustermedoidsd};
    clusterkmeanmeds{2,3} = {nclustersd};
    clusterkmeanmeds{2,4} = {titlekmedoids};
    
    kmeanmedsreturn = {clusterkmeanmeds};
%%%%
%%%%   Save all of the clusters
%%%%
%     varinfoo = {'clusterkmeanmeds' savekmeanmeds 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
%     varinfoo = {'clustermedoidsk' savekmeanmeds 1}; eval(sprintf('global %s',varinfoo{1})); saveright01(varinfoo);
%%%%
%%%%  Compute memory and timing variables for performance
%%%%
    tendkmeanmeds = now;
    durationnkmeanmeds = tendkmeanmeds-tstartkmeanmeds;
    display(sprintf('Ending KMEANMEDS Analysis at %s',datestr(datetime('now'))))
    tstartkmeanmedst = datetime(datevec(tstartkmeanmeds));
    tendkmeanmedsd   = datetime(datevec(tendkmeanmeds));
    timekmeanmeds = rem(durationnkmeanmeds,1)*86400;
    display(sprintf('KMEANMEDS Analysis Duration: %s',datestr(timekmeanmeds/86400, 'HH:MM:SS')));

    workspacee = whos;
    memusedkmeanmeds = sum([workspacee.bytes]);
%%%%
%%%%   Save all of the variables
%%%%
    varnamess = {varnamesshort{:} varnameslong{:} varnamestime{:}}; 
    for ii = 1:size(varnamess,2); eval(sprintf('global %s',varnamess{ii}));  end;
    saverightend01;
    profile off

else
    display('KMEANMEDS files already exists and OVERWRITE KMEANMEDS set to ZERO.  KMEANMEDS analysis NOT DONE.')
    kmeanmedsreturn = {1};
end
close all
return 

    
    
